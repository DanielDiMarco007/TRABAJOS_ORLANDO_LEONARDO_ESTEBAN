import color from 'colors';

import {suma, resta, multiplicacion, division} from  './my_modules/funciones.js';


const a = 4;
const b = 2;


console.log('                                                                              '.bgRed);
console.log('                                                                              '.bgRed);

console.log( '         '.bgRed,`suma ${a} + ${b} es  `.blue , suma(a,b),'                                      ','           '.bgRed);
console.log( '         '.bgRed,`resta   ${a} - ${b} es`.red , resta(a,b),'                                     ','           '.bgRed); 
console.log( '         '.bgRed,`multiplicacion ${a} * ${b} es `.yellow , multiplicacion(a,b),'                             ','           '.bgRed);
console.log( '         '.bgRed,`division ${a} entre ${b} es `.green , division(a,b),'                               ','           '.bgRed);

console.log('                                                                              '.bgRed);
console.log('                                                                              '.bgRed);