import colors from 'colors';
import readlineSync from 'readline-sync';
import funciones from './my_modules/funciones.js';

let opcion;




do{
 do{


    funciones.mostrar_menu();
    
     
      opcion = parseInt(readlineSync.question('Seleccione una opcion: '.yellow));
 
 }while(opcion < 0 || opcion > 3 || isNaN(opcion)); 
 
  switch(opcion){

    case 0:
        console.log('SALIENDO DE LA APP...'.red);
    break;

    case 1: 
        console.log(funciones.holaMundo.green);  
        opcion = readlineSync.question('Presione ENTER para continuar...'.yellow);
    
    break

     case 2:
        console.log(funciones.presentacion.red);
        opcion = readlineSync.question('Presione ENTER para continuar...'.yellow);
    break; 
    
        case 3:
        console.log(funciones.operaciones(10,2).blue);
        opcion = readlineSync.question('Presione ENTER para continuar...'.yellow);
        break;
        
        default:
        
        console.log('OPCION NO VALIDA'.red);
    break;


}


}while(opcion != 0);