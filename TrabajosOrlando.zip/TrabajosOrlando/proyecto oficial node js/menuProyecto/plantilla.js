import Colors  from "colors";

function mostrarplantilla(titulo, opciones, tamaño=50, espacio=12){
const emptyline = ' '.repeat(tamaño);
console.log(emptyline.bgGreen);


console.log(

"  ".bgGreen +
" ".repeat(Math.floor((tamaño - 4 - titulo.length)/2)) + 
titulo + 

"  ".repeat((tamaño - 4 - titulo.length - Math.floor(tamaño - 4 - titulo.length)/2)) +
"  ".bgGreen
);

console.log(emptyline.bgGreen);
opciones.forEach((opcion,index) => {
const opcionStr = ` ${index +1}. ${opcion}`;
console.log("  ".bgGreen + opcionStr + " ".repeat(10) +
 opcionStr +
  " ".repeat(tamaño - opcionStr.length) +
   "  ".bgGreen); 
});


mostrarplantilla("TIENDA SENA CBA",[

'1. HOLA MUNDO',
'2. PRESENTACION',
'3. OPERACIONES',
'0. CERRAR APP' 



]);
}