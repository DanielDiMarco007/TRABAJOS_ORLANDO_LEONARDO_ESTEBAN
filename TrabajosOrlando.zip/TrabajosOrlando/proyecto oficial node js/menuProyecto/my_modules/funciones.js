
import colors from 'colors';
import readlineSync from 'readline-sync';



const mostrar_menu = () => {

console.log('                            '.bgGreen);
     console.log(`${'  '.bgGreen}     TIENDA SENA CBA    ${'  '.bgGreen}`);
     console.log('                            '.bgGreen);
     console.log(`${'  '.bgGreen}   ${'1'.green}      HOLA MUNDO    ${'  '.bgGreen}      `);
     console.log(`${'  '.bgGreen}   ${'2'.green}      PRESENTACION  ${'  '.bgGreen}      `);
     console.log(`${'  '.bgGreen}   ${'3'.green}      OPERACIONES   ${'  '.bgGreen}      `);
     console.log(`${'  '.bgGreen}   ${'0'.green}      CERRAR APP    ${'  '.bgGreen}      `);
     console.log('                            '.bgGreen);
    
};

const holaMundo = () => {

    return('HOLA MUNDO'.green);  
};
const presentacion = () => {
    return('PRESENTACION'.red);
};
const operaciones = (dato1,dato2) => {
    console.log('OPERACIONES'.blue);
    const suma = dato1 + dato2;
    const resta = dato1 - dato2;
    const multiplicacion = dato1 * dato2;
    const division = dato1 / dato2;
    return (`LA SUMA ES: ${suma}, LA RESTA ES: ${resta}, LA MULTIPLICACION ES: ${multiplicacion}, LA DIVISION ES: ${division}`);
}
const funciones = {
    mostrar_menu,
    holaMundo,
    presentacion,
    operaciones
};
export default funciones;