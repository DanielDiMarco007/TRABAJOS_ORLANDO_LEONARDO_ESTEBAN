
import colors from 'colors'



class Automovil {
    constructor(marca, linea, modelo, cilindraje, precio) {
        this.marca = marca;
        this.linea = linea;
        this.modelo = modelo;
        this.cilindraje = cilindraje;
        this.precio = precio;
    }

    //metodo informacionVehiculo
    informacionVehiculo() {
        console.log(`El vehiculo es un ${this.marca} ${this.linea} del año ${this.modelo}, con cilindraje de ${this.cilindraje}cc y un precio de $${this.precio}`);
    };


    //metodo revisionTecnicoMecanica
    revisionTecnicoMecanica() {
        if (this.modelo < 2025) {
            console.log(`El vehiculo ${this.marca} ${this.linea} del año ${this.modelo} requiere revision tecnico-mecanica`);
        }
    };

    //metodo nivelGasolina
    nivelGasolina() {
        const nivel = Math.floor(Math.random() * 101);
        console.log(`El nivel de gasolina del vehiculo ${this.marca} ${this.linea} es de ${nivel}%`);
    }


};



//CLASE HIJA AUTOMOVILSEDAN
class AutomovilSedan extends Automovil {
    constructor(marca, linea, modelo, cilindraje, precio, numeroPasajeros, tipoCaja) {
        super(marca, linea, modelo, cilindraje, precio);
        this.numeroPasajeros = numeroPasajeros;
        this.tipoCaja = tipoCaja;

    }
    //metodo numeroCinturonesSeguridad
    numeroCinturonesSeguridad() {
        console.log(`El vehiculo sedan ${this.marca} ${this.linea} tiene ${this.numeroPasajeros} cinturones de seguridad`);
    }

    //sobreescritura del metodo informacionVehiculo
    informacionVehiculo() {
        console.log(`El vehiculo es un ${this.marca} ${this.linea} del año ${this.modelo}, con cilindraje de ${this.cilindraje}cc y un precio de $${this.precio},con ${this.numeroPasajeros} cinturones de seguridad `);
    }

    //metodo tipoCaja
    tipoCajaSedan() {

        console.log(`el vehiculo sedan ${this.marca} ${this.linea} tiene una caja de tipo ${this.tipoCaja}`);
    }

}



//instancias de la clase AutomovilSedan
// const sedan1 = new AutomovilSedan('Mazda', 'sedan', 2017, 1800, 50000000, 4, 'automatica skyactiv-drive')
// const sedan2 = new AutomovilSedan('Toyota', 'Corolla', 2018, 1800, 20000, 4, 'automatica');
// const sedan3 = new AutomovilSedan('Honda', 'Civic', 2020, 2000, 25000, 2, 'manual');


// console.log("---------------------------------------------------------".rainbow)
// sedan1.informacionVehiculo();
// sedan1.numeroCinturonesSeguridad();
// sedan1.nivelGasolina();
// sedan1.tipoCajaSedan();
// sedan1.revisionTecnicoMecanica();
// console.log("---------------------------------------------------------".rainbow)
// sedan2.informacionVehiculo();
// sedan2.numeroCinturonesSeguridad();
// sedan2.nivelGasolina();
// sedan2.tipoCajaSedan();
// sedan2.revisionTecnicoMecanica();
// console.log("---------------------------------------------------------".rainbow)
// sedan3.informacionVehiculo();
// sedan3.numeroCinturonesSeguridad();
// sedan3.nivelGasolina();
// sedan3.tipoCajaSedan();
// sedan3.revisionTecnicoMecanica();
// console.log("---------------------------------------------------------".rainbow)


export default Automovil;