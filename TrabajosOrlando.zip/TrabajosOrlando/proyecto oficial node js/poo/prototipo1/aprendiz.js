//CLASE BASE: APRENDIZ
function Aprendiz(nombre, apellidos, edad) {
    this.nombre = nombre;
    this.apellido = apellidos;
    this.edad = edad;
    this.lenguajes = [];
};





// Agregar metodos al prototipo de la función constructora

//Metodo saludar: Saluda al usuario en el frontend
Aprendiz.prototype.saludar = function () {
    console.log(`Hola, mi nombre es ${this.nombre} ${this.apellidos}`);

};
//Metodo Aprendido: Añade un lenguaje al array de lenguajes e informa que se aprendido
Aprendiz.prototype.aprendido = function (lenguaje) {
    this.lenguajes.push(lenguaje);
    console.log(`He aprendido ${lenguaje}`);
};
//Metodo de despedida: Se despide del usuario en el frontend
Aprendiz.prototype.despedida = function (lenguaje) {
    console.log(`Adios ${this.nombre}`);
};


//SUBCLASES DE LA CLASE BASE APRENDIZ
//Subclase Aprendiz etapa practica}

function AprendizPractica(nombre, apellidos, edad, nombreEmpresa, sueldo, cargo) {
    Aprendiz.call(this, nombre, apellidos, edad);
    this.nombreEmpresa = nombreEmpresa; // Nombre de la empresa
    this.sueldo = sueldo; // Sueldo del aprendiz
    this.cargo = cargo; // Cargo del aprendiz
};

//Establecer la herencia de prototipos
AprendizPractica.prototype = Object.create(Aprendiz.prototype);
AprendizPractica.prototype.constructor = AprendizPractica;

//Metodo especial para aprendiz en etapa practica
AprendizPractica.prototype.trabajar = function () {
    console.log(`El aprendiz ${this.nombre} esta trabajando en ${this.nombreEmpresa} como ${this.cargo}`);
};
AprendizPractica.prototype.recibirSueldo = function () {
    console.log(`El aprendiz ${this.nombre} ha recibido su sueldo de ${this.sueldo}`);
};
AprendizPractica.prototype.saludar = function () {
    console.log(`Hola, mi nombre es ${this.nombre} ${this.apellidos} y estoy en etapa practica en la empresa ${this.nombreEmpresa}`);
};


//Subclase Aprendiz etapa lectiva
function AprendizLectiva(nombre, apellidos, edad, ficha, jornada, programadeFormacion) {
    Aprendiz.call(this, nombre, apellidos, edad);
    this.ficha = ficha; // Numero de ficha
    this.jornada = jornada; // Jornada del aprendiz
    this.programadeFormacion = programadeFormacion; // Programa de formacion
};

//Establecer la herencia de prototipos
AprendizLectiva.prototype = Object.create(Aprendiz.prototype);
AprendizLectiva.prototype.constructor = AprendizLectiva;

//Metodo especial para aprendiz en etapa lectiva
AprendizLectiva.prototype.estudiar = function () {
    console.log(`El aprendiz ${this.nombre} esta estudiando el programa de formacion ${this.programadeFormacion}`);
};
AprendizLectiva.prototype.asistirClase = function () {
    console.log(`El aprendiz ${this.nombre} esta asistiendo a clases en la jornada de ${this.jornada}`);
};
AprendizLectiva.prototype.saludar = function () {
    console.log(`Hola, mi nombre es ${this.nombre} ${this.apellidos} y estoy en etapa lectiva en el programa de formacion ${this.programadeFormacion}`);
};
AprendizLectiva.prototype.despedida = function () {
    console.log(`Adios ${this.nombre}, nos vemos en clase`);
}


//Instanciar Objetos
const aprendiz1 = new AprendizPractica('Ana', 'Martinez', 23, 'Tech Solutions', 1500, 'Desarrolladora Junior');
aprendiz1.saludar();
aprendiz1.trabajar();
aprendiz1.recibirSueldo();
aprendiz1.aprendido('ReactJS');
aprendiz1.despedida();
const aprendiz2 = new AprendizLectiva('Luis', 'Ramirez', 21, 'F12345', 'Diurna', 'Desarrollo Web');
aprendiz2.saludar();
aprendiz2.estudiar();
aprendiz2.asistirClase();
aprendiz2.aprendido('NodeJS');
aprendiz2.despedida();