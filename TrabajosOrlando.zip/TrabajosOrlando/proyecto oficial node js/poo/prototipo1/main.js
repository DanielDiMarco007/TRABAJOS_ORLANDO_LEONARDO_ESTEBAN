// ============================================================================
// PROGRAMA PRINCIPAL: Gestión de Clases
// AUTOR: [Tu nombre aquí]
// DESCRIPCIÓN: Menú interactivo que permite al usuario explorar y ejecutar
//              los métodos de las clases Automóvil, Instructor y Restaurante.
// ============================================================================

import readlineSync from 'readline-sync';
import colors from 'colors';

// Importación de las clases principales
import Automovil from './automovil.js';
import Instructor from './instructor.js';
import Restaurante from './restaurante.js';


console.log(colors.rainbow('===== Bienvenido al programa de Clases en Node.js ====='));

let continuar = true;

while (continuar) {

  console.log(colors.yellow('===================== MENÚ PRINCIPAL ====================='));
  console.log('||'.yellow,('1. Automóviles '),'                                    ','||'.yellow);
  console.log('||'.yellow,('2. Instructores '),'                                   ','||'.yellow);
  console.log('||'.yellow,('3. Restaurantes '),'                                   ','||'.yellow);
  console.log('||'.yellow,('4. Salir '),'                                          ','||'.yellow);
  console.log(colors.yellow('=========================================================='));

  const opcion = readlineSync.question(colors.green('Seleccione una opcion: '));

  switch (opcion) {
    // ========================================================================
    // OPCIÓN 1 - AUTOMÓVILES
    case '1':
        console.clear()
      console.log(colors.magenta('--- AUTOMÓVILES ---'));
      const auto1 = new Automovil('Mazda', 'Sedan', 2017, 1800, 50000000);
      const auto2 = new Automovil('Toyota', 'Corolla', 2020, 2000, 65000000);

      console.log(colors.green('Mostrando informacion de los vehiculos:'));
      auto1.informacionVehiculo();
      auto1.nivelGasolina();
      auto1.revisionTecnicoMecanica();

      console.log('----------------------------------------------------');
      auto2.informacionVehiculo();
      auto2.nivelGasolina();
      auto2.revisionTecnicoMecanica();
      break;

    // ========================================================================
    // OPCIÓN 2 - INSTRUCTORES
    case '2':
    console.clear()
      console.log(colors.magenta('--- INSTRUCTORES ---'));
      const ins1 = new Instructor('Nelson', 'Software', 'Mixta');
      const ins2 = new Instructor('Rucio', 'Hardware', 'Diurna');
      const ins3 = new Instructor('Carlos', 'Electrónica', 'Nocturna');

      console.log(colors.green('Informacion de los instructores:'));
      ins1.informacionInstructor();
      ins1.programaFormacion();

      console.log('----------------------------------------------------');
      ins2.informacionInstructor();
      ins2.programaFormacion();

      console.log('----------------------------------------------------');
      ins3.informacionInstructor();
      ins3.programaFormacion();
      break;

    // ========================================================================
    // OPCIÓN 3 - RESTAURANTES
    case '3':
        console.clear()
      console.log(colors.magenta('--- RESTAURANTES ---'));
      const pedido1 = new Restaurante('Salmón rosado Alemán', 1, 300000);
      const pedido2 = new Restaurante('Arepas Reina Pepiada', 5, 40000);

      console.log(colors.green('Mostrando pedidos:'));
      pedido1.pedidoRestaurante();
      pedido1.valorPedido();
      pedido1.descuentoPedido();

      console.log('----------------------------------------------------');
      pedido2.pedidoRestaurante();
      pedido2.valorPedido();
      pedido2.descuentoPedido();
      break;

    // ========================================================================
    // OPCIÓN 4 - SALIR
    case '4':
        console.clear()
      console.log(colors.blue('Gracias por usar el programa. ¡Hasta luego! '));
      continuar = false;
      break;

    // ========================================================================
    // OPCIÓN INVÁLIDA
    default:
      console.log(colors.red(' Opcion no valida. Intente nuevamente.'));
      break;
  }

  // Esperar antes de regresar al menú
  if (continuar && opcion !== '4') {
    readlineSync.question(colors.cyan('Presione Enter para volver al menu...'));
  }
}
