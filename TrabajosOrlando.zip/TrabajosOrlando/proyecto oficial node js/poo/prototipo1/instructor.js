
import colors from 'colors'



class Instructor {
    constructor(nombre, linea, jornada) {
        this.nombre = nombre;
        this.linea = linea;
        this.jornada = jornada;
    }

    //metodo informacionInstructor
    informacionInstructor() {
        console.log(`el nombre del instructor es ${this.nombre} y trabajo en la jornada ${this.jornada}`);
    }

    //metodo programaFormacion
    programaFormacion() {
        const linea1 = "Software";
        const linea2 = "Hardware";
        if (this.linea === linea1) {

            console.log(`el instructor ${this.nombre} pertenece al area de Análisis y desarrollo de software`)
        } else if (this.linea === linea2) {
            console.log(`el instructor ${this.nombre} pertenece al area de Administración de redes`)
        };

        if (this.linea !== linea1 && this.linea !== linea2) {
            console.log(`no se tiene registro calificado para estas lineas tecnologicas por parte del insructor ${this.nombre} `)
        }

    }
}


class InstructorPlanta extends Instructor {
    constructor(nombre, linea, jornada, fecha_vinculacion) {
        super(nombre, linea, jornada);
        this.fecha_vinculacion = fecha_vinculacion;
    }

    //metodo tiempo_vinculacion
    tiempo_vinculacion() {
        console.log(`el instructor ${this.nombre} se vinculó en ${this.fecha_vinculacion} `);
    }

    // polimorfismo del metodo informacionInstructor
    informacionInstructor() {
        console.log(`el nombre del instructor es ${this.nombre} y trabajo en la jornada ${this.jornada}. Fue vinculado en ${this.fecha_vinculacion}`);
    }

}



//instancias de la clase InstructorPlanta
// const ins1 = new InstructorPlanta('Nelson', 'Software', 'mixta', '27/06/2007');
// const ins2 = new InstructorPlanta('Rucio', 'Hardware', 'diurna', '10/11/2010');
// const ins3 = new InstructorPlanta('Angel', 'Hardware', 'nocturna', '15/03/2015');


// console.log("--------------------------------------------------------------------------------------------------------------".rainbow)

// ins1.informacionInstructor();
// ins1.tiempo_vinculacion();
// ins1.programaFormacion();
// console.log("---------------------------------------------------------".rainbow)


// ins2.informacionInstructor();
// ins2.tiempo_vinculacion();
// ins2.programaFormacion();
// console.log("---------------------------------------------------------".rainbow)
// ins3.informacionInstructor();
// ins3.tiempo_vinculacion();
// ins3.programaFormacion();
// console.log("---------------------------------------------------------".rainbow)
export default Instructor;