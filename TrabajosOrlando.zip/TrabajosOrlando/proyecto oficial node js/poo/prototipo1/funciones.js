function menu() {
console.log('                                                      '.bgGreen)
  console.log(colors.yellow('||'.bgGreen,'========= MENÚ ClASES CON HIJAS ==========','||'.bgGreen));
  console.log('||'.bgGreen,(colors.yellow('1. Instructor')),'                       ','||'.bgGreen);
  console.log('||'.bgGreen,(colors.yellow('2. Automovil')),'                        ','||'.bgGreen);
  console.log('||'.bgGreen,(colors.yellow('3. Restaurante')),'                      ','||'.bgGreen);
  console.log('||'.bgGreen,(colors.yellow('4. Salir')),'                            ','||'.bgGreen);
  console.log(colors.yellow('||'.bgGreen,'==========================================','||'.bgGreen));
console.log('                                                      '.bgGreen)
}



const operaciones = [menu]

export default operaciones;