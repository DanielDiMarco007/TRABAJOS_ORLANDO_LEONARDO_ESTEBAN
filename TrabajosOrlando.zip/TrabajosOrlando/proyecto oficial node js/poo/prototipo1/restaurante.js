import colors from 'colors'








class Restaurante {
  constructor(plato, cantidad, precio) {
    this.plato = plato;
    this.cantidad = cantidad;
    this.precio = precio;

  }

  //metodo pedidoRestaurante
  pedidoRestaurante() {
    console.log(`El pedido contiene el plato de ${this.plato}, en cantidad de ${this.cantidad}, con un monto de ${this.precio}`);
  }
  //metodo valorPedido
  valorPedido() {
    const total = this.cantidad * this.precio;
    console.log(`Total del plato ${this.plato}: $${total}`);
  }

  //metodo descuentoPedido
  descuentoPedido() {
    if (this.cantidad >= 2 && this.precio > 50000) {
      const descuento = this.precio * 0.10;
      const precio_final = this.precio - descuento;
      console.log(`Se aplica un descuento de $${descuento}. El precio final es $${precio_final}.`);
    } else {
      console.log(`No aplica descuento para el pedido de ${this.plato}.`);
    }
  }



}


class RestauranteDomicilio extends Restaurante {
  constructor(plato, cantidad, precio, tiempo_entrega, valor_domicilio) {
    super(plato, cantidad, precio);
    this.tiempo_entrega = tiempo_entrega;
    this.valor_domicilio = valor_domicilio;
  }

  //metodo informacionRestaurante
  informacionRestaurante() {
    console.log(`Este restaurante tiene muy buena reputación ya que ${this.tiempo_entrega} es el tiempo de entrega promedio y una gran variedad de platos.`);
  }




  //sobreescritura del metodo valorPedido
  valorPedido() {
    const total = (this.cantidad * this.precio) + this.valor_domicilio;
    console.log(`Total del plato con domicilio incluido: $${total}`);
  }


  //metodo tiempoEntrega

  tiempoEntrega() {
    console.log(`El tiempo de entrega para el pedido de ${this.plato} es de ${this.tiempo_entrega}.`);
  }

};




// const pedido1 = new RestauranteDomicilio('Salmón rosado Alemán con caviar negro', 1, 300000, 10, 10000);
// const pedido2 = new RestauranteDomicilio('Trufas de Madagascar a la frangCua', 3, 70000, 10, 10000);
// const pedido3 = new RestauranteDomicilio('Arepas Reina Pepiada', 5, 40000, 10, 10000)



// console.log("--------------------------------------------------------------------------------------------------------------".rainbow)
// pedido1.pedidoRestaurante();
// pedido1.valorPedido();
// pedido1.descuentoPedido();
// pedido1.informacionRestaurante();
// pedido1.valorPedido();
// pedido1.tiempoEntrega();
// console.log("--------------------------------------------------------------------------------------------------------------".rainbow)




// console.log("--------------------------------------------------------------------------------------------------------------".rainbow)
// pedido2.pedidoRestaurante();
// pedido2.valorPedido();
// pedido2.descuentoPedido();
// pedido2.informacionRestaurante();
// pedido2.valorPedido();
// pedido2.tiempoEntrega();
// console.log("--------------------------------------------------------------------------------------------------------------".rainbow)




// console.log("--------------------------------------------------------------------------------------------------------------".rainbow)
// pedido3.pedidoRestaurante();
// pedido3.valorPedido();
// pedido3.descuentoPedido();
// pedido3.informacionRestaurante();
// pedido3.valorPedido();
// pedido3.tiempoEntrega();
// console.log("--------------------------------------------------------------------------------------------------------------".rainbow)


export default Restaurante;