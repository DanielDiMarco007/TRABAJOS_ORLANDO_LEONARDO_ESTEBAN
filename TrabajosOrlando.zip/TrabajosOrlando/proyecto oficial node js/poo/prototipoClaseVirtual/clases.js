// definir la clase Persona
class Persona {
    //metodo constructor
    constructor(nombres, apellidos, edad) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.edad = edad;
    }



    //metodo nombre Completo
    nombreCompleto() {
        return `${this.nombres}  ${this.apellidos}`
    };




    nombreedad() {
        return `${this.nombres}  tiene   ${this.edad}  años`
    };

};


// //instanciar la clase Persona
// const persona1 = new Persona("Juan", "Pérez", 30);

// console.log(persona1.nombreCompleto()); // Output: Juan Pérez
// console.log(persona1.nombreedad()); // Output: Juan tiene 30 años
// console.log(persona1);



// definir la clase Aprendiz que hereda de Persona
class Aprendiz extends Persona {
    //metodo constructor
    constructor(nombres, apellidos, edad, ficha, programa,fechaInicio,fechaFinal) {
        super(nombres, apellidos, edad);
        this.ficha = ficha;
        this.programa = programa;
        this.fechaInicio = fechaInicio;
        this.fechaFinal = fechaFinal;
    };


//plomorfismo que sobreescribe el metodo nombreCompleto
    nombreCompleto() {
        return `Aprendiz: ${this.nombres}  ${this.apellidos}`
    }
 //metodo datosAprendiz
    datosAprendiz() {
        return `El aprendiz ${this.nombres}${this.apellidos} con ficha ${this.ficha} está inscrito en el programa ${this.programa} desde ${this.fechaInicio} hasta ${this.fechaFinal}.`
    };




};

// // instanciar la clase Aprendiz
// const aprendiz1 = new Aprendiz("Ana", "Gómez", 22, "123456", "Desarrollo de Software", "2024-01-15", "2024-12-15");

// console.log(aprendiz1.nombreCompleto());
// console.log(aprendiz1.datosAprendiz());
// console.log(aprendiz1.nombreedad());
// console.log(aprendiz1);



class AprendizEtapaPractica extends Aprendiz {
    constructor(nombres, apellidos, edad, ficha, programa, fechaInicio, fechaFinal, empresa, duracionPractica) {
        super(nombres, apellidos, edad, ficha, programa, fechaInicio, fechaFinal);
        this.empresa = empresa;
        this.duracionPractica = duracionPractica;
    }   

    datosAprendiz () {
        return `El aprendiz ${this.nombres} ${this.apellidos} con ficha ${this.ficha} está inscrito en el programa ${this.programa} desde ${this.fechaInicio} hasta ${this.fechaFinal}. Realizará su práctica en la empresa ${this.empresa} por una duración de ${this.duracionPractica} meses.`;
    };
    
    
    
    //polimorfismo nombreCompleto
    nombreCompleto () {
        return `Aprendiz en etapa de práctica: ${this.nombres}  ${this.apellidos}`;
    };
}

//polimorfismo datosAprendiz


//  instanciar la clase AprendizEtapaPractica
 const aprendizPractica1 = new AprendizEtapaPractica("Luis", "Martínez", 24, "654321", "Análisis de Sistemas", "2024-02-01", "2024-11-30", "Tech Solutions", 6);

console.log(aprendizPractica1.nombreCompleto());
console.log(aprendizPractica1.datosAprendiz());
console.log(aprendizPractica1.nombreedad());
console.log(aprendizPractica1);

