//Definición de la Clase Computador
class Computador {

    //Atributos Privados
    #codigo;
    #marca;
    #modelo;
    #anno;
    #descripcion;
    #serial;
    #precio;
    #iva; //Porcentage del Impuesto al Valor Agregadoge. Valor entre 0 y 1
    #descuento; //Porcentage de descuento entre 0 y 1

    //Método Constructor con valores de inicio
    constructor() {
        this.#codigo = "CP0000";
        this.#marca = "";
        this.#modelo = "";
        this.#anno = 0;
        this.#descripcion = "";
        this.#serial = "SRL0000";
        this.#precio = 0.0;
        this.#iva = 0.19; //19% IVA por defecto
        this.#descuento = 0.0; //0% descuento por defecto
    };

    //Métodos Getters y Setters
    //Código
    //Metodo Getter: Obtiene el valor del atributo código
    get codigo() {
        return this.#codigo;
    };

    //Metodo Setter: Establece el valor del atributo código
    set codigo(codigo) {
        this.#codigo = codigo;
    };

    //Marca
    //Metodo Getter: Obtiene el valor del atributo marca
    get marca() {
        return this.#marca;
    };

    //Metodo Setter: Establece el valor del atributo marca
    set marca(marca) {
        this.#marca = marca;
    };

    //Modelo
    //Metodo Getter: Obtiene el valor del atributo modelo
    get modelo() {
        return this.#modelo;
    };

    //Metodo Setter: Establece el valor del atributo modelo
    set modelo(modelo) {
        this.#modelo = modelo;
    };

    //Año
    //Metodo Getter: Obtiene el valor del atributo año
    get anno() {
        return this.#anno;
    };

    //Metodo Setter: Establece el valor del atributo año
    set anno(anno) {
        this.#anno = anno;
    };

    //Descripción
    //Metodo Getter: Obtiene el valor del atributo descripción
    get descripcion() {
        return this.#descripcion;
    };

    //Metodo Setter: Establece el valor del atributo descripción
    set descripcion(descripcion) {
        this.#descripcion = descripcion;
    };

    //Serial
    //Metodo Getter: Obtiene el valor del atributo serial
    get serial() {
        return this.#serial;
    };

    //Metodo Setter: Establece el valor del atributo serial
    set serial(serial) {
        this.#serial = serial;
    };

    //Precio
    //Metodo Getter: Obtiene el valor del atributo precio
    get precio() {
        return this.#precio;
    };

    //Metodo Setter: Establece el valor del atributo precio
    set precio(precio) {
        this.#precio = precio;
    };

    //IVA
    //Metodo Getter: Obtiene el valor del atributo iva
    get iva() {
        return this.#iva;
    };

    //Metodo Setter: Establece el valor del atributo iva
    set iva(iva) {
        this.#iva = iva;
    };

    //Descuento
    //Metodo Getter: Obtiene el valor del atributo descuento
    get descuento() {
        return this.#descuento;
    };

    //Metodo Setter: Establece el valor del atributo descuento
    set descuento(descuento) {
        this.#descuento = descuento;
    };

    //Metodo para calcular el precio final del computador
    calcularPrecioFinal() {
        const precioConIva = this.#precio + (this.#precio * this.#iva);
        const precioFinal = precioConIva - (this.#precio * this.#descuento);
        return precioFinal;
    };

    //Método para mostrar la información del computador
    mostrarInfo() {
        return `Código: ${this.#codigo}\nMarca: ${this.#marca}\nModelo: ${this.#modelo}\n
                Año: ${this.#anno}\nDescripción: ${this.#descripcion}\n
                Serial: ${this.#serial}\nPrecio: $${this.#precio.toFixed(2)}\n
                IVA: ${(this.#iva * 100).toFixed(2)}%\n
                Descuento: ${(this.#descuento * 100).toFixed(2)}%\n
                Precio Final: $${this.calcularPrecioFinal().toFixed(2)}`;
    };
};



//definicion clase smartphone

class Smartphone {





    #serial;
    #pantalla;
    #resolucion;
    #procesador;
    #ram;
    #conectividad;
    #diagnostico;



    //metodo constructor con valores de inicio


    constructor() {
        this.#serial = "SPH0000";
        this.#pantalla = "";
        this.#resolucion = "";
        this.#procesador = "";
        this.#ram = "";
        this.#conectividad = [];
        this.#diagnostico = "";


    }

    //metodos getters y setters
    //serial
    get serial() {
        return this.#serial;
    };

    set serial(serial) {
        this.#serial = serial;
    };

    //pantalla
    get pantalla() {
        return this.#pantalla;
    };
    set pantalla(pantalla) {
        this.#pantalla = pantalla;
    };

    //resolucion
    get resolucion() {
        return this.#resolucion;
    };
    set resolucion(resolucion) {
        this.#resolucion = resolucion;
    };
    //procesador
    get procesador() {
        return this.#procesador;
    };
    set procesador(procesador) {
        this.#procesador = procesador;
    };

    //ram
    get ram() {
        return this.#ram;
    };
    set ram(ram) {
        this.#ram = ram;
    };

    //conectividad
    get conectividad() {
        return this.#conectividad;
    };
    set conectividad(conectividad) {
        this.#conectividad = conectividad;
    };

    //diagnostico
    get diagnostico() {
        return this.#diagnostico;
    };
    set diagnostico(diagnostico) {
        this.#diagnostico = diagnostico;
    };


    //metodo para mostrar la informacion del smartphone    
    mostrarInfo() {
        return `Serial: ${this.#serial}\n
                Pantalla: ${this.#pantalla}\n
                Resolución: ${this.#resolucion}\n
                Procesador: ${this.#procesador}\n
                RAM: ${this.#ram}\n
                Conectividad: ${this.#conectividad.join(', ')}\n
                Diagnóstico: ${this.#diagnostico}`;
    };

};


//difinir la clase que contiene metodos estaticos

class Utilidades {

    //metodo estatico para validar el serial de un dispositivo
    static validarSerial(serial) {
        const SerialPattern = /^[A-Z]{3}\d{4}$/;
        return SerialPattern.test(serial);
    }

  
    static mostrarMenu(title, options, width = 60) {
        console.clear();
        
        const emptyLine = " ".repeat(width);

        // Encabezado
        console.log(emptyLine.bgGreen);
        //   console.log(
        //     "  ".bgGreen + 
        //       title.padStart((width - 2 + title.length) / 2).padEnd(width - 4) +
        //       "  ".bgGreen
        //   );
        console.log(
            "  ".bgGreen + " ".repeat(Math.floor((width - 4 - title.length)/2)) +
            title + " ".repeat((width - 4 - title.length) - Math.floor((width - 4 - title.length)/2)) +
            "  ".bgGreen
        );
        console.log(emptyLine.bgGreen);

        // Opciones numeradas
        options.forEach((opt, index) => {
            const line = `${String(index + 1).green}.  ${opt}`;
            console.log(
            "  ".bgGreen +
                "      " +
                line + " ".repeat(width - line.length) +
                "  ".bgGreen
            );
        });

        // Espacio + opción de salida
        console.log("  ".bgGreen + " ".repeat(width - 4) + "  ".bgGreen);
        const line = `${"0".green}.  Cerrar APP`;
        console.log(
            "  ".bgGreen +
            "      " +
            line + " ".repeat(width - line.length) +
            "  ".bgGreen
        );

        // Pie
        console.log(emptyLine.bgGreen);
    };
};











//Exportación de las clases
//definir objeto para exportar las clases
const clases = {
     Computador,
     Smartphone,
     Utilidades

};

//exportar el objeto clases
export default clases;
