/*

centro de biotecnología agropecuario
ficha 3293689
tecnologo en análisis y dasarrollo de software
autor: daniel di marco
fecha: 11-09-2025
descripción:programa con operaciones matematicas basicas 


*/


import operaciones from "./my_modules/funciones.js";
import colors from 'colors';
import readlineSync from "readline-sync";
import { PlantillaSuma } from "./plantilla_suma.js";
 


let dato2 = 0;
let continuar = 0

do{
  const dato1 = parseFloat(readlineSync.question('digite el primer numero: '));
 do{
    
    
    dato2 =  parseFloat(readlineSync.question('digite el segundo numero: '));

   }while(dato2===0);

   //diseño interfaz de usuario (ui)
  PlantillaSuma(dato1,dato2);

   

   continuar  = parseInt(readlineSync.question('digite 0 para finalizar / enter para continuar '));
} while (continuar !==0);


console.log(colors.bgWhite('======================================================='));
console.log('                          FINALIZADO                   '.bgRed)
console.log(colors.bgWhite('======================================================='));

