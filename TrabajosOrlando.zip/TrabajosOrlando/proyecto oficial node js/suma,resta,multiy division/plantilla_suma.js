import operaciones from "./my_modules/funciones.js";
import colors from "colors";

// Plantilla para mostrar operaciones matemáticas en un recuadro alineado y coloreado
export function PlantillaSuma(dato1, dato2, tamano = 50) {
  const emptyLine = ' '.repeat(tamano);
  console.log(emptyLine.bgWhite);

  // Título centrado en recuadro blanco
  const titulo = `Operaciones Matemáticas`;
  console.log(
    "  ".bgWhite +
    " ".repeat(Math.floor(tamano - 4 - titulo.length) / 2) +
    titulo +
    " ".repeat(tamano - 4 - titulo.length - Math.floor((tamano - 4 - titulo.length) / 2)) +
    "  ".bgWhite
  );
  console.log(emptyLine.bgWhite);

  

  // Cuerpo de operaciones, alineado como opciones
  const espacio = 7;
  const operacionesArr = [
    `suma: ${dato1} + ${dato2} = ${operaciones.sumar(dato1, dato2)}`,
    `resta: ${dato1} - ${dato2} = ${operaciones.resta(dato1, dato2)}`,
    `multiplicación: ${dato1} * ${dato2} = ${operaciones.multiplicacion(dato1, dato2)}`,
    `división: ${dato1} / ${dato2} = ${operaciones.division(dato1, dato2)}`
  ];

  operacionesArr.forEach((linea) => {
    const espaciosFinal = Math.max(tamano - espacio - 4 - linea.length, 0);
    console.log(
      "  ".bgWhite +
      " ".repeat(espacio) +
      linea.green +
      " ".repeat(espaciosFinal) +
      "  ".bgWhite
    );
  });

  // Línea final
  console.log(emptyLine.bgWhite);
}