import colors from 'colors';
import readline from 'readline-sync';
import presentacion from './my_modules/funciones.js';
const nombre_correcto='DANIEL ELIAS DI MARCO BORGES';
const continuar=true;

const nombre = readline.question('Escriba el nombre completo de daniel para ver su presentacion: ');

if (nombre === nombre_correcto) {
    console.log('Nombre correcto. Mostrando presentación...\n'.green);
    presentacion.presentacion();
} else {

    console.log('Nombre incorrecto. No se puede mostrar la presentación.'.red);
  
}




