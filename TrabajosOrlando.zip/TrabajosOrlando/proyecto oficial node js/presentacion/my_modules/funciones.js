import colors from 'colors';
import readline from 'readline-sync';





function presentacion() {
console.log('                                                '.bgGreen);
     console.log(`${'  '.bgGreen}     PRESENTACION                           ${'  '.bgGreen}`);
     console.log('                                                '.bgGreen);
     console.log(`${'  '.bgGreen}    NOMBRE: DANIEL ELIAS DI MARCO BORGES    ${'  '.bgGreen}      `);
     console.log(`${'  '.bgGreen}     EDAD : 18 AÑOS                         ${'  '.bgGreen}      `);
     console.log(`${'  '.bgGreen}     FICHA: 3293689                         ${'  '.bgGreen}      `);
     console.log(`${'  '.bgGreen} DIRECCION: CRA12b#9c-75                    ${'  '.bgGreen}      `);
     console.log(`${'  '.bgGreen}  TELEFONO: 3215480094                      ${'  '.bgGreen}      `);
     console.log(`${'  '.bgGreen} DOCUMENTO: 5080425                         ${'  '.bgGreen}      `);







     console.log('                                                '.bgGreen);
    
}export default { presentacion };