import colors from 'colors';
import {tablaMultiplicar } from './my_modules/funciones.js';




//=================>PLANTILLA TABLA MULTIPLICAR<=====================
function MultiplicarPlantilla(numero, tamano = 30) {
   const emptyLine = ' '.repeat(tamano);
   console.log(emptyLine.bgWhite);

   // Título centrado en recuadro blanco
   const titulo = `Tabla del ${numero}`;
   console.log(
      "  ".bgWhite +
      " ".repeat(Math.floor(tamano - 4 - titulo.length) / 2) +
      titulo +
      " ".repeat(tamano - 4 - titulo.length - Math.floor((tamano - 4 - titulo.length) / 2)) +
      "  ".bgWhite
   );
   console.log(emptyLine.bgWhite);

   // Cuerpo de la tabla, alineado como opciones
   const espacio = 7;
   for (let i = 1; i <= 10; i++) {
      const resultado = numero * i;
      const linea = `${numero} x ${i} = ${resultado}`;
      console.log(
         "  ".bgWhite +
         " ".repeat(espacio) +
         linea.green +
         " ".repeat(tamano - espacio - 4 - linea.length) +
         "  ".bgWhite
      );
   }

   // Línea final
   console.log(emptyLine.bgWhite);
}

export { MultiplicarPlantilla };





