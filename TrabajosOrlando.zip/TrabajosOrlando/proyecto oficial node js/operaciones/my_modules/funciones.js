

import colors from "colors";
let numero;
export function tablaMultiplicar(numero) {
  console.log(`${'                       '.bgWhite}`)
  console.log(`${'  '.bgWhite}  Tabla del  ${numero}:      ${'  '.bgWhite}`);
  for (let i = 1; i <= 10; i++) {
    const resultado = numero * i;
    console.log(`${'  '.bgWhite}    ${numero} x ${i} = ${resultado}    ${'  '.bgWhite}`.green);
  }
}




