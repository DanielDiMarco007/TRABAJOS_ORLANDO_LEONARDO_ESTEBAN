

import readlineSync from "readline-sync";
import colors from "colors";
import {MultiplicarPlantilla } from "./plantilla_multiplicar.js";


let continuarPrograma = true;

while (continuarPrograma) {
  console.log('\n================='.rainbow, 'Tabla de Multiplicar'.bgGreen,    ' ===================\n'.rainbow);
  const inicial = parseInt(readlineSync.question('\nDigite la tabla inicial: '), 10);
  const final = parseInt(readlineSync.question('Digite la tabla final: '), 10);

  let tabla = inicial;
  let continuar = true;

  if (inicial <= final) {
    // ASCENDENTE
    while (tabla <= final && continuar) {
  MultiplicarPlantilla(tabla);

      const respuesta = readlineSync.question(
        '\nPresione Enter para continuar o escriba "0" para finalizar: '
      );

      if (respuesta.trim() === '0') {
        console.log('\nProceso finalizado por el usuario.'.red);
        continuar = false;
        continuarPrograma = false;
      } else {
        tabla++;
      }
    }
  } else {
    // DESCENDENTE
    while (tabla >= final && continuar) {
  MultiplicarPlantilla(tabla);

      const respuesta = readlineSync.question(
        '\nPresione Enter para continuar o escriba "0" para finalizar: '.cyan
      );

      if (respuesta.trim() === '0') {
        console.log('\nProceso finalizado por el usuario.'.red);
        continuar = false;
        continuarPrograma = false;
      } else {
        tabla--;
      }
    }
  }

  // Si terminó todas las tablas y no se salió con "0"
  if (continuarPrograma) {
    const repetir = readlineSync.question(
      '\n  ¿Desea calcular otra tabla? Presione Enter para continuar o escriba "0" para salir: '.cyan
   );

    if (repetir.trim() === '0') {
      console.log('\nGracias por usar el programa. ¡Hasta pronto!'.yellow);
      continuarPrograma = false;
    }
  }
}








