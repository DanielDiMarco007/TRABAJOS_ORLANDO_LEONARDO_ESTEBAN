// Crea una clase Vehiculo con marca, modelo y año.
// Luego crea 3 objetos distintos y muéstralos en consola con un método mostrarInfo().

// // 📌 Ejemplo:


class vehiculo {

    constructor(marca, modelo, año) {

        this.marca = marca;
        this.modelo = modelo;
        
        this.año = año;

    }


    //metodo mostrarinfo

    mostrarinfo() {

     console.log(`${this.marca},${this.modelo},${this.año}`)


    }


}

const v1 = new vehiculo ('chevrolet','camaro','2020')



v1.mostrarinfo();


const v2 = new vehiculo ('chevrolet','aveo','2020')
v2.mostrarinfo();
const v3 = new vehiculo ('mazda','626','2000')
v3.mostrarinfo();