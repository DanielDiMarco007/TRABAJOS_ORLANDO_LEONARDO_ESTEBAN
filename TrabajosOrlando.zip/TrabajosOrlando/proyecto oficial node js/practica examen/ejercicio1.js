class Persona {

    constructor(nombre, edad) {

        this.nombre = nombre;
        this.edad = edad;

    }

    //metodo saludo 

    saludo() {

        return `hola mi nombre es ${this.nombre} y tengo ${this.edad} años`


    }


}
// const persona1 =new Persona('daniel','18')


// console.log(persona1.saludo());


class Trabajador extends Persona {
    
    constructor(nombre,cargo) {

        super(nombre);


        this.cargo = cargo;





    }

    //metodo trabajar

    trabajar() {
        console.log( `hola mi nombre es ${this.nombre}, y soy ${this.cargo} :)`)

    }

}

const trabajador1 = new Trabajador ('Daniel','mecanico')

trabajador1.trabajar();