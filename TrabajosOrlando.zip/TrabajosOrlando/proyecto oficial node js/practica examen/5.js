// Usa readline-sync para pedirle al usuario:

// Su nombre

// Su edad

// Y crea un objeto de la clase Persona (de la pregunta 1) que se presente con el método presentarse().



import readlineSync from 'readline-sync'




class Usuario {

    constructor(nombre, edad) {

        this.nombre = nombre;

        this.edad = edad;


    }


    //metodos

    Info() {
  console.log(`hola mi nombre es ${this.nombre} y tengo ${this.edad}`)
    }
    

}



const nombre = readlineSync.question(`ingresa tu nombre: `)

const edad = readlineSync.question(`ingresa tu edad : `)


const usuario1 = new Usuario (nombre,edad);


usuario1.Info();