class CuentaBancaria {
  #saldo;

  constructor(saldoInicial = 0) {
    this.#saldo = saldoInicial;
  }

  // Getter
  get saldo() {
    return this.#saldo;
  }

  // Setter con validación
  set saldo(nuevoSaldo) {
    if (nuevoSaldo >= 0) {
      this.#saldo = nuevoSaldo;
    } else {
      console.log('Error: el saldo no puede ser negativo.');
    }
  }

  // Método extra para mostrar el saldo
  mostrarSaldo() {
    console.log(`Saldo actual: $${this.#saldo}`);
  }
}

const cuenta1 = new CuentaBancaria(500);

cuenta1.saldo = -200;     // ❌ Error: el saldo no puede ser negativo.

