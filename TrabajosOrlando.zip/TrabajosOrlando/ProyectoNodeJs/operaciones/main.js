/*

centro de biotecnología agropecuario
ficha 3293689
tecnologo en análisis y dasarrollo de software
autor: daniel di marco
fecha: 11-09-2025
descripción:programa con operaciones matematicas basicas 


*/


import operaciones from "./my_modules/funciones.js";
import colors from 'colors';
import readlineSync from "readline-sync";
 


let dato2 = 0;
let continuar = 0

do{
  const dato1 = parseFloat(readlineSync.question('digite el primer numero: '));
 do{
    
    
    dato2 =  parseFloat(readlineSync.question('digite el segundo numero: '));

   }while(dato2===0);

   //diseño interfaz de usuario (ui)
   console.log(colors.bgGreen('======================================================='));
   console.log('           DANIEL DI MARCO                             '.blue.bgWhite)
   console.log(colors.bgGreen('======================================================='));
   console.log('suma:'.blue ,`${dato1}+${dato2} = ${operaciones.sumar(dato1,dato2)}  `);
   console.log('resta:'.cyan,`${dato1}-${dato2} = ${operaciones.resta(dato1,dato2)}  `);
   console.log('multiplicacion:'.yellow,`${dato1}*${dato2} = ${operaciones.multiplicacion(dato1,dato2)}  `);
   console.log('division:'.rainbow,`${dato1}/${dato2} = ${operaciones.division(dato1,dato2)}  `);
   console.log(colors.bgGreen('======================================================='));

   console.log(colors.bgGreen('======================================================='));

   continuar  = parseInt(readlineSync.question('digite 0 para finalizar / enter para continuar '));
} while (continuar !==0);


console.log(colors.bgWhite('======================================================='));
console.log('                          FINALIZADO                   '.bgRed)
console.log(colors.bgWhite('======================================================='));

