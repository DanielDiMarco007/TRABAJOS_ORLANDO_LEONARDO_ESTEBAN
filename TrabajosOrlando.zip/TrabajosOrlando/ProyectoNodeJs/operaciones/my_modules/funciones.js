
/*

centro de biotecnología agropecuario
ficha 3293689
tecnologo en análisis y dasarrollo de software
autor: daniel di marco
fecha: 11-09-2025
descripción:modulo que contiene las funciones matemáticas básicas


*/

//DEFINE LA FUNCION PARA SUMAR DOS NÚMEROS
/*
function sumar(dato1,dato2){

return dato1 + dato2 ;


}

*/


const sumar=(dato1,dato2) => {
     return dato1 + dato2

    
    }
//DEFINE LA FUNCION PARA RESTAR DOS NÚMEROS

const resta=(dato1,dato2)=>{

return dato1 -dato2

}
//DEFINE LA FUNCION PARA MULTIPLICACION DOS NÚMEROS


const multiplicacion=(dato1,dato2)=>{

return dato1*dato2

}
//DEFINE LA FUNCION PARA DIVISION DOS NÚMEROS
const division=(dato1,dato2)=>{
if (dato2 === 0){

return( ' error no se puede dividir por cero');


}


else{

    return dato1/dato2;
}
}


//exportar funciones para que puedan ser usadas en otros archivos
const operaciones = {//cuando veamos  unas llavas{} es un objeto  y si vemos [] es una arreglo o lista
    sumar, 
    resta,
    multiplicacion,
    division
};

export default operaciones;