export  function suma(dato1,dato2,dato3){

return dato1 + dato2 + dato3;


}
export  function resta(dato1,dato2,dato3){

    return dato1 - dato2 - dato3;
    
    
    }
export  function multiplicacion(dato1,dato2,dato3){
 
  return dato1*dato2*dato3;
        
        
  }
  export  function division(dato1,dato2,dato3){

  return dato1 +dato2+ dato3 / 3;
 }