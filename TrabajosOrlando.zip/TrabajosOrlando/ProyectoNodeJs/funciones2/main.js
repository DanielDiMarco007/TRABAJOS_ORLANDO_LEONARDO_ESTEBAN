
import colors from'colors';
import {suma,multiplicacion,resta,division}from './my_modules/funciones.js'



let resultado;
 const dato1 = 3597850;
 const dato2 = 50785936;
 const dato3 = 393893495;


 resultado = (dato1 + dato2 + dato3)/3;

console.log = (`${funciones.suma(4,2,4)}`);