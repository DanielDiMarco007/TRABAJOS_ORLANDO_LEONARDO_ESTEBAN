// Ejercicio 2: Proyecto de Encapsulamiento 
// • Crear una clase CuentaBancaria con propiedades privadas: #documento, 
// #nombre, #apellidos, #tipoCuenta, #numeroCuenta, #saldo. 
// • Implementar métodos depositar, retirar y obtenerSaldo. 



class CuentaBancaria {
    #documento;
    #nombre;
    #apellidos;
    #tipoCuenta;
    #numeroCuenta;
    #saldo;

    constructor() {
        this.#documento = "";
        this.#nombre = "";
        this.#apellidos = "";
        this.#tipoCuenta = "";
        this.#numeroCuenta = "";
        this.#saldo = 0;
    }



    //metodos getters y setters

    //getter para documento
    get documento() {
        return this.#documento;
    }

    //setter para documento
    set documento(nuevodocumento) {
        this.#documento = nuevodocumento;
    }


    //getter para nombre
    get nombre() {
        return this.#nombre;
    }
    //setter para nombre
    set nombre(nuevonombre) {
        this.#nombre = nuevonombre;
    }

    //getter para apellidos
    get apellidos() {
        return this.#apellidos;
    }

    //setter para apellidos
    set apellidos(nuevoapellidos) {
        this.#apellidos = nuevoapellidos;
    }
    //getter para tipoCuenta
    get tipoCuenta() {
        return this.#tipoCuenta;
    }
    //setter para tipoCuenta
    set tipoCuenta(nuevotipoCuenta) {
        this.#tipoCuenta = nuevotipoCuenta;
    }

    //getter para numeroCuenta
    get numeroCuenta() {
        return this.#numeroCuenta;
    }
    //setter para numeroCuenta
    set numeroCuenta(nuevonumeroCuenta) {
        this.#numeroCuenta = nuevonumeroCuenta;
    }

    //getter para saldo
    get saldo() {
        return this.#saldo;
    }
    //setter para saldo
    set saldo(nuevosaldo) {
        this.#saldo = nuevosaldo;
    }




    //metodo para depositar
    depositar() {

        console.log(`Depositando ${this.saldo} en la cuenta ${this.#numeroCuenta}`);


    }




    //metodo para retirar
    retirar() {

        console.log(`Retirando ${this.saldo} de la cuenta ${this.#numeroCuenta}`);



    }



  obtenerSaldo() {
        console.log(`El saldo de la cuenta ${this.#numeroCuenta} es ${this.#saldo}`);
    }



}


const cuenta1 = new CuentaBancaria();
cuenta1.documento = "5080425";
cuenta1.nombre = "Daniel";
cuenta1.apellidos = "Di Marco";
cuenta1.tipoCuenta = "Ahorros";
cuenta1.numeroCuenta = "57585";
cuenta1.saldo = 90000000;
cuenta1.depositar();
cuenta1.retirar(`${cuenta1.saldo = 4000} `);
cuenta1.obtenerSaldo();



const clases = [CuentaBancaria,Circulo,Cuadrado];

export default clases;