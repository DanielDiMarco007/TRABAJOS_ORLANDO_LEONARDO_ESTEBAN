//menu de opciones
import readlineSync from 'readline-sync';
import clases from './my_modules/ejercicio2.js';
import figuras from './my_modules/ejercicio1.js';
import consola from './my_modules/ejercicio3.js';



//mostrar opciones
function mostrarMenu() {
console.log("1. Ejercicio 1: Proyecto de Polimorfismo y Herencia");
console.log("2. Ejercicio 2: Proyecto Clase Cuenta Bancaria");
console.log("3. Ejercicio 3: Proyecto Clase para mostrar resultados");
console.log("4. Salir");
}
      


const operaciones = [mostrarMenu];

export default operaciones;