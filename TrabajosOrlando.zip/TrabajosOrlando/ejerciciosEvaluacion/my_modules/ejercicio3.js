// Ejercicio 3: Proyecto Clase para mostrar resultados 
// • Diseñar una clase ConsolaResultados que imprima resultados en consola con 
// formato claro y legible. 
// • El método principal de la clase deberá recibir una lista (array) de objetos 
// pertenecientes a las clases Cuadrado o Circulo. 
// • El método deberá recorrer la lista y mostrar en pantalla el nombre de la figura 
// y el valor de su área, con dos decimales de precisión. 
import figuras from './ejercicio1.js';

class ConsolaResultados {

    mostrarResultados(listaFiguras) {
        listaFiguras.forEach(figura => {
            const nombreFigura = figura.constructor.name;
            const areaFigura = figura.calcularArea().toFixed(2);
            console.log(`Figura: ${nombreFigura}, Área: ${areaFigura}`);
        });



    }
}

const consola = [ConsolaResultados]