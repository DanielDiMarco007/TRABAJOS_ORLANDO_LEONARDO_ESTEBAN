// Ejercicio 1: Proyecto de Polimorfismo y Herencia 
// • Crear una clase abstracta Figura con método calcularArea(). 
// • Crear clases Cuadrado y Circulo que sobrescriban el método. 
// • Crear una función que reciba un arreglo de figuras y muestre sus áreas.



import readlineSync from 'readline-sync';

class Figura {


    //no hay constructor ya que es una clase abstracta

    //metodo calcularArea


    calcularArea() {
        const dato1 = readlineSync.questionInt("ingrese el primer dato: ");
        const dato2 = readlineSync.questionInt("ingrese el segundo dato: ");

        return dato1 * dato2;
    }

}
//clase cuadrado que hereda de figura

class Cuadrado extends Figura {

    calcularArea() {
        const lado = readlineSync.questionInt("ingrese el lado del cuadrado: ");
        return lado * lado;
    }
}

//clase circulo que hereda de figura
class Circulo extends Figura {

    calcularArea() {
        const radio = readlineSync.questionInt("ingrese el radio del circulo: ");
        return Math.PI * radio * radio;
    }

}


const figuras = [
    new Cuadrado(),
    new Circulo()
];


figuras.forEach(figura => {
    console.log("Área:", figura.calcularArea());
});


export default figuras;

