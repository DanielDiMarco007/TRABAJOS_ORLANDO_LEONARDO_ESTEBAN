//menú para mostrar los 3 ejercicios

import clases from "./my_modules/ejercicio2.js";
import figuras from "./my_modules/ejercicio1.js";
import consola from "./my_modules/ejercicio3.js";
import readlineSync from "readline-sync";
import operaciones from "./my_modules/funciones.js";


const option = readlineSync.questionInt(`Seleccione el ejercicio a ejecutar: `);


operaciones.mostrarMenu();
switch (option) {
    case 1:
        console.log("Ejecutando Ejercicio 1: Proyecto de Polimorfismo y Herencia");
        figuras.forEach(figura => {
            console.log("Área:", figura.calcularArea());
        });
        break;
    case 2:
        console.log("Ejecutando Ejercicio 2: Proyecto Clase Cuenta Bancaria");
        
        const cuenta1 = new clases.CuentaBancaria();
        cuenta1.documento = "5080425";
        cuenta1.nombre = "Daniel";
        cuenta1.apellidos = "Di Marco";
        cuenta1.tipoCuenta = "Ahorros";
        cuenta1.numeroCuenta = "57585";
        cuenta1.saldo = 90000000;
        cuenta1.depositar();
        cuenta1.retirar(`${cuenta1.saldo = 4000} `);
        cuenta1.obtenerSaldo();
        break;
    case 3:
        console.log("Ejecutando Ejercicio 3: Proyecto Clase para mostrar resultados");
        const consolaResultados = new consola[0]();
        consolaResultados.mostrarResultados(figuras);
        break;

    case 4:
        console.log("Saliendo del programa...");
        break;



    default:
        console.log("Opción no válida");
        break;






}