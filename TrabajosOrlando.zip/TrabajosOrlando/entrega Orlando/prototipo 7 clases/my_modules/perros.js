//AUTOR : DANIEL DI MARCO
//FICHA : 3293689
//descripcion:
//clase perro con sus respectivos metodos

//CLASE PADRE PERRO
function Perro(nombre, raza, altura) {
this.nombre = nombre;
this.raza = raza;
this.altura = altura;

}



//metodos del objeto perro
//metodo ladrar

Perro.prototype.ladrar = function() {
    console.log("El perro " + this.nombre + " esta ladrando");
}
//metodo comiendo
Perro.prototype.comer = function() {
    console.log("El perro " + this.nombre + " esta comiendo");
}
//metodo dormir
Perro.prototype.dormir = function() {
    console.log("El perro " + this.nombre + " esta durmiendo");
}


// exportacion del modulo perro

export default {Perro};



