//AUTOR : DANIEL DI MARCO
//FICHA : 3293689
//descripcion:
//clase telefono con sus respectivos metodos





//CLASE PADRE TELEFONO

function Telefono(pantalla, resolucion, procesador, ram, bateria, conectividad) {
    this.pantalla = pantalla;
    this.resolucion = resolucion;
    this.procesador = procesador;
    this.ram = ram;
    this.bateria = bateria;
    this.conectividad = conectividad;

}

//PRIMERA TANDA DE METODOS PARA INSTANCIAS DIFERENTES
Telefono.prototype.llamar = function () {
    console.log("Llamando a mamá...");
}

//metodo tomar foto
Telefono.prototype.foto = function () {
    console.log("Tomando una foto...(quedó chulisima)");

}
//metodo grabar video
Telefono.prototype.grabarVideo = function () {
    console.log("Grabando video... (no olvides sonreir)");
}
//metodo grabar audio
Telefono.prototype.grabarAudio = function () {
    console.log("Grabando audio...(voz clara y nítida)");
}
//metodo diseñar documentos
Telefono.prototype.diseñarDocumentos = function () {
    console.log("Diseñando documentos...(trabajo terminado)");
}

//metodo editar videos
Telefono.prototype.editarVideos = function () {
    console.log("Editando videos...(corte perfecto)");
}







//metodos del objeto telefono2
    Telefono.prototype.llamar2 = function () {
    console.log("Llamando a JuanMecánico...");
}

//metodo tomar foto
Telefono.prototype.foto2 = function () {
    console.log("Tomando una foto...(avisa el screamer jajaja que feo)");

}
//metodo grabar video
Telefono.prototype.grabarVideo2 = function () {
    console.log("Grabando video... ( uy no, confirmo re feo)");
}
//metodo grabar audio
Telefono.prototype.grabarAudio2 = function () {
    console.log("Grabando audio...(voz distorsionada)");
}
//metodo diseñar documentos
Telefono.prototype.diseñarDocumentos2 = function () {
    console.log("Diseñando documentos...(Pdf listo)");
}

//metodo editar videos
Telefono.prototype.editarVideos2 = function () {
    console.log("Editando videos...(mi loco , te quedaste sin espacio)");
}





// metodos telefono3


//metodo llamar
Telefono.prototype.llamar3 = function () {
    console.log("Llamando a Socio Oscar...");
}

//metodo tomar foto
Telefono.prototype.foto3 = function () {
    console.log("Tomando una foto...(Que hermoso que quedo)");

}
//metodo grabar video
Telefono.prototype.grabarVideo3 = function () {
    console.log("Grabando video... ( re fluido y claro)");
}
//metodo grabar audio
Telefono.prototype.grabarAudio3 = function () {
    console.log("Grabando audio...(voz de machote)");
}
//metodo diseñar documentos
Telefono.prototype.diseñarDocumentos3 = function () {
    console.log("Diseñando documentos...(excel listo)");
}

//metodo editar videos
Telefono.prototype.editarVideos3 = function () {
    console.log("Editando videos...(perate wey, me tardo un poco)");
}








//exportacion del modulo telefono
export default { Telefono };