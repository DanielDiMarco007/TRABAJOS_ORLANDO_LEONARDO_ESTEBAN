//AUTOR : DANIEL DI MARCO
//FICHA : 3293689
//descripcion:
//clase taza con sus respectivos metodos


function Taza (color, forma, tamaño){
this.color = color;
this.forma = forma;
this.tamaño = tamaño;


}


//metodos del objeto taza
Taza.prototype.Sostenerse= function(){
    console.log("La taza se esta sosteniendo, pero está que se cae");
}
//metodos del objeto taza
Taza.prototype.almacenar= function(){
    console.log( "esta taza tiene cafe, perfecto pa acompañarlo con pan");
}



//metodos del objeto taza
Taza.prototype.Sostenerse2= function(){
    console.log("La taza la tienen en la mano, si se le cae es porque es muy bobo");
}
//metodos del objeto taza
Taza.prototype.almacenar2= function(){
    console.log( "esta vaina tiene agua fria, perfecto pa esta calor tan mlp");
}


//metodos del objeto taza
Taza.prototype.Sostenerse3= function(){
    console.log("esta taza si esta bien puesta, no se va a caer");
}
//metodos del objeto taza
Taza.prototype.almacenar3= function(){
    console.log( "esta taza tiene jugo de naranja, perfecto pa la salud");
}





//exportacion del modulo taza
 export default {Taza};