//AUTOR : DANIEL DI MARCO
//FICHA : 3293689
//descripcion:
//clase usuario con sus respectivos metodos


//CLASE PADRE USUARIO
function Usuario(Nombres, Apellidos, Correo, Contraseña, Premium){
this.Nombres = Nombres;
this.Apellidos = Apellidos;
this.Correo = Correo;
this.Contraseña = Contraseña;
this.Premium = Premium;


}

//metodos prototipicos de la clase usuario

//primera tanda de metodos para instancias diferentes
//primer tanda de metodos para la primera estancia
Usuario.prototype.iniciarSesion = function(){
    console.log("El usuario ha iniciado sesion");
}
//metodo cerrar sesion
Usuario.prototype.cerrarSesion = function(){
    console.log("El usuario ha cerrado sesion");
}
//metodo editar perfil
Usuario.prototype.editarPerfil = function(){
    console.log("El usuario ha editado su perfil");

}
//metodo cambiar contraseña
Usuario.prototype.cambiarContraseña = function(){
    console.log("El usuario ha cambiado su contraseña");
}
//metodo pasar a premium
Usuario.prototype.pasarAPremium = function(){
    console.log("El usuario ha pasado a ser premium");
}
//metodo publicacion
Usuario.prototype.Publicacion = function(){
    console.log("El usuario ha realizado una publicacion");
}



//SEGUNDA TANDA DE METODOS PARA OTRAS INSTANCIAS DIFERENTES
Usuario.prototype.iniciarSesion1 = function(){
    console.log("El usuario ha iniciado sesion a las 5pm");
}//metodo cerrar sesion
Usuario.prototype.cerrarSesion1 = function(){
    console.log("El usuario ha cerrado sesion(byee)");
}//metodo editar perfil
Usuario.prototype.editarPerfil1 = function(){
    console.log("El usuario ha editado su perfil(actualizó su foto de perfil)");

}
//metodo cambiar contraseña
Usuario.prototype.cambiarContraseña1 = function(){
    console.log("El usuario ha cambiado su contraseña(=4343653)");
}
//metodo pasar a premium
Usuario.prototype.pasarAPremium1 = function(){
    console.log("El usuario ha pasado a ser premium(money, money $$$)");
}
//metodo publicacion
Usuario.prototype.Publicacion1 = function(){
    console.log("El usuario ha realizado una publicacion(LOL)");
}



//TERCERA TANDA DE METODOS PARA OTRAS INSTANCIAS DIFERENTES
//metodo iniciar sesion
Usuario.prototype.iniciarSesion2 = function(){
    console.log("El usuario ha iniciado sesion a las 3am(insomnio)");
}
//metodo cerrar sesion
Usuario.prototype.cerrarSesion2 = function(){
    console.log("El usuario ha cerrado sesion(nunca lo vamos a extrañar)");
}
//metodo editar perfil
Usuario.prototype.editarPerfil2 = function(){
    console.log("El usuario ha editado su perfil(actualizó su biografía)");

}
//metodo cambiar contraseña
Usuario.prototype.cambiarContraseña2 = function(){
    console.log("El usuario ha cambiado su contraseña(=00101010292)");
}
//metodo pasar a premium
Usuario.prototype.pasarAPremium2 = function(){
    console.log("El usuario ha pasado a ser premium(vip vip vip)");
}
//metodo publicacion
Usuario.prototype.Publicacion2 = function(){
    console.log("El usuario ha realizado una publicacion(anda sad el chico :(");
}







//exportacion del modulo usuario
export default {Usuario};