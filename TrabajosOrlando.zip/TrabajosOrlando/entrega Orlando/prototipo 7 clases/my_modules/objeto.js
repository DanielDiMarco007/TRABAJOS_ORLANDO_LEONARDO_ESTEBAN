// los objetos en JS= claves y valores

//definicion de un objeto
const aprendiz1 = {
    //atributos o propiedades = clave: valor
    nombre: 'Juan',
    apellido: 'Perez',
    edad: 18,
    lenguajes: ['javascript', 'html', 'css'],

    //metodos = funciones dentro de un objeto
    saludar: function() {
        console.log('Hola, mi nombre es ' + this.nombre + ' ' + this.apellido);
    },
    despedirse() {
        console.log('Adios, nos vemos pronto');
    },
    aprendido: function(lenguaje) {
        this.lenguajes.push(lenguaje);
        console.log('He aprendido ' + this.lenguaje);
    },

};
console.log(aprendiz1);
aprendiz1.saludar();
aprendiz1.aprendido('Python');
aprendiz1.aprendido('java');
aprendiz1.despedirse();

console.log(aprendiz1);

//funciones constructoras de objetos
function Aprendiz(nombre, apellido, edad) {
    this.nombre = nombre;
    this.apellido = apellido;
    this.edad = edad;
    this.lenguajes = [];
};

//crearinstancias de objetos

const aprendiz2 = new Aprendiz('Maria', 'Gomez', 20);
console.log(aprendiz2);

const aprendiz3 = new Aprendiz('Carlos', 'Lopez', 22);
console.log(aprendiz3);

//agregar metodos al prototipo del objeto
//metodo saludar: saluda al usuario en el frontend

Aprendiz.prototype.saludar = function() {
    console.log('Hola, mi nombre es ' + this.nombre + ' ' + this.apellido);
};

//metodo aprendido: agrega un lenguaje al array de lenguajes e informa que lo aprendio

Aprendiz.prototype.aprendido = function(lenguaje) {
    this.lenguajes.push(lenguaje);
    console.log('He aprendido ' + lenguaje);
};

//metodo despedirse: se despide del usuario en el frontend

Aprendiz.prototype.despedirse = function() {
    console.log('Adios, nos vemos pronto');
};


//usar los metodos
//aprendiz2
aprendiz2.saludar();
aprendiz2.aprendido('Ruby');
aprendiz2.despedirse();
//aprendiz3
aprendiz3.saludar();
aprendiz3.aprendido('C#');
aprendiz3.despedirse();
//mostrar los objetos actualizados
console.log(aprendiz2);
console.log(aprendiz3);