//AUTOR : DANIEL DI MARCO
//FICHA : 3293689
//descripcion:
//clase mamifero con sus respectivos metodos

//CLASE PADRE MAMIFERO
function MamiferoT(nombre , especie, edad, color) {
    this.nombre = nombre;
    this.especie = especie;
    this.edad = edad;
    this.color = color;
}


//metodos del objeto mamifero
//metodo correr

MamiferoT.prototype.correr = function() {
    console.log("El mamifero " + this.nombre + " esta corriendo");
}
//metodo dormir
MamiferoT.prototype.dormir = function() {
    console.log("El mamifero " + this.nombre + " esta durmiendo");
}
//metodo comer
MamiferoT.prototype.comer = function() {
    console.log("El mamifero " + this.nombre + " esta comiendo");
}

// Exportar solo la definición; instancias y logs se harán desde main.js cuando el usuario lo solicite.
export default {MamiferoT};