//AUTOR : DANIEL DI MARCO
//FICHA : 3293689
//descripcion:
//clase jugador con sus respectivos metodos


//CLASE PADRE JUGADOR
function Jugador(velocidad, presicion,energia, nombre, apellido, edad,posicion) {
    this.velocidad = velocidad;
    this.presicion = presicion;
    this.energia = energia;
    this.nombre = nombre;
    this.apellido = apellido;
    this.edad = edad;
    this.posicion = posicion;
}



//metodos del objeto jugador
Jugador.prototype.cuadrado1= function(){
console.log("Kyliam Mbappe le pegó un tiro al arco... GOLAZOOOO!!! directo al angulo ");

}//metodos del objeto jugador
Jugador.prototype.X1= function(){
    console.log("Kyliam Mbappe hizo un pase corto a Messi... pase perfecto"); 
}

//metodos del objeto jugador
Jugador.prototype.O1= function(){
console.log("Kyliam Mbappe hizo un centro al área... cabezazo letal de Benzema, !tiro de esquina"); 
  }

//metodos del objeto jugador
Jugador.prototype.triangulo1= function(){
console.log("Kyliam Mbappe mete un pase entre líneas a Neymar... ¡qué jugador! "); 
}




//metodos del objeto jugador2
Jugador.prototype.cuadrado2= function(){
console.log("Pedri le pegó un tiro al arco... GOLAZOOOO!!! desde fuera del área ");      }
//metodos del objeto jugador2
Jugador.prototype.X2= function(){
console.log("Pedri se la pasa a Rashford... pase perfecto del mago"); 
}
//metodos del objeto jugador2
Jugador.prototype.O2= function(){
console.log("Pedri hizo un centro al área... !chilena de Lewandoski, que GOLAZOOOOOOOOOOOO!!!!!!!"); 
}
//metodos del objeto jugador2
Jugador.prototype.triangulo2= function(){
console.log("Pedri mete un pase entre líneas a Lamine... ¡pero que distinguido! "); 
}

//metodos del objeto jugador3
Jugador.prototype.cuadrado3= function(){
console.log("Lamine le pegó un tiro al arco... GOLAZOOOO!!! que efecto hagarró ese balon, Dios mio ");   }

//metodos del objeto jugador3
Jugador.prototype.X3= function(){
console.log("Lamine se la pasa al Tiburon Ferran... pase perfecto del crack"); 
}
//metodos del objeto jugador3
Jugador.prototype.O3= function(){
console.log("Lamine hizo un centro al área... !volea de Fermin Lopez, que GOLAZOOOOOOOOOOOO!!!!!!!"); 
  }
  //metodos del objeto jugador3
Jugador.prototype.triangulo3= function(){
console.log("Lamine mete un pase entre líneas a Pedri... ¡que clase tiene este niño! "); 
}


//exportacion del modulo jugador

export default {Jugador};