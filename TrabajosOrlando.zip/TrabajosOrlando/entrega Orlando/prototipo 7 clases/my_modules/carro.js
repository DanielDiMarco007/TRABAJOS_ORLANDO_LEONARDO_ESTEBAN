
//AUTOR : DANIEL DI MARCO
//FICHA : 3293689
//descripcion:
//clase carro con sus respectivos metodos



//Constructor de objetos
function Carro(marca, color, tipo, precio, puertas, combustible, cilindros, transimision) {



    this.marca = marca;
    this.color = color;
    this.tipo = tipo;
    this.precio = precio;
    this.puertas = puertas;
    this.combustible = combustible;
    this.cilindros = cilindros;
    this.transimision = transimision;

}







//metodos del objeto carro
  

// metodo encender
Carro.prototype.encender = function () {
    console.log("El carro " + this.marca + " esta encendido a pocas penas");
}
// metodo apagar
Carro.prototype.apagar = function () {
    console.log("El carro " + this.marca + " esta apagado (porfin descanza)");
}
// metodo avanzar
Carro.prototype.avanzar = function () {
    console.log("El carro " + this.marca + " esta avanzando ");
}
// metodo frenar
Carro.prototype.frenar = function () {
    console.log("El carro " + this.marca + " esta frenando");
}
// metodo reversa
Carro.prototype.reversa = function () {
    console.log("El carro " + this.marca + " esta en reversa ");
}



// TANDA DE METODOS PARA OTRAS INSTANCIAS DIFERENTES
Carro.prototype.encender1 = function () {
    console.log("El carro " + this.marca + " prendió de una vez");
}
// metodo apagar
Carro.prototype.apagar1 = function () {
    console.log("El carro " + this.marca + " esta apagado (que descanse el carro)");
}
// metodo avanzar
Carro.prototype.avanzar1 = function () {
    console.log("El carro " + this.marca + " esta avanzando a 60km/h ");
}
// metodo frenar
Carro.prototype.frenar1 = function () {
    console.log("El carro " + this.marca + " esta frenando poco a poco");
}
// metodo reversa
Carro.prototype.reversa1 = function () {
    console.log("El carro " + this.marca + " esta en reversa ");


}




// TANDA DE METODOS PARA OTRAS INSTANCIAS DIFERENTES
Carro.prototype.encender2 = function () {
    console.log("El carro " + this.marca + " prendió en ipsofacto");
}
// metodo apagar
Carro.prototype.apagar2 = function () {
    console.log("El carro " + this.marca + " esta apagado llegó a su destino");
}
// metodo avanzar
Carro.prototype.avanzar2 = function () {
    console.log("El carro " + this.marca + " esta avanzando a 30km/h ");
}
// metodo frenar
Carro.prototype.frenar2 = function () {
    console.log("El carro " + this.marca + " frenó de golpe");
}
// metodo reversa
Carro.prototype.reversa2 = function () {
    console.log("El carro " + this.marca + " esta en reversa despacio ");


}







// exportacion del modulo carro


export default { Carro };


