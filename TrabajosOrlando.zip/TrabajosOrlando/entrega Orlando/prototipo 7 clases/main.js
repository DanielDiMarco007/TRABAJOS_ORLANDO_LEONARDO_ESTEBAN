//AUTOR : DANIEL DI MARCO
//FICHA : 3293689
//descripcion:
//menu que muestra de manera ordenada 
//7 clases diferentes con sus respectivos metodos
//y permite al usuario navegar entre ellas
//hasta que decida salir del programa

import readlineSync from 'readline-sync';
import colors from 'colors';


import Carro from './my_modules/carro.js';
import MamiferoT from './my_modules/mamiferost.js';
import Perro from './my_modules/perros.js';
import Usuario from './my_modules/usuario.js';
import Telefono from './my_modules/telefono.js';
import Taza from './my_modules/taza.js';
import Jugador from './my_modules/jugador.js';
import mostrarPlantilla from './my_modules/plantilla.js';




// Variable para controlar si el programa sigue ejecutándose
let continuar = true;
const pausaEnter = (mensaje = "Presione Enter para continuar...") => {
    readlineSync.question(mensaje);
};

// ======================= MENÚ PRINCIPAL =========================
while (continuar) {

    // Encabezado del menú
    console.clear();
    console.log(colors.green("Bienvenido al menú de opciones de POO con JS"));
    console.log(colors.yellow("Seleccione una opción para ver las clases y métodos:"));

    // Plantilla visual para mostrar las opciones del menú
    mostrarPlantilla.mostrarPlantilla(
        "MENU DE OPCIONES",
        [
            "1) CLASE CARRO",
            "2) CLASE MAMIFERO",
            "3) CLASE PERRO",
            "4) CLASE USUARIO",
            "5) CLASE TELEFONO",
            "6) CLASE TAZA",
            "7) CLASE JUGADOR",
            "8) SALIR"
        ],
        80
    );

    // Usuario elige una opción
    const opcion = readlineSync.questionInt("Ingrese el número de la opción que desea ver: ");


    // switch de opciones del menú
    switch (opcion) {


        // ---------- OPCIÓN 1: CLASE CARRO1 ------------------------
        case 1:
            console.clear();
            console.log("                                       Clase Usuario y sus métodos :                                        ".bgGreen.white);
            //INSTANCIAS
            // Instanciamos 3 carros con diferentes datos
            const carro1 = new Carro.Carro("Toyota", "Rojo", "Sedan", 170000000, 4, "Gasolina", 4, "Automática");
            const carro2 = new Carro.Carro("Mitsubishi", "Verde", "Sedan", 52000000, 4, "Gasolina", 6, "Manual");
            const carro3 = new Carro.Carro("Ford Mustang", "Cherry Black", "Deportivo", 165000000, 2, "Diesel", 8, "Automática");
            //METODOS DE CARRO
            console.log("--------------------------------------------------CARROS--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            carro1.encender();
            carro1.avanzar();
            carro1.frenar();
            carro1.reversa();
            carro1.apagar();
            console.log(" ");
            console.log(" ");
pausaEnter();
            console.log("--------------------------------------------------CARRO2--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            carro2.encender1();
            carro2.avanzar1();
            carro2.frenar1();
            carro2.reversa1();
            carro2.apagar1();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------CARRO3--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            carro3.encender2();
            carro3.avanzar2();
            carro3.frenar2();
            carro3.reversa2();
            carro3.apagar2();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            break;



        // ---------- OPCIÓN 2: CLASE MAMIFERO ---------------------
        case 2:
            console.clear();
            console.log("                                       Clase Mamífero y sus métodos :                                        ".bgGreen.white);
            //INSTANCIAS
            const mamifero1 = new MamiferoT.MamiferoT("Leonardo", "León", 5, "Amarillo");
            const mamifero2 = new MamiferoT.MamiferoT("Marta", "Elefante", 10, "Gris");
            const mamifero3 = new MamiferoT.MamiferoT("Koko", "Gorila", 7, "Negro");
            //METODOS DE MAMIFERO
            console.log("--------------------------------------------------Mamifero1--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            mamifero1.correr();
            mamifero1.dormir();
            mamifero1.comer();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------Mamifero2--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            mamifero2.correr();
            mamifero2.dormir();
            mamifero2.comer();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------Mamifero3--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            mamifero3.correr();
            mamifero3.dormir();
            mamifero3.comer();
            break;



        // ---------- OPCIÓN 3: CLASE PERRO -------------------------
        case 3:
            console.clear();
            console.log("                                       Clase Perro y sus métodos :                                        ".bgGreen.white);

            //INSTANCIAS
            const perro1 = new Perro.Perro("Scooby", "Labrador", 3, "Marrón");
            const perro2 = new Perro.Perro("Hachi", "Pastor Alemán", 4, "Negro y Marrón");
            const perro3 = new Perro.Perro("Luna", "Husky", 2, "Blanco y Gris");
            //METODOS DE PERRO
            console.log("--------------------------------------------------Perro 1--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            perro1.ladrar();
            perro1.comer();
            perro1.dormir();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------perro 2--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            perro2.ladrar();
            perro2.comer();
            perro2.dormir();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------perro 3--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            perro3.ladrar();
            perro3.comer();
            perro3.dormir();
            console.log(" ");
            console.log(" ");
            break;



        // ---------- OPCIÓN 4: CLASE USUARIO -----------------------
        case 4:
            console.clear();

            //INSTANCIAS
            const usuario1 = new Usuario.Usuario("Juanito", "Godinez", "god@gmail.com", "12345", "si");
            const usuario2 = new Usuario.Usuario("Maria", "Lopez", "LopM@gmail.com", "54321", "no");
            const usuario3 = new Usuario.Usuario("Adrian", "Torres", "adrianconquistaT@gmail.com", "3254675", "si");
            //METODOS DE USUARIO
            console.log("--------------------------------------------------Usuarios--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");

            console.log("--------------------------------------------------Usuario1--------------------------------------------------".bgWhite.magenta);

            console.log(" ");
            usuario1.iniciarSesion();
            usuario1.editarPerfil();
            usuario1.cambiarContraseña();
            usuario1.pasarAPremium();
            usuario1.Publicacion();
            usuario1.cerrarSesion();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------Usuario2--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            usuario2.iniciarSesion1();
            usuario2.editarPerfil1();
            usuario2.cambiarContraseña1();
            usuario2.pasarAPremium1();
            usuario2.Publicacion1();
            usuario2.cerrarSesion1();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------Usuario3--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            usuario3.iniciarSesion2();
            usuario3.editarPerfil2();
            usuario3.cambiarContraseña2();
            usuario3.pasarAPremium2();
            usuario3.Publicacion2();
            usuario3.cerrarSesion2();
            console.log(" ");
            console.log(" ");
            break;



        // ---------- OPCIÓN 5: CLASE TELÉFONO -----------------------
        case 5:
            console.clear();
            console.log("                                       Clase Teléfono y sus métodos :                                        ".bgGreen.white);

            //INSTANCIAS
            const telefono1 = new Telefono.Telefono("6.5 pulgadas", "1080x2400", "Snapdragon 888", "8GB", "4500mAh", "Android 15");
            const telefono2 = new Telefono.Telefono("6.1 pulgadas", "1170x2532", "A15 Bionic", "6GB", "3095mAh", "iOS");
            const telefono3 = new Telefono.Telefono("6.6 pulgadas", "1080x2340", "Dimensity 1080 ", "8GB", "5000mAh", "Android 15");
            //METODOS DE TELEFONO
            console.log("--------------------------------------------------TELEFONOS--------------------------------------------------".bgWhite.magenta);

            console.log("--------------------------------------------------Telefono1--------------------------------------------------".bgWhite.magenta);

            console.log(" ");
            console.log(" ");
            telefono1.llamar();
            telefono1.foto();
            telefono1.grabarVideo();
            telefono1.grabarAudio();
            telefono1.diseñarDocumentos();
            telefono1.editarVideos();

            console.log(" ");
            console.log(" ");
            pausaEnter();

            console.log("--------------------------------------------------Telefono2--------------------------------------------------".bgWhite.magenta);

            console.log(" ");
            console.log(" ");
            telefono2.llamar2();
            telefono2.foto2();
            telefono2.grabarVideo2();
            telefono2.grabarAudio2();
            telefono2.diseñarDocumentos2();
            telefono2.editarVideos2();


            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------Telefono3--------------------------------------------------".bgWhite.magenta);

            console.log(" ");
            console.log(" ");
            telefono3.llamar3();
            telefono3.foto3();
            telefono3.grabarVideo3();
            telefono3.grabarAudio3();
            telefono3.diseñarDocumentos3();
            telefono3.editarVideos3();
            console.log(" ");
            console.log(" ");
            break;



        // ---------- OPCIÓN 6: CLASE TAZA --------------------------
        case 6:
            console.clear();
            console.log("                                       Clase Taza y sus métodos :                                        ".bgGreen.white);

            //INSTANCIAS
            const taza1 = new Taza.Taza("Blanca", "Cilíndrica", "Mediana");
            const taza2 = new Taza.Taza("Azul", "Cuadrada", "Grande");
            const taza3 = new Taza.Taza("Roja", "Rectangular", "Pequeña");
            //METODOS DE TAZA
            console.log("--------------------------------------------------TAZAS--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            console.log("--------------------------------------------------Taza1--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            taza1.Sostenerse();
            taza1.almacenar();

            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------Taza2--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");
            taza2.Sostenerse2();
            taza2.almacenar2();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------Taza3--------------------------------------------------".bgWhite.magenta);

            console.log(" ");
            console.log(" ");
            taza3.Sostenerse3();
            taza3.almacenar3();
            console.log(" ");
            console.log(" ");
            break;



        // ---------- OPCIÓN 7: CLASE JUGADOR ------------------------
        case 7:
            console.clear();
            console.log("                                       Clase Jugador y sus métodos :                                        ".bgGreen.white);
            //INSTANCIAS
            const jugador1 = new Jugador.Jugador(90, 95, 85, "Kylian", "Mbappé", 24, "Delantero");
            const jugador2 = new Jugador.Jugador(85, 100, 80, "Pedri", "González", 21, "Mediocampista");
            const jugador3 = new Jugador.Jugador(88, 92, 83, "Lamine", "Yamal", 18, "Extremo Derecho");
            //METODOS DE JUGADOR
            console.log("--------------------------------------------------Jugador 1--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");

            jugador1.cuadrado1();
            jugador1.X1();
            jugador1.O1();
            jugador1.triangulo1();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------Jugador 2--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");

            jugador2.cuadrado2();
            jugador2.X2();
            jugador2.O2();
            jugador2.triangulo2();
            console.log(" ");
            console.log(" ");
            pausaEnter();
            console.log("--------------------------------------------------jugador 3--------------------------------------------------".bgWhite.magenta);
            console.log(" ");
            console.log(" ");

            jugador3.cuadrado3();
            jugador3.X3();
            jugador3.O3();
            jugador3.triangulo3();

            console.log(" ");
            console.log(" ");
            break;



        // ---------- OPCIÓN 8: SALIR -------------------------------
        case 8:
            console.log("Saliendo del programa...".bgRed.white);
            continuar = false; // cerrar el programa al elegir la opción 8
            break;



        // ---------- OPCIÓN INVALIDA --------------------------------
        default:
            console.log("Opción inválida, por favor seleccione una opción del 1 al 8.".bgRed.white);
    }



    // ======================= SUBMENÚ ===============================
    if (continuar) {
        console.log("\n¿Qué desea hacer?".bgWhite.black);
        console.log("");
        // Opciones para el usuario
        console.log("1. Volver al menú principal".bgGreen.white);
        console.log("")
        console.log("2. Salir del programa".bgRed.white);
        console.log("");
        // Usuario elige una opción
        const volver = readlineSync.questionInt("Seleccione una opción: ");
        // Manejo de la elección del usuario
        if (volver === 1) {
            continue;
        } else if (volver === 2) {
            console.log("Saliendo del programa...".bgRed.white);
            continuar = false;
        } else {
            console.log("Opción inválida. Terminando programa...".bgRed.white);
            continuar = false;
        }
    }
}
