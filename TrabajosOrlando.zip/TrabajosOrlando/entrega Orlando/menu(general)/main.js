/* 
=========================================================
ELABORADO POR:      DANIEL DI MARCO
NUMERO DE DOCUMENTO: PPT 5080425
FICHA:              3293689

DESCRIPCIÓN:
Este proyecto muestra un menú en consola que permite acceder 
a diferentes programas hechos previamente en clase, como:
- Presentación personal
- Operaciones matemáticas
- Tablas de multiplicar
- Ejemplo básico "Hola mundo"
=========================================================
*/

import colors from "colors"; // Librería para dar color al texto en consola
import readlineSync from "readline-sync"; // Librería para entrada de datos por consola
import operaciones from "./my_modules/funciones.js"; // Módulo con funciones personalizadas
import Plantillas from "./my_modules/plantilla_menu.js";
import stringWidth from 'string-width';
import chalk from 'chalk';
import figlet from 'figlet';
// Funciones de plantillas gráficas para mostrar menús y operaciones 

// Limpia la consola al iniciar el programa

let Salir = false;


do {



  //==========================================================
  // -------------------- MENÚ PRINCIPAL --------------------
  //=============================================================
  operaciones.MENU1()
  // Pregunta al usuario qué opción quiere usar
  const opcion = readlineSync.questionInt("Elige una opcion: ".magenta.bgWhite);

  // Control de flujo según la opción elegida
  switch (opcion) {

    // Solicita los datos al usuario
    case 1: // Presentación personal
      console.clear();
      Plantillas.PLpresentacion('PRESENTACIÓN PERSONAL', ['Por favor ingrese los siguientes datos:']);
      const documento = readlineSync.questionInt("Ingrese su numero de documento: ".blue.bgWhite);
      const ficha = readlineSync.questionInt("Ingrese su ficha: ".blue.bgWhite);
      const nombre = operaciones.preguntarSoloLetras("Ingrese su nombre: ".blue.bgWhite);
      const apellido = operaciones.preguntarSoloLetras("Ingrese su apellido: ".blue.bgWhite);
      const direccion = readlineSync.question("Ingrese su direccion: ".blue.bgWhite);
      const telefono = readlineSync.questionInt("Ingrese su telefono: ".blue.bgWhite);
      const gmail = readlineSync.question("Ingrese su gmail: ".blue.bgWhite);
      console.clear();
      const datosPresentacion = [
        `Nombre: ${nombre} ${apellido}`,
        `Documento: ${documento}`,
        `Ficha: ${ficha}`,
        `Dirección: ${direccion}`,
        `Teléfono: ${telefono}`,
        `Gmail: ${gmail}`
      ];
      Plantillas.PLpresentacion("PRESENTACIÓN PERSONAL", datosPresentacion);
      readlineSync.question("Presione Enter para volver al menu principal: ".blue.bgWhite);
      console.clear();

      break;

    case 2: // Operaciones matemáticas
      console.clear();//limpia la consola
      
      let continuarOperaciones = true;//variable para controlar el bucle del submenú de operaciones

      while (continuarOperaciones) {
        operaciones.menuOperaciones();

        // -------------------- SUBMENÚ DE OPERACIONES -------------------
        // Pregunta al usuario qué opción quiere usar
        const opc = readlineSync.questionInt("Elige una opcion: ".black.bgYellow);

        // Variables para operaciones
        let a, b;

        switch (opc) {
          case 1: // Suma
            console.clear();
            console.log('*********************'.bgCyan)
            console.log(' || '.bgCyan, 'SUMA!!', '    ', ' || '.bgCyan)
            console.log('*********************'.bgCyan)
            console.log(' ');
            console.log(' ');
            // Solicita los números al usuario
            a = parseFloat(readlineSync.questionInt("Ingrese el primer numero: ".bgGreen));
            b = parseFloat(readlineSync.questionInt("Ingrese el segundo numero: ".bgGreen));
            console.clear();

            // Llama a la función para mostrar la plantilla de suma individual
            Plantillas.PlantillaSumaIndividual(a, b);
            readlineSync.question("Presione Enter para volver al menu de operaciones...");
            console.clear();
            break;




          case 2: // Resta

            console.clear();
            console.log('**********************'.bgCyan)
            console.log(' || '.bgCyan, 'RESTA!!', '    ', ' || '.bgCyan)
            console.log('**********************'.bgCyan)
            console.log('  ');
            console.log(' ');
            // Solicita los números al usuario
            a = parseFloat(readlineSync.questionInt("Ingrese el primer numero: ".bgGreen));
            b = parseFloat(readlineSync.questionInt("Ingrese el segundo numero: ".bgGreen));
            console.clear();
            // Llama a la función para mostrar la plantilla de resta individual
            Plantillas.PlantillaRestaIndividual(a, b);
            readlineSync.question("Presione Enter para volver al menu de operaciones...");
            console.clear();
            break;



          case 3: // Multiplicación
            console.clear();
            console.log('*******************************'.bgCyan)
            console.log(' || '.bgCyan, 'MULTIPLICACIÓN!!', '    ', ' || '.bgCyan)
            console.log('*******************************'.bgCyan)
            console.log('  ');
            console.log(' ');
            // Solicita los números al usuario
            a = parseFloat(readlineSync.questionInt("Ingrese el primer numero: ".bgGreen));
            b = parseFloat(readlineSync.questionInt("Ingrese el segundo numero: ".bgGreen));
            console.clear();
            // Llama a la función para mostrar la plantilla de multiplicación individual
            Plantillas.PlantillaMultiplicacionIndividual(a, b);
            readlineSync.question("Presione Enter para volver al menu de operaciones...");
            console.clear();
            break;




          case 4: // División
            console.clear();
            console.log('*************************'.bgCyan)
            console.log(' || '.bgCyan, 'DIVISION!!', '    ', ' || '.bgCyan)
            console.log('*************************'.bgCyan)
            console.log('  ');
            console.log(' ');
            // Solicita los números al usuario
            a = parseFloat(readlineSync.questionInt("Ingrese el primer numero: ".bgGreen));
            b = parseFloat(readlineSync.question("Ingrese el segundo numero: ".bgGreen));
            console.clear();
            // Llama a la función para mostrar la plantilla de división individual
            Plantillas.PlantillaDivisionIndividual(a, b);
            readlineSync.question("Presione Enter para volver al menu de operaciones...");
            console.clear();
            break;





          case 5: // Promedio
            console.clear();
            console.log('*************************'.bgCyan)
            console.log(' || '.bgCyan, 'PROMEDIO!!', '    ', ' || '.bgCyan)
            console.log('*************************'.bgCyan)

            operaciones.Promedio(a);
            console.log('  ');
            readlineSync.question("Presione Enter para volver al menu de operaciones...");
            console.clear();
            break;




          case 6: // Volver al menú principal
            console.clear();
            continuarOperaciones = false;
            break;
          default:
            console.log("Opcion invalida, intenta de nuevo.".white.bgRed);
            readlineSync.question("Presione Enter para continuar...");
            console.clear();
            break;
        }
      }



      break;

    case 3: // Tablas de multiplicar
      console.clear();
      Plantillas.mostrarPlantilla("TABLAS DE MULTIPLICAR", ["Ingrese el rango de tablas que desea ver:"]);
      // Solicita el rango de tablas al usuario
      const inicial = readlineSync.questionInt("\nDigite la tabla inicial: ".bgGreen.white);
      const final = readlineSync.questionInt("Digite la tabla final: ".bgRed.white);
      let tabla = inicial;
      let continuar = true;
      console.clear();
      while (continuar) {
        // if que nos permite controlar si se ha llegado al final del rango de forma ascendente o descendente
        if ((inicial <= final && tabla > final) || (inicial > final && tabla < final)) {
          console.clear();
          readlineSync.question("\nHasta aca llega su peticion. Presione Enter para continuar al menu: ".bgGreen.white);
          console.clear();
          continuar = false;
          break;
        }
        // Llama a la función para mostrar la tabla de multiplicar
        Plantillas.MultiplicarPlantilla(tabla);
        const respuesta = readlineSync.question("\nPresione Enter para continuar o escriba '0' para finalizar: ".bgYellow.black);
        if (respuesta === "0") { // Si el usuario escribe '0', se finaliza el proceso
          console.log("\nProceso finalizado por el usuario.".red.bgWhite);
          continuar = false;
          console.clear();
          break;
        } else {
          if (inicial <= final) {
            tabla++; // Incrementa la tabla para el siguiente ciclo(ascendente)
            console.clear();
          } else {
            tabla--; // Decrementa la tabla para el siguiente ciclo(descendente)
            console.clear();
          }
        }
      }
      break;

    case 4: // Hola mundo
      console.clear();
      //hola mundo modificado por librerias chalk y figlet
      operaciones.holaMundo('HOLA', 'Big', chalk.redBright);
      operaciones.holaMundo('MUNDO', 'Slant', chalk.cyanBright);
      readlineSync.question("\nPresione Enter para volver al menu principal: ".blue.bgWhite);
      console.clear(); //limpia la consola
      break;

    case 5: // Salida del programa
      console.clear();
      //mensaje de despedida modificado por librerias chalk y figlet
      operaciones.hastaluego('HASTA', 'Big', chalk.cyanBright.bold);
      operaciones.hastaluego('LUEGO', 'Slant', chalk.magentaBright.bold);

      process.exit(0);



    default: // Manejo de opción inválida
      console.log("Opción invalida, intenta de nuevo.".white.bgRed);
      console.clear();
      operaciones.MENU1();
      break;






  }
} while (!Salir)

console.log("Saliendo del programa...".white.bgRed);







