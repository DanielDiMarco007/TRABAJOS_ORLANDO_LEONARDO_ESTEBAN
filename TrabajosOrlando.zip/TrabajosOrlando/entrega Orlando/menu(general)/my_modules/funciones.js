
import colors from 'colors'; // Librería para dar color al texto en consola
import stringWidth from 'string-width';// Librería para medir el ancho real de cadenas de texto
import chalk from 'chalk'; // Librería para estilos de texto en consola
import figlet from 'figlet'; // Librería para texto en arte ASCII
import readlineSync from 'readline-sync'; // Librería para entrada de datos por consola
import Plantillas from './plantilla_menu.js'; // Importa las plantillas de menú desde otro módulo




// Opciones del menú principal
const opcionesMenu = [
  "1) PRESENTACION PERSONAL",
  "2) OPERACIONES MATEMATICAS",
  "3) TABLAS DE MULTIPLICAR",
  "4) HOLA MUNDO",
  "5) SALIR",
];


function MENU1() {
  // Muestra la plantilla con el título y las opciones
  Plantillas.mostrarPlantilla("=== MENÚ PRINCIPAL ===", opcionesMenu, 60, true);




}





//MENU DE OPERACIONES CORREGIDO

function menuOperaciones() {
  Plantillas.mostrarPlantilla("MENÚ DE OPERACIONES", [
    "1) Suma",
    "2) Resta",
    "3) Multiplicación",
    "4) División",
    "5) Promedio (3 números aleatorios del 1 al 50)",
    "6) Volver al menú principal"
  ], 60);
}



// ===========================================================
// FUNCIÓN: Hola Mundo
// Muestra en pantalla un recuadro con el clásico mensaje "Hola Mundo"
// ===========================================================

//librerias para colores y arte ascii
//este codigo sirve para mostrar el mensaje de hola mundo en arte ascii con colores
function holaMundo(texto, estilo = 'Standard', color = chalk.greenBright) {

  const fuego = chalk.redBright.bold('🔥🔥🔥');
  const infernal = `${fuego} ${texto} ${fuego}`;

  const textLength = stringWidth(infernal);
  const asciiArt = figlet.textSync(texto, { font: estilo });
  const lineas = asciiArt.split('\n');

  const terminalWidth = process.stdout.columns;

  const centrado = lineas
    .map(linea => {
      const padding = Math.floor((terminalWidth - stringWidth(linea)) / 2);
      return ' '.repeat(Math.max(0, padding)) + color(linea);
    })
    .join('\n');

  console.log('\n' + centrado + '\n');

}


// ===========================================================
// FUNCIÓN: Presentación Personal
// Muestra información personal del autor en un recuadro verde
// ===========================================================
function presentacion(documento, ficha, nombre, apellido, direccion, telefono, gmail) {

  console.log('                                                '.bgGreen);
  console.log(`${'  '.bgGreen}     PRESENTACION                           ${'  '.bgGreen}`);
  console.log('                                                '.bgGreen);
  console.log(`${'  '.bgGreen} DOCUMENTO: ${documento}                    ${'  '.bgGreen}`);
  console.log(`${'  '.bgGreen}     FICHA: ${ficha}                        ${'  '.bgGreen}`);
  console.log(`${'  '.bgGreen}    NOMBRE: ${nombre} ${apellido}           ${'  '.bgGreen}`);
  console.log(`${'  '.bgGreen} DIRECCION: ${direccion}                    ${'  '.bgGreen}`);
  console.log(`${'  '.bgGreen}  TELEFONO: ${telefono}                     ${'  '.bgGreen}`);
  console.log(`${'  '.bgGreen}   GMAIL: ${gmail}                          ${'  '.bgGreen}`);
  console.log('                                                '.bgGreen);
}


// ===========================================================
// FUNCIONES: Operaciones Matemáticas Básicas
// ===========================================================
function suma(a, b) { return a + b; }
function resta(a, b) { return a - b; }
function multiplicacion(a, b) { return a * b; }
function division(a, b) {
  if (b === 0) return "Error: división por cero"; // Evita error de dividir entre 0
  return a / b;
}

// ===========================================================
// FUNCIÓN: Tabla de Multiplicar
// Muestra en consola la tabla de multiplicar del número dado
// con recuadro blanco
// ===========================================================
function tablaMultiplicar(numero) {
  console.log(`${'                       '.bgWhite}`);
  console.log(`${'  '.bgWhite}  Tabla del  ${numero}:      ${'  '.bgWhite}`);
  for (let i = 1; i <= 10; i++) {
    const resultado = numero * i;
    console.log(`${'  '.bgWhite}    ${numero} x ${i} = ${resultado}    ${'  '.bgWhite}`);
  }
}



//        promedio
function Promedio() {


  // Crear tres arrays para guardar los números

  let numeros1 = [];
  let numeros2 = [];
  let numeros3 = [];
  let numeros = [numeros1, numeros2, numeros3]; // array que agrupa los tres conjuntos

  let numDigitado;   // cantidad de números que el usuario desea generar
  let numAleatorio;  // variable temporal para el número aleatorio
  let numero;        // variable temporal para iterar sobre los arrays


  // Pedir al usuario la cantidad de números a generar

  do {
    numDigitado = readlineSync.questionInt(
      "Digite la cantidad de numeros que quieres que aparescan ".white.bgGreen
    );
  } while (numDigitado < 1 || numDigitado > 999999999999999); // Validación básica


  // Llenar los tres conjuntos con números aleatorios entre 1 y 100

  for (numero of numeros) { // recorre cada uno de los tres arrays
    for (let i = 0; i < numDigitado; i++) {
      numAleatorio = Math.floor(Math.random() * 100) + 1; // genera número aleatorio entre 1 y 100
      numero.push(numAleatorio); // agrega el número al array correspondiente
    }
  }


  // Mostrar cada conjunto y esperar a que el usuario presione ENTER para continuar

  console.clear();
  console.log("Primer conjunto de numeros:", numeros1);
  readlineSync.question("Presione ENTER para continuar...");
  console.clear();
  console.log("Segundo conjunto de numeros:", numeros2);
  readlineSync.question("Presione ENTER para continuar...");
  console.clear();
  console.log("Tercer conjunto de numeros:", numeros3);
  readlineSync.question("Presione ENTER para continuar...");


  // Unir todos los números en un solo array para calcular suma y promedio

  const todosNumeros = [...numeros1, ...numeros2, ...numeros3]; // concatenar los tres arrays
  const sumaNumeros = todosNumeros.reduce((acc, n) => acc + n, 0); // suma de todos los números
  const cantidadNumeros = todosNumeros.length; // total de números
  const promedio = cantidadNumeros > 0 ? sumaNumeros / cantidadNumeros : 0; // promedio


  // Inicializar variables para máximo y mínimo

  let numMax = todosNumeros[0];
  let numMin = todosNumeros[0];
  let filaMax = 1, posMax = 1;
  let filaMin = 1, posMin = 1;


  // Recorrer todos los números para encontrar máximo y mínimo y su ubicación

  todosNumeros.forEach((num, idx) => {
    let fila, pos;
    if (idx < numeros1.length) { fila = 1; pos = idx + 1; }
    else if (idx < numeros1.length + numeros2.length) { fila = 2; pos = idx - numeros1.length + 1; }
    else { fila = 3; pos = idx - numeros1.length - numeros2.length + 1; }

    // actualizar máximo
    if (num > numMax) { numMax = num; filaMax = fila; posMax = pos; }
    // actualizar mínimo
    if (num < numMin) { numMin = num; filaMin = fila; posMin = pos; }
  });


  // Mostrar resumen de resultados

  console.log("\nResumen de todos los conjuntos:");
  console.log("Suma total de los números:", sumaNumeros);
  console.log("Promedio total:", promedio.toFixed(2));
  console.log(`Número máximo: ${numMax} (Fila ${filaMax}, posición ${posMax})`);
  console.log(`Número mínimo: ${numMin} (Fila ${filaMin}, posición ${posMin})`);
}








// ===========================================================
// MENÚ PRINCIPAL (Versión Simple)
// Muestra las opciones básicas del programa en recuadro rojo
// Nota: en el main.js se usa una plantilla más avanzada
// ===========================================================
function menuPrincipal() {
  console.log('                                            '.bgRed);
  console.log(`${'  '.bgRed}          ${"=== MENÚ PRINCIPAL ===".rainbow}        ${'  '.bgRed}`);
  console.log('                                            '.bgRed);
  console.log(`${'  '.bgRed}   ${"1) Presentación personal".yellow}             ${'  '.bgRed} `);
  console.log(`${'  '.bgRed}                                        ${'  '.bgRed}`);
  console.log(`${'  '.bgRed}   ${"2) Operaciones matemáticas".red}           ${'  '.bgRed}`);
  console.log(`${'  '.bgRed}                                        ${'  '.bgRed}`);
  console.log(`${'  '.bgRed}   ${"3) Tablas de multiplicar".cyan}             ${'  '.bgRed}`);
  console.log(`${'  '.bgRed}                                        ${'  '.bgRed}`);
  console.log(`${'  '.bgRed}   ${"4) HOLA MUNDO".green}                        ${'  '.bgRed}`);
  console.log(`${'  '.bgRed}                                        ${'  '.bgRed}`);
  console.log(`${'  '.bgRed}   ${"5) Salir".white}                             ${'  '.bgRed}`);
  console.log(`${'  '.bgRed}                                        ${'  '.bgRed}`);
  console.log('                                            '.bgRed);
}

// Exporta todas las operaciones como módulo por defecto


// ===========================================================
// FUNCIÓN: Hasta Luego
// Muestra un mensaje de despedida en arte ASCII centrado
// ===========================================================
function hastaluego(texto, estilo = 'Standard', color = chalk.redBright.bold) {
  const ascii = figlet.textSync(texto, { font: estilo });
  const lineas = ascii.split('\n');
  const terminalWidth = process.stdout.columns;

  const resultado = lineas
    .map(linea => {
      const padding = Math.floor((terminalWidth - stringWidth(linea)) / 2);
      return ' '.repeat(Math.max(0, padding)) + color(linea);
    })
    .join('\n');

  console.log('\n' + resultado + '\n');
}









//-------------------- FUNCIÓN DE VALIDACIÓN --------------------
// Solo permite letras y espacios



function preguntarSoloLetras(mensaje) {
  let respuesta;
  let esValida = false;

  while (!esValida) {
    respuesta = readlineSync.question(mensaje);

    // Valida que solo contenga letras y espacios
    if (/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(respuesta)) {
      esValida = true;
    } else {
      console.log(" Error: Solo se permiten letras. Por favor, intenta de nuevo.".red.bgWhite);
    }
  }

  return respuesta;
}





// ===========================================================
// OBJETO: operaciones
// Agrupa y exporta todas las funciones principales para 
// poder ser usadas en otros archivos del proyecto
// ===========================================================
const operaciones = {
  MENU1,
  menuOperaciones,
  holaMundo,
  presentacion,
  suma,
  resta,
  multiplicacion,
  division,
  tablaMultiplicar,
  menuPrincipal,
  hastaluego,
  Promedio,
  preguntarSoloLetras

};
export default operaciones;
