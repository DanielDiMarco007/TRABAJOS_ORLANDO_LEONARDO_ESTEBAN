import colors from 'colors'; // Librería para colores en la consola
import operaciones from './funciones.js';

// ===========================================================
// PLANTILLA: MENÚ PRINCIPAL
// Función para mostrar un menú con recuadro rojo y opciones centradas
// Parámetros:
// - titulo: el título del menú
// - opcion: arreglo con las opciones a mostrar
// - tamano: ancho del recuadro (default: 60)
// - colores: booleano, futuro uso para colores personalizados
// ===========================================================
export function mostrarPlantilla(titulo, opcion, tamano = 60) {
  const emptyLine = '*'.bold .repeat(tamano);
  console.log(emptyLine.bgRed); 

  // --- TÍTULO CENTRADO ---
  const leftTitle = Math.max(Math.floor((tamano - 4 - titulo.length) / 2), 0);
  const rightTitle = Math.max(tamano - 4 - titulo.length - leftTitle, 0);
  console.log(
    "||".rainbow +
    " ".repeat(leftTitle) +
    titulo.black.bgYellow +
    " ".repeat(rightTitle) +
    "||".rainbow
  );
  console.log(emptyLine.bgRed);

  // --- CUERPO (OPCIONES DEL MENÚ) ---
  const espacio = 3; // margen izquierdo
  opcion.forEach((opcion) => {
    let texto = `${opcion}`;
    // Divide opciones largas en varias líneas
    while (texto.length > tamano - espacio - 4) {
      const linea = texto.slice(0, tamano - espacio - 4);
      const espaciosFinal = Math.max(tamano - espacio - 4 - linea.length, 0);
      console.log(
        "||".rainbow +
        " ".repeat(espacio) +
        linea.white +
        " ".repeat(espaciosFinal) +
        "||".rainbow
      );
      texto = texto.slice(tamano - espacio - 4);
    }
    // Última línea de la opción
    const espaciosFinal = Math.max(tamano - espacio - 4 - texto.length, 0);
    console.log(
      "||".rainbow +
      " ".repeat(espacio) +
      texto.white +
      " ".repeat(espaciosFinal) +
      "||".rainbow
    );
  });

  // Línea inferior
  console.log(emptyLine.bgRed);
}

// ===========================================================
// PLANTILLA: TABLAS DE MULTIPLICAR
// Muestra una tabla de multiplicar enmarcada en un recuadro blanco
// Parámetros:
// - numero: número base de la tabla
// - tamano: ancho del recuadro (default: 30)
// ===========================================================
export function MultiplicarPlantilla(numero, tamano = 30) {
  const emptyLine = '*'.repeat(tamano);
  console.log(emptyLine.bgWhite);

  // --- TÍTULO ---
  const titulo = `Tabla del ${numero}`;
  console.log(
    "  ".bgWhite +
    " ".repeat(Math.floor(tamano - 4 - titulo.length) / 2) +
    titulo +
    " ".repeat(tamano - 4 - titulo.length - Math.floor((tamano - 4 - titulo.length) / 2)) +
    "  ".bgWhite
  );
  console.log(emptyLine.bgWhite);

  // --- CUERPO (OPERACIONES DE LA TABLA) ---
  const espacio = 7;
  for (let i = 1; i <= 10; i++) {  // funciones de multiplicar que se llamó desde funciones.js
    const resultado = numero * i;
    const linea = `${numero} x ${i} = ${resultado}`;  // funciones de multiplicar que se llamó desde funciones.js
    console.log(
      "  ".bgWhite +
      " ".repeat(espacio) +
      linea.green +
      " ".repeat(tamano - espacio - 4 - linea.length) +
      "  ".bgWhite
    );
  }

  // Línea final
  console.log(emptyLine.bgWhite);
}






//=======================PLANTILLA PRESENTACION=========================


export function PLpresentacion(titulo, datosPresentacion , tamano = 80) {
  
  const emptyLine = '-'.repeat(tamano);
  console.log(emptyLine.bgYellow); 

  // --- presentacion ---
  const leftTitle = Math.max(Math.floor((tamano - 4 - titulo.length) / 2), 0);
  const rightTitle = Math.max(tamano - 4 - titulo.length - leftTitle, 0);
  console.log(
    "||".bgYellow +
    " ".repeat(leftTitle) +
    titulo +
    " ".repeat(rightTitle) +
    "||".bgYellow
  );
  console.log(emptyLine.bgYellow);

  const espacio = 7; // margen izquierdo
  datosPresentacion.forEach((datosPresentacion) => {
    let texto = `${datosPresentacion}`;
    // Divide opciones largas en varias líneas
    while (texto.length > tamano - espacio - 4) {
      const linea = texto.slice(0, tamano - espacio - 4);
      const espaciosFinal = Math.max(tamano - espacio - 4 - linea.length, 0);
      console.log(
        "||".bgYellow +
        " ".repeat(espacio) +
        linea +
        " ".repeat(espaciosFinal) +
        "||".bgYellow
      );
      texto = texto.slice(tamano - espacio - 4);
    }
    // Última línea de la opción
    const espaciosFinal = Math.max(tamano - espacio - 4 - texto.length, 0);
    console.log(
      "||".bgYellow +
      " ".repeat(espacio) +
      texto +
      " ".repeat(espaciosFinal) +
      "||".bgYellow
    );
  });

  // Línea inferior
  console.log(emptyLine.bgYellow);
}


// ===========================================================
// PLANTILLA: OPERACIONES MATEMÁTICAS
// Muestra suma, resta, multiplicación y división en un recuadro
// Parámetros:
// - dato1, dato2: números ingresados
// - tamano: ancho del recuadro (default: 70)
// ===========================================================




// ================== PLANTILLAS INDIVIDUALES ==================

 function PlantillaSumaIndividual(a, b, tamano = 60) {
  const emptyLine = '-'.repeat(tamano);
  console.log(emptyLine.bgMagenta);
  const titulo = 'SUMA';
  console.log(
    "||".rainbow +
    " ".repeat(Math.floor((tamano - 4 - titulo.length) / 2)) +
    titulo.yellow +
    " ".repeat(tamano - 4 - titulo.length - Math.floor((tamano - 4 - titulo.length) / 2)) +
    "||".rainbow
  );
  
  const resultado = `${a} + ${b} = ${operaciones.suma(a, b)}`;
  const espacio = 7;
  const espaciosFinal = Math.max(tamano - espacio - 4 - resultado.length, 0);
  console.log(
    "||".rainbow +
    " ".repeat(espacio) +
    resultado.yellow +
    " ".repeat(espaciosFinal) +
    "||".rainbow
  );
  console.log(emptyLine.bgMagenta);
}

 function PlantillaRestaIndividual(a, b, tamano = 60) {
const emptyLine = '-'.repeat(tamano);
console.log(emptyLine.bgGreen);
  const titulo = 'RESTA';
  console.log(
    "||".rainbow +
    " ".repeat(Math.floor((tamano - 4 - titulo.length) / 2)) +
    titulo.cyan +
    " ".repeat(tamano - 4 - titulo.length - Math.floor((tamano - 4 - titulo.length) / 2)) +
    "||".rainbow
  );
  
  const resultado = `${a} - ${b} = ${operaciones.resta(a, b)}`;
  const espacio = 7;
  const espaciosFinal = Math.max(tamano - espacio - 4 - resultado.length, 0);
  console.log(
    "||".rainbow +
    " ".repeat(espacio) +
    resultado.yellow +
    " ".repeat(espaciosFinal) +
    "||".rainbow
  );
  console.log(emptyLine.bgGreen);
}

 function PlantillaMultiplicacionIndividual(a, b, tamano = 60) {
  const emptyLine = '-'.repeat(tamano);
  console.log(emptyLine.bgYellow);
  const titulo = 'MULTIPLICACIÓN';
  console.log(
    "||".rainbow +
    " ".repeat(Math.floor((tamano - 4 - titulo.length) / 2)) +
    titulo.yellow +
    " ".repeat(tamano - 4 - titulo.length - Math.floor((tamano - 4 - titulo.length) / 2)) +
    "||".rainbow
  );
  
  const resultado = `${a} * ${b} = ${operaciones.multiplicacion(a, b)}`;
  const espacio = 7;
  const espaciosFinal = Math.max(tamano - espacio - 4 - resultado.length, 0);
  console.log(
    "||".rainbow +
    " ".repeat(espacio) +
    resultado.yellow +
    " ".repeat(espaciosFinal) +
    "||".rainbow
  );
  console.log(emptyLine.bgYellow);
}

 function PlantillaDivisionIndividual(a, b, tamano = 60) {
  const emptyLine = '-'.repeat(tamano);
  console.log(emptyLine.bgWhite);
  const titulo = 'DIVISIÓN';
  console.log(
    "||".rainbow +
    " ".repeat(Math.floor((tamano - 4 - titulo.length) / 2)) +
    titulo.rainbow.bgWhite +
    " ".repeat(tamano - 4 - titulo.length - Math.floor((tamano - 4 - titulo.length) / 2)) +
    "||".rainbow
  );
 
  const resultado = `${a} / ${b} = ${operaciones.division(a, b)}`;
  const espacio = 7;
  const espaciosFinal = Math.max(tamano - espacio - 4 - resultado.length, 0);
  console.log(
    "||".rainbow +
    " ".repeat(espacio) +
    resultado.yellow +
    " ".repeat(espaciosFinal) +
    "||".rainbow
  );
  console.log(emptyLine.rainbow);
}
 function PlantillaPromedio(numeros, tamano = 60) {
  const emptyLine = ' '.repeat(tamano);
  console.log(emptyLine.bgWhite);
  const titulo = 'PROMEDIO';
  console.log(
    "  ".bgWhite +
    " ".repeat(Math.floor((tamano - 4 - titulo.length) / 2)) +
    titulo +
    " ".repeat(tamano - 4 - titulo.length - Math.floor((tamano - 4 - titulo.length) / 2)) +
    "  ".bgWhite
  );
  console.log(emptyLine.bgWhite);

  const promedio = (numeros.reduce((a, b) => a + b, 0) / numeros.length).toFixed(2);
  const resultado = `Números: ${numeros.join(', ')} | Promedio: ${promedio}`;
  const espacio = 7;
  const espaciosFinal = Math.max(tamano - espacio - 4 - resultado.length, 0);
  console.log(
    "  ".bgWhite +
    " ".repeat(espacio) +
    resultado.yellow +
    " ".repeat(espaciosFinal) +
    "  ".bgWhite
  );
  console.log(emptyLine.bgWhite);
}




// exportamos todas las plantillas pa tenerlo mas organizado
const Plantillas={




  mostrarPlantilla,
  MultiplicarPlantilla,
  PLpresentacion,
  PlantillaSumaIndividual,
  PlantillaRestaIndividual,
  PlantillaMultiplicacionIndividual,
  PlantillaDivisionIndividual,
  PlantillaPromedio


}
export default Plantillas;