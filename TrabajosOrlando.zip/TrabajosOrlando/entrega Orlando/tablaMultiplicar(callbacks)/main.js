import readlineSync from "readline-sync";

import colors from "colors";

import operaciones from "./my_modules/plantillas.js"

//CODIGO ECHO EN CLASE PARA GUIARME ------------------>


// function Multiplicar(numero, callback) {
//     setTimeout(() => {
//         console.log(`tabla de multiplicar del ${numero}:`)
//         let resultado = " "
//         for (let i = 1; i <= 10; ++i)
//             resultado += ` ${numero} x ${i} = ${numero * i} \n`
//         callback()
//         console.log(resultado)

//     }, 0 | Math.random() * 2000);

// }
//------------------------------------------------------------>


// Función delay para esperar entre tablas
function esperar(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Función async para mostrar tablas en un rango
async function mostrarTablas() {
    console.clear();
    console.log(colors.blue("=== TABLAS DE MULTIPLICAR ==="));

    // Pedir tabla inicial y final
    let tablaInicial = parseInt(readlineSync.question("Ingrese la tabla inicial: "));
    let tablaFinal = parseInt(readlineSync.question("Ingrese la tabla final: "));

    // Validación de entradas
    while (isNaN(tablaInicial) || isNaN(tablaFinal) || tablaInicial < 1 || tablaFinal < 1 || tablaInicial > tablaFinal) {
        console.log(colors.red("Valores inválidos. La tabla inicial debe ser menor o igual a la final y ambos mayores que 0."));
        tablaInicial = parseInt(readlineSync.question("Ingrese la tabla inicial: "));
        tablaFinal = parseInt(readlineSync.question("Ingrese la tabla final: "));
    }

    // Mostrar cada tabla con retraso
    for (let i = tablaInicial; i <= tablaFinal; i++) {
        operaciones.MultiplicarPlantilla(i, 30, () => {});
        await esperar(2000); // espera 2 segundos entre tablas
        console.log("\n"); // espacio entre tablas
    }

   
}

// Ejecutar
mostrarTablas();
