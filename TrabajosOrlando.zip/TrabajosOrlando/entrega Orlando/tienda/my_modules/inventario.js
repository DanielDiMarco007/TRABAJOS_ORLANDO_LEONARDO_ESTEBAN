import fs from "fs";
import color from "colors";
import readlineSync from "readline-sync";
import Producto from "./Producto.js";

/**
 * Clase que proporciona utilidades para gestionar el inventario de productos.
 * Incluye funcionalidades para cargar, guardar, agregar, eliminar, buscar y vender productos.
 */
class Utilidades {

    
     // Muestra una plantilla visual formateada en la consola con título y opciones.
   
    static mostrarPlantilla(titulo, opcion, tamano = 60) {
        const emptyLine = "*".bold.repeat(tamano);
        console.log(emptyLine.bgRed);

        // Centrado del título
        const leftTitle = Math.max(Math.floor((tamano - 4 - titulo.length) / 2), 0);
        const rightTitle = Math.max(tamano - 4 - titulo.length - leftTitle, 0);
        console.log(
            "||".rainbow +
            " ".repeat(leftTitle) +
            titulo.black.bgYellow +
            " ".repeat(rightTitle) +
            "||".rainbow
        );
        console.log(emptyLine.bgRed);

        // Opciones
        const espacio = 3;
        opcion.forEach((opc) => {
            let texto = `${opc}`;

            while (texto.length > tamano - espacio - 4) {
                const linea = texto.slice(0, tamano - espacio - 4);
                const espaciosFinal = Math.max(tamano - espacio - 4 - linea.length, 0);

                console.log(
                    "||".rainbow +
                    " ".repeat(espacio) +
                    linea.white +
                    " ".repeat(espaciosFinal) +
                    "||".rainbow
                );

                texto = texto.slice(tamano - espacio - 4);
            }

            // Última línea
            const espaciosFinal = Math.max(tamano - espacio - 4 - texto.length, 0);
            console.log(
                "||".rainbow +
                " ".repeat(espacio) +
                texto.white +
                " ".repeat(espaciosFinal) +
                "||".rainbow
            );
        });

        console.log(emptyLine.bgRed);
    }

    /**
     * Array que almacena todos los productos del inventario.
    
     */
    static inventario = [];

    /**
     * Carga el inventario desde el archivo productos.json.
     * Lee el archivo, parsea el JSON y crea instancias de Producto para cada elemento.
     * Muestra un mensaje de éxito o error según el resultado de la operación.
    
     */
    static cargarInventario() {
        try {
            const data = fs.readFileSync("./productos.json", "utf8");
            const json = JSON.parse(data);

            Utilidades.inventario = json.map(p =>
                new Producto(
                    p.codigo,
                    p.nombre,
                    p.precio,
                    p.stock,
                    p.categoria,
                    p.descripcion,
                    p.iva,
                    p.descuento,
                    p.producto
                )
            );

            console.log(color.green("Inventario cargado correctamente."));
        } catch (err) {
            console.log(color.red("Error cargando inventario, mano: " + err));
        }
    }

    /**
     * Lista todos los productos del inventario en formato tabla.
     * Si el inventario está vacío, muestra un mensaje informativo.
     
     */
    static listarInventario() {
        if (Utilidades.inventario.length === 0) {
            console.log(color.yellow("Inventario vacío."));
            return;
        }

        console.table(Utilidades.inventario);
    }

    /**
     * Solicita los datos de un nuevo producto al usuario y lo agrega al inventario.
     * Pide: código, nombre, precio, stock, categoría, descripción, IVA y descuento.
    
     */
    static agregarProducto() {

        const codigo = readlineSync.questionInt(color.cyan("Código: ").bgWhite);
        const nombre = readlineSync.question(color.cyan("Nombre: ").bgWhite);
        const precio = readlineSync.questionFloat(color.cyan("Precio: ").bgWhite);
        const stock = readlineSync.questionInt(color.cyan("Stock: ").bgWhite);
        const categoria = readlineSync.question(color.cyan("Categoría: ").bgWhite);
        const descripcion = readlineSync.question(color.cyan("Descripción: ").bgWhite);
        const iva = readlineSync.questionFloat(color.cyan("IVA (%): ").bgWhite);
        const descuento = readlineSync.questionFloat(color.cyan("Descuento (%): ").bgWhite);

        const nuevo = new Producto(
            codigo,
            nombre,
            precio,
            stock,
            categoria,
            descripcion,
            iva,
            descuento,
            nombre // opcional: producto = nombre
        );

        Utilidades.inventario.push(nuevo);

        console.log(color.green("Producto agregado exitosamente."));
    }

    /**
     * Elimina un producto del inventario según su código.
     * Solicita el código al usuario y lo busca en el inventario.
     * Muestra un mensaje de éxito o error según si el producto existe o no.
  
     */     
    static eliminarProducto() {
        const codigo = readlineSync.questionInt(color.cyan("Código a eliminar: ").bgWhite);

        const index = Utilidades.inventario.findIndex(p => p.codigo === codigo);

        if (index === -1) {
            console.log(color.red("Producto no encontrado."));
            return;
        }

        Utilidades.inventario.splice(index, 1);
        console.log(color.green("Producto eliminado."));
    }

    /**
     * Busca un producto en el inventario por su código.
     * Solicita el código al usuario y muestra el producto encontrado en formato tabla.
     * Si no existe, muestra un mensaje de error.
     * @static
     */
    static buscarProducto() {
        const codigo = readlineSync.question(color.cyan("Código a buscar: "));

        const prod = Utilidades.inventario.find(p => p.codigo === codigo);

        if (!prod) {
            console.log(color.red("Producto no encontrado."));
            return;
        }

        console.table([prod]);
    }

    /**
     * Realiza la venta de un producto, reduciendo su stock.
     * Solicita el código del producto y la cantidad a vender.
     * Valida la existencia del producto y la disponibilidad de stock.
     * Muestra el nuevo stock después de la venta exitosa.
     
     */
    static venderProducto() {
        const codigo = readlineSync.question(color.cyan("Código del producto: "));
        const cantidad = readlineSync.questionInt(color.cyan("Cantidad: "));
// Buscar el producto en el inventario
        const prod = Utilidades.inventario.find(p => p.codigo === codigo);

        if (!prod) {
            console.log(color.red("Producto no existe."));
            return;
        }

        if (prod.stock < cantidad) {
            console.log(color.red("Stock insuficiente."));
            return;
        }

        prod.stock -= cantidad;

        console.log(color.green("Venta realizada."));
        console.log(color.yellow(`Nuevo stock: ${prod.stock}`));
    }

    /**
     * Guarda el inventario actual en el archivo productos.json.
     * Serializa el array de productos a JSON con formato legible.
     * Muestra un mensaje de éxito o error según el resultado de la operación.
   */
    static grabarInventario() {
        try {
            fs.writeFileSync("./productos.json", JSON.stringify(Utilidades.inventario, null, 2));
            console.log(color.green("Inventario guardado correctamente."));
        } catch (err) {
            console.log(color.red("Error al guardar: " + err));
        }
    }
}

// Exportar la clase Utilidades dentro de un objeto Util

const Util = {Utilidades}
export default Util;