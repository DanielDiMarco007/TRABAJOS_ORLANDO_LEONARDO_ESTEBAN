class Producto {

    constructor(codigo, nombre, precio, stock, categoria, descripcion, iva, descuento) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
        this.categoria = categoria;
        this.descripcion = descripcion;
        this.iva = iva;
        this.descuento = descuento;
    }





    get getCodigo()
     { return this.codigo; }

     set setCodigo(codigo) 
    { this.codigo = codigo; }

    get getNombre() 
    { return this.nombre; }

    set setNombre(nombre) 
    { this.nombre = nombre; }

    get getPrecio() 
    { return this.precio; }

    set setPrecio(precio) 
    { this.precio = precio; }

    get getStock()
     { return this.stock; }

    set setStock(stock) 
    { this.stock = stock; }

    get getCategoria() 
    { return this.categoria; }

    set setCategoria(categoria) 
    { this.categoria = categoria; }

    get getDescripcion() 
    { return this.descripcion; }

    set setDescripcion(descripcion) 
    { this.descripcion = descripcion; }

    get getIva() 
    { return this.iva; }

    set setIva(iva) { this.iva = iva; }


    get getDescuento()
     { return this.descuento; }
    
     set setDescuento(descuento) 
    { this.descuento = descuento; }

}

export default Producto;
