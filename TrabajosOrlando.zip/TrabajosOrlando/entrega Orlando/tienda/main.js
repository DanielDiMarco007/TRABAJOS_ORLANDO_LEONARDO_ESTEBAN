

//Autor: Daniel Di Marco
//ficha : 3293689
//Fecha: 11/12/2025
//Descripción: Programa de gestión de inventario para una tienda.


import readlineSync from 'readline-sync';
import color from 'colors';
import Util from './my_modules/inventario.js';
 
// Variable para almacenar la opción del menú
let opt;

do {
 // PLantilla del menú principal
 console.clear();
    Util.Utilidades.mostrarPlantilla(
        "TIENDA DANIEL",
        [
            //opciones del menú
            "1. Cargar inventario",
            "2. Listar inventario",
            "3. Agregar producto",
            "4. Eliminar producto",
            "5. Buscar producto",
            "6. Vender producto",
            "7. Grabar inventario",
            "8. Salir"
        ],
        80
    );
     // Solicitar opción al usuario
    opt = readlineSync.questionInt(color.cyan("Seleccione una opción: ".bgWhite));

    switch (opt) {
        case 1:
            console.clear();
            // Cargar inventario llamando al método correspondiente
            Util.Utilidades.cargarInventario();
            break;

        case 2:
            console.clear();
            // Listar inventario llamando al método correspondiente
            Util.Utilidades.listarInventario();
            break;

        case 3:
            console.clear();
            // Agregar producto llamando al método correspondiente
            Util.Utilidades.agregarProducto();
            break;

        case 4:
            console.clear();
            // Eliminar producto llamando al método correspondiente
            Util.Utilidades.eliminarProducto();
            break;

        case 5:
            console.clear();
            // Buscar producto llamando al método correspondiente
            Util.Utilidades.buscarProducto();
            break;

        case 6:
            console.clear();
            // Vender producto llamando al método correspondiente
            Util.Utilidades.venderProducto();
            break;

        case 7:
            console.clear();
            // Grabar inventario llamando al método correspondiente
            Util.Utilidades.grabarInventario();
            break;

        case 8:
            // Salir del programa
            console.clear();
            console.log("Saliendo del sistema...".bgGreen.white);
            break;

        default:
            console.log("Opción inválida, mano.".bgRed.white);
            break;
    }

    if (opt !== 8) {
        // Pausa antes de mostrar el menú nuevamente
        readlineSync.question("\nPresione ENTER para continuar...".bgYellow.black);
         
    }

} while (opt !== 8);
