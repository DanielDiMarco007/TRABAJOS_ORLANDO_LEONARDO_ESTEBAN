//AUTOR : DANIEL ELIAS DI MARCO BORGES
//FICHA : 3293689
//DESCRIPCION: Módulo que define la clase Instructor y su subclase InstructorTiempoCompleto
// con propiedades encapsuladas utilizando campos privados.


// Clase padre Instructor
class Instructor {
    #nombre;
    #linea;
    #jornada;

    constructor() {
        this.#nombre = "";
        this.#linea = "";
        this.#jornada = "";
    }

    // Getters y Setters
    //GET nombre
    get getNombre() {
        return this.#nombre;
    }
    //SET nombre
    set setNombre(nombre) {
        this.#nombre = nombre;
    }
    //GET linea 
    get getLinea() {
        return this.#linea;
    }
    //SET linea
    set setLinea(linea) {
        this.#linea = linea;
    }
    //GET jornada
    get getJornada() {
        return this.#jornada;
    }
    //SET jornada
    set setJornada(jornada) {
        this.#jornada = jornada;
    }

    // Descripción completa
    descripcionCompleta() {
        return `Nombre: ${this.getNombre}, Línea: ${this.getLinea}, Jornada: ${this.getJornada}`;
    }

    // Determinar programa de formación
    programaFormacion() {
        const linea = this.getLinea;
        const nombre = this.getNombre;

        if (!linea) {
            console.log(`El instructor ${nombre} no tiene línea asignada`);
            return;
        }
        //includes busca en un string la palabra que se le está asignando
        if (linea === 'software' || linea.includes('software') || linea.includes('desarrollo')) {
            console.log(`${nombre} pertenece al área de Análisis y Desarrollo de Software`);
        } // si en el string la palabra es hardaware o redes se detecta y se asigna al area de administracion de redes
        else if (linea === 'hardware' || linea.includes('hardware') || linea.includes('red') || linea.includes('redes')) {
            console.log(`${nombre} pertenece al área de Administración de Redes`);
        }
        else { // por si no pertenece a ningun programa
            console.log(`${nombre} no pertenece a ningún programa específico`);
        }
    }
}


// Clase hija InstructorTiempoCompleto
class InstructorTiempoCompleto extends Instructor {
    #area;
    #vinculacion;
    #tiempoVinculacion;

    constructor() {
        super();
        this.#area = "";
        this.#vinculacion = "";
        this.#tiempoVinculacion = "";
    }

    // getters y setters
    //GET area
    get getArea() {
        return this.#area;
    }
    //SET area
    set setArea(area) {
        this.#area = area;
    }
    //GET vinculacion
    get getVinculacion() {
        return this.#vinculacion;
    }
    //SET vinculacion
    set setVinculacion(vincu) {
        this.#vinculacion = vincu;
    }
    //GET tiempoVinculacion
    get getTiempoVinculacion() {
        return this.#tiempoVinculacion;
    }
    //SET tiempoVinculacion
    set setTiempoVinculacion(tiempo) {
        this.#tiempoVinculacion = tiempo;
    }

    // Información completa del instructor
    informacionInstructor() {
        console.log(
            `El instructor ${this.getNombre} dicta la línea: ${this.getLinea} `, "\n",
            `en la jornada ${this.getJornada}, área: ${this.getArea}, y realiza `, "\n",
            `vinculación con empresas por ${this.getTiempoVinculacion}.`
        );
    }

    // Información de vinculación específica
    instructorVinculacion() {
        console.log(
            `El instructor ${this.getNombre} realiza vinculación con empresas: ${this.getVinculacion}`
        );
    }
}


// Exportación
const ins = { Instructor, InstructorTiempoCompleto };
export default ins;
