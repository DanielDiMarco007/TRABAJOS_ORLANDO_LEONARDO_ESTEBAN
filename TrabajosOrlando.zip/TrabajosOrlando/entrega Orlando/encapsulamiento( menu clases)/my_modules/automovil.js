//AUTOR : DANIEL ELIAS DI MARCO BORGES
//FICHA : 3293689
//DESCRIPCION: Módulo que define la clase Automovil y su subclase Carro (AutomovilSedan)
// con propiedades encapsuladas utilizando campos privados.





class Automovil {
    #marca;
    #linea;
    #modelo;
    #cilindraje;
    #precio;

    constructor() {
        this.#marca ="" ;
        this.#linea = "";
        this.#modelo = "";
        this.#cilindraje = "";
        this.#precio = 0;
    }

 
    // Métodos getter y setter para cada propiedad (públicos para permitir uso en subclases)
    //GET marca
    get getMarca() {
        return this.#marca;
    }
    //SET marca
     set setMarca(marca) {
        this.#marca = marca;
    }

    //GET linea
    get getLinea() {
        return this.#linea;
    }
    //SET linea
    set setLinea(linea) {
        this.#linea = linea;
    }
    //GET modelo
    get getModelo() {
        return this.#modelo;
    }
    //SET modelo
    set setModelo(modelo) {
        this.#modelo = modelo;
    }
    //GET cilindraje
    get getCilindraje() {
        return this.#cilindraje;
    }
    //SET cilindraje
    set setCilindraje(cilindraje) {
        this.#cilindraje = cilindraje;
    }
    //GET precio
    get getPrecio() {
        return this.#precio;
    }
    //SET precio
    set setPrecio(precio) {
        this.#precio = precio;
    }

    // Método para obtener la descripción completa del automóvil
    descripcionCompleta() {
        return `Marca: ${this.getMarca},
         Linea: ${this.getLinea}, Modelo: ${this.getModelo}, 
         Cilindraje: ${this.getCilindraje},
          Precio: $${this.getPrecio}`;
    }

}


// clase hija automovil sedan (propiedades encapsuladas con campos privados)
class Carro extends Automovil {
    #numeroPasajeros;
    #tipoCaja;

    constructor() {
        super();
        this.#numeroPasajeros = 0;
        this.#tipoCaja = '';
    }

    // getters/setters para propiedades privadas de la subclase
    
    //GET numeroPasajeros
    get getNumeroPasajeros() {
        return this.#numeroPasajeros;
    }
    //SET numeroPasajeros
    set setNumeroPasajeros(n) {
        this.#numeroPasajeros = n;//abreviacion de numero
    }
    //GET tipoCaja
    get getTipoCaja() {
        return this.#tipoCaja;
    }
    //SET tipoCaja
    set setTipoCaja(t) {
        this.#tipoCaja = t;//abreviacion de tipo
    }

    // metodo numeroCinturonesSeguridad (usa los getters de la clase base)
    numeroCinturonesSeguridad() {
        console.log(`El vehículo sedan ${this.getMarca} ${this.getLinea} tiene ${this.getNumeroPasajeros} cinturones de seguridad`);
    }

    // sobreescritura del metodo informacionVehiculo
    informacionVehiculo() {
        console.log(`El vehículo es un ${this.getMarca} ${this.getLinea} del año ${this.getModelo}, con cilindraje de ${this.getCilindraje} y un precio de $${this.getPrecio}, con ${this.getNumeroPasajeros} cinturones`);
    }

    // metodo tipoCaja
    tipoCajaSedan() {
        console.log(`El vehículo sedan ${this.getMarca} ${this.getLinea} tiene una caja de tipo ${this.getTipoCaja}`);
    }

}


//Exportacion de las clases
const auto = {Automovil, Carro}
 export default auto;