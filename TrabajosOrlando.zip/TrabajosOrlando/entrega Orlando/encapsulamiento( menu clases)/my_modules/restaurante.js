//AUTOR : DANIEL ELIAS DI MARCO BORGES
//FICHA : 3293689
//DESCRIPCION: Módulo que define la clase Restaurante y su subclase RestauranteDomicilio
// con propiedades encapsuladas utilizando campos privados.




//  Clase Padre: Restaurante

class Restaurante {
    // Campos privados
    #plato;
    #cantidad;
    #precio;


    constructor() {
        this.#plato = "";
        this.#cantidad = 0;
        this.#precio = 0;
    }

    //  GETTERS & SETTERS 

    // get plato
    get getPlato() {
        return this.#plato;
    }

// set plato
    set setPlato(plato) {
        this.#plato = plato;
    }

    // get cantidad
    get getCantidad() {
        return this.#cantidad;
    }

    // set cantidad
    set setCantidad(cantidad) {
        this.#cantidad = cantidad;
    }

    // get precio
    get getPrecio() {
        return this.#precio;
    }

    // set precio
    set setPrecio(precio) {
        this.#precio = precio;
    }

    // metodo de descripcionCompleta
    descripcionCompleta() {
        return `Plato: ${this.getPlato}, Cantidad: ${this.getCantidad}, Precio: $${this.getPrecio}`;
    }
}



// Clase hija RestauranteDomicilio
class RestauranteDomicilio extends Restaurante {
    // Campos privados adicionales
    #informacionrestaurante;
    #valorpedido;

    constructor() {
        super();
        this.#informacionrestaurante = "";
        this.#valorpedido = 0;
    }

    //getters y setters
    // GET informacionRestaurante
    get getInformacionRestaurante() {
        return this.#informacionrestaurante;
    }

    //SET informacionRestaurante
    set setInformacionRestaurante(info) {
        this.#informacionrestaurante = info;
    }

    //GET valorPedido
    get getValorPedido() {
        return this.#valorpedido;
    }

    //SET valorPedido
    set setValorPedido(valor) {
        this.#valorpedido = valor;
    }

    //  MÉTODOS 


    // Imprime la información completa del restaurante a domicilio.

    informacionRestauranteDomicilio() {
           //precio total 
        const total = this.getPrecio * this.getCantidad;

        console.log(
            `El restaurante ofrece el plato ${this.getPlato} para domicilio, ` +
            `cantidad: ${this.getCantidad}, precio total: $${total}, ` +
            ` ${this.getInformacionRestaurante}, ` +
            `valor del pedido: ${this.getValorPedido}`
        );
    }

    // Muestra si el pedido aplica para descuento.
    valorpedidoDomicilio() {
        const total = this.getPrecio * this.getCantidad;

        if (total > 50000) { // Aplica descuento si es mayor a 50000
            console.log(
                `El pedido a domicilio de ${this.getPlato} supera $50000, ` +
                `por lo tanto tiene un descuento del 10%.`
            );
        } else {
            // No aplica descuento
            console.log(
                `El pedido a domicilio de ${this.getPlato} tiene un valor de $${total} y no aplica descuento.`
            );
        }
    }


    // Calcula y muestra el valor final con descuento si aplica.

    descuentopedidoDomicilio() {
        const total = this.getPrecio * this.getCantidad;

        if (total > 50000) {
            const descuento = total * 0.10;// 10% de descuento
            const totalConDescuento = total - descuento;

            console.log(`Total a pagar con descuento: $${totalConDescuento}`);
        } else {
            console.log(`No hay descuento. Total a pagar: $${total}`);
        }
    }
}



// Exportación Para usar en main.js
const res = { Restaurante, RestauranteDomicilio };
export default res;