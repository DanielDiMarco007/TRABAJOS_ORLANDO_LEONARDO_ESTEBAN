//AUTOR : DANIEL ELIAS DI MARCO BORGES
//FICHA : 3293689
//DESCRIPCION: Programa principal que implementa un menú para interactuar
// con las clases AutomovilSedan, 
// InstructorTiempoCompleto y RestauranteDomicilio.

import auto from './my_modules/automovil.js';
import ins from './my_modules/instructor.js';
import res from './my_modules/restaurante.js';
import readlineSync from 'readline-sync';
import colors from 'colors';
import mostrarPlantilla from './my_modules/plantilla.js';

const pausaEnter = (mensaje = "Presione Enter para continuar...") => {
    readlineSync.question(mensaje);
};

// menu de opciones

let opc;
// variable para controlar la salida del bucle
let salir = false;

do {
    console.clear();
    // Mostrar el menú principal entre una plantilla
    mostrarPlantilla.mostrarPlantilla("Menú Principal", [
        "1. Automóvil",
        "2. Instructor",
        "3. Restaurante",
        "4. Salir"
    ], 60);
    // Leer la opción seleccionada por el usuario
    opc = readlineSync.questionInt("Seleccione una opción (1-4): ");

    switch (opc) {
        //opcion 1
        case 1:
            // Mostrar las instancias de AutomovilSedan
            console.clear();
            console.log("========================================================================================================================================".blue.bgWhite)
            console.log("")
            console.log("                                    ", "SELECIONÓ LA OPCIÓN AUTOMÓVIL ", "          ");
            console.log("")
            console.log("========================================================================================================================================".blue.bgWhite)
            console.log("")
            console.log("")

            // instancias de la clase AutomovilSedan
            //INSTANCIA 1
            const carro1 = new auto.Carro();
            carro1.setMarca = "Mazda";
            carro1.setLinea = "262";
            carro1.setModelo = "2020";
            carro1.setCilindraje = "2.0";
            carro1.setPrecio = 85000000;
            carro1.setNumeroPasajeros = 5;
            carro1.setTipoCaja = "Automática";
            // metodos invocados de la clase Carro
            carro1.numeroCinturonesSeguridad();
            carro1.informacionVehiculo();
            carro1.tipoCajaSedan();
            console.log("")

            console.log("========================================================================================================================================".blue)
            console.log("")
            pausaEnter();
            console.log("")
            console.log("========================================================================================================================================".blue)
            //INSTANCIA 2
            console.log("")

            const carro2 = new auto.Carro();
            carro2.setMarca = "Toyota";
            carro2.setLinea = "Corolla";
            carro2.setModelo = "2021";
            carro2.setCilindraje = "1.8";
            carro2.setPrecio = 90000000;
            carro2.setNumeroPasajeros = 5;
            carro2.setTipoCaja = "Manual";
            // metodos invocados de la clase Carro
            carro2.numeroCinturonesSeguridad();
            carro2.informacionVehiculo();
            carro2.tipoCajaSedan();
            console.log("")

            console.log("========================================================================================================================================".blue)
            console.log("")
            pausaEnter();
            console.log("")
            console.log("========================================================================================================================================".blue)
            //INSTANCIA 3
            console.log("")

            const carro3 = new auto.Carro();
            carro3.setMarca = "Honda";
            carro3.setLinea = "Civic";
            carro3.setModelo = "2019";
            carro3.setCilindraje = "2.0";
            carro3.setPrecio = 80000000;
            carro3.setNumeroPasajeros = 5;
            carro3.setTipoCaja = "Automática";
            // metodos invocados de la clase Carro
            carro3.numeroCinturonesSeguridad();
            carro3.informacionVehiculo();
            carro3.tipoCajaSedan();
            console.log("")

            console.log("========================================================================================================================================".blue)
            console.log("")

            pausaEnter();

            break;
        //opcion 2
        case 2:
            // Mostrar las instancias de Instructor 
            console.clear();
            console.log("========================================================================================================================================".white.bgGreen)
            console.log("")
            console.log("                                                   ", "SELECIONÓ LA OPCIÓN INSTRUCTOR ", "          ");
            console.log("")
            console.log("========================================================================================================================================".white.bgGreen)
            console.log("")
            // instancias de la clase InstructorTiempoCompleto

            //INSTANCIA 1
            const instructor1 = new ins.InstructorTiempoCompleto();
            instructor1.setNombre = "daniel di marco"
            instructor1.setLinea = "desarrollo web "
            instructor1.setJornada = "diurna"
            instructor1.setArea = "analisis y desarrollo"
            instructor1.setTiempo = "tiempo completo"
            instructor1.setTiempoVinculacion = "2 años"
            instructor1.setVinculacion = "Desarrollo de proyectos con empresas locales"
            // metodos invocados de la clase InstructorTiempoCompleto
            instructor1.informacionInstructor();
            instructor1.instructorVinculacion();
            console.log("")

            console.log("========================================================================================================================================".white.bgGreen)
            console.log("")
            pausaEnter();
            console.log("")
            console.log("========================================================================================================================================".white.bgGreen)
            console.log("")

            //INSTANCIA 2
            const instructor2 = new ins.InstructorTiempoCompleto();
            instructor2.setNombre = "María Fernanda Rojas";
            instructor2.setLinea = "hardware y redes";
            instructor2.setJornada = "nocturna";
            instructor2.setArea = "Infraestructura Tecnológica";
            instructor2.setTiempoVinculacion = "8 meses";
            instructor2.setVinculacion = "Soporte técnico empresarial";
            // metodos invocados de la clase InstructorTiempoCompleto
            instructor2.informacionInstructor();
            instructor2.instructorVinculacion();
            console.log("")

            console.log("========================================================================================================================================".white.bgGreen)
            console.log("")

            pausaEnter();
            console.log("")

            console.log("========================================================================================================================================".white.bgGreen)
            console.log("")

            //INSTANCIA 3
            const instructor3 = new ins.InstructorTiempoCompleto();
            instructor3.setNombre = "Luis Alberto Mendoza";
            instructor3.setLinea = "mantenimiento de hardware";
            instructor3.setJornada = "tarde";
            instructor3.setArea = "Electrónica y mantenimiento";
            instructor3.setTiempoVinculacion = "1 año";
            instructor3.setVinculacion = "Empresas de ensamble y reparación";
            // metodos invocados de la clase InstructorTiempoCompleto
            instructor3.informacionInstructor();
            instructor3.instructorVinculacion();
            console.log("")

            console.log("========================================================================================================================================".white.bgGreen)

            console.log("")

            pausaEnter();


            break;
        //opcion 3
        case 3:
            // Mostrar la opcion de Restaurante
            console.clear();
            console.log("============================================================================================================================================================".white.bgCyan)
            console.log("")
            console.log("                                    ", "SELECIONÓ LA OPCIÓN RESTAURANTE ", "          ");
            console.log("")
            console.log("============================================================================================================================================================".white.bgCyan)
            console.log("")
            // instancias de la clase RestauranteDomicilio
            console.log("")

            // INSTANCIA 1
            const pedido1 = new res.RestauranteDomicilio();
            pedido1.setPlato = "Bandeja paisa";
            pedido1.setCantidad = 2;
            pedido1.setPrecio = 30000;
            pedido1.setInformacionRestaurante = "Restaurante La Antioqueñita";
            pedido1.setValorPedido = 6000;

            -
                // metodos invocados de la clase RestauranteDomicilio
                pedido1.informacionRestauranteDomicilio();
            pedido1.valorpedidoDomicilio();
            pedido1.descuentopedidoDomicilio();
            console.log("")

            console.log("============================================================================================================================================================".white.bgCyan)
            console.log("")

            pausaEnter();
            console.log("")

            console.log("============================================================================================================================================================".white.bgCyan)
            console.log("")

            // INSTANCIA 2
            const pedido2 = new res.RestauranteDomicilio();
            pedido2.setPlato = "Hamburguesa doble carne";
            pedido2.setCantidad = 1;
            pedido2.setPrecio = 22000;
            pedido2.setInformacionRestaurante = "Burger House";
            pedido2.setValorPedido = 6000;
            // metodos invocados de la clase RestauranteDomicilio
            pedido2.informacionRestauranteDomicilio();
            pedido2.valorpedidoDomicilio();
            pedido2.descuentopedidoDomicilio();
            console.log("")

            console.log("============================================================================================================================================================".white.bgCyan)
            console.log("")
            pausaEnter();
            console.log("")
            console.log("============================================================================================================================================================".white.bgCyan)
            console.log("")

            // INSTANCIA 3
            const pedido3 = new res.RestauranteDomicilio();
            pedido3.setPlato = "Pizza familiar hawaiana";
            pedido3.setCantidad = 3;
            pedido3.setPrecio = 18000;
            pedido3.setInformacionRestaurante = "Pizzería Don Carlos";
            pedido3.setValorPedido = 5000;

            // metodos invocados de la clase RestauranteDomicilio
            pedido3.informacionRestauranteDomicilio();
            pedido3.valorpedidoDomicilio();
            pedido3.descuentopedidoDomicilio();
            console.log("")

            console.log("============================================================================================================================================================".white.bgCyan)
            console.log("")

            pausaEnter();
            break;

        case 4:
            // Salir del programa

            console.clear();
            console.log("Saliendo del programa...".red.bgWhite);
            salir = false;
            break;


    }
    // mientras no se seleccione la opción de salir
} while (opc !== 4);