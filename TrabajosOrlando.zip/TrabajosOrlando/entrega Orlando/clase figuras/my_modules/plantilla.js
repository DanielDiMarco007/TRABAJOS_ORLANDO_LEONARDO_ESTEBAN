function mostrarPlantilla(titulo, opcion, tamano = 60) {
  const emptyLine = '*'.bold .repeat(tamano);
  console.log(emptyLine.bgRed); 

  // --- TÍTULO CENTRADO ---
  const leftTitle = Math.max(Math.floor((tamano - 4 - titulo.length) / 2), 0);
  const rightTitle = Math.max(tamano - 4 - titulo.length - leftTitle, 0);
  console.log(
    "||".rainbow +
    " ".repeat(leftTitle) +
    titulo.black.bgYellow +
    " ".repeat(rightTitle) +
    "||".rainbow
  );
  console.log(emptyLine.bgRed);

  // --- CUERPO (OPCIONES DEL MENÚ) ---
  const espacio = 3; // margen izquierdo
  opcion.forEach((opcion) => {
    let texto = `${opcion}`;
    // Divide opciones largas en varias líneas
    while (texto.length > tamano - espacio - 4) {
      const linea = texto.slice(0, tamano - espacio - 4);
      const espaciosFinal = Math.max(tamano - espacio - 4 - linea.length, 0);
      console.log(
        "||".rainbow +
        " ".repeat(espacio) +
        linea.blue +
        " ".repeat(espaciosFinal) +
        "||".rainbow
      );
      texto = texto.slice(tamano - espacio - 4);
    }
    // Última línea de la opción
    const espaciosFinal = Math.max(tamano - espacio - 4 - texto.length, 0);
    console.log(
      "||".rainbow +
      " ".repeat(espacio) +
      texto.white +
      " ".repeat(espaciosFinal) +
      "||".rainbow
    );
  });

  // Línea inferior
  console.log(emptyLine.bgRed);
}


const plantilla = { mostrarPlantilla };
export default plantilla;