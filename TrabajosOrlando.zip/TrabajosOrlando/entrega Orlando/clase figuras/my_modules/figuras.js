//====================================================
// MENU DE CLASES PARA FIGURAS GEOMÉTRICAS 
// ECHO POR : DANIEL ELIAS DI MARCO BORGES
// FICHA : 3293689
//====================================================

import readlineSync from "readline-sync";

//  CLASE PADRE FIGURA
class Figura {
    constructor(lado) {
        this.lado = lado; // opcional para algunas figuras
    }

    // método calcular área
    calcularArea() {
        throw new Error("Este método debe ser implementado en las subclases");
    }

    // método calcular perímetro
    calcularPerimetro() {
        throw new Error("Este método debe ser implementado en las subclases");
    }
}

// CLASE CUADRADO
class Cuadrado extends Figura {
    constructor(lado) {
        super(lado); // pasamos el lado a la clase padre
        this.lado = lado; // guardamos el lado en el objeto
    }
    // método calcular área para cuadrado lado * lado
    calcularArea() {
        return this.lado * this.lado;
    }
    // método calcular perímetro para cuadrado 4 * lado
    calcularPerimetro() {
        return this.lado * 4;
    }
}

// CLASE CIRCULO
class Circulo extends Figura {
    constructor(radio) {
        super();
        this.radio = radio;
    }
    // método calcular área para círculo π * r^2
    calcularArea() {
        return Math.PI * this.radio * this.radio;
    }
    // método calcular perímetro para círculo 2 * π * r
    calcularPerimetro() {
        return 2 * Math.PI * this.radio;
    }
}

// CLASE TRIANGULO
class Triangulo extends Figura {
    constructor(base, altura, lado3) {
        super();
        this.base = base;
        this.altura = altura;
        this.lado3 = lado3;
    }
    // método calcular área para triángulo base * altura / 2
    calcularArea() {
        return (this.base * this.altura) / 2;
    }
    // método calcular perímetro para triángulo suma de los tres lados
    calcularPerimetro() {
        return this.base + this.altura + this.lado3;
    }
}

// exportamos las clases
const figuras = { Cuadrado, Circulo, Triangulo };

export default figuras;
