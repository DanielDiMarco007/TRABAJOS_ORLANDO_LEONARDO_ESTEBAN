
//====================================================
// MENU DE CLASES PARA FIGURAS GEOMÉTRICAS 
// ECHO POR : DANIEL ELIAS DI MARCO BORGES
// FICHA : 3293689
//====================================================

import readlineSync from "readline-sync";
import colors from "colors";
import figuras from "./my_modules/figuras.js";
import plantilla from "./my_modules/plantilla.js";


//variable de opcion
let opt;

let salir = false;

do {
    //==========================================
    //llamamos plantillas para mostrar el menu
    //==========================================
console.clear();
    plantilla.mostrarPlantilla('MENU DE FIGURAS GEOMETRICAS',

        ['1. Cuadrado',
            '2. Circulo',
            '3. Triangulo',
            '4. Salir'], 60);//60 tamaño de plantilla

    //solicitamos la opcion
    opt = readlineSync.questionInt('Ingrese el numero de la opcion deseada: ');


    switch (opt) {

        case 1:
            //solicitamos el lado del cuadrado
            
            console.clear();
            //mostramos mensaje de cuadrado
            console.log("                                                           ".bgMagenta)
            console.log("")
            console.log(colors.yellow("  ".bgMagenta, ('        Ha seleccionado la opción de Cuadrado.'), "      ", "  ".bgMagenta));
            console.log("")
            console.log("                                                           ".bgMagenta)
            //solicitamos el lado del cuadrado
            let lado = parseFloat(readlineSync.questionInt('Ingrese el lado del cuadrado: '));
            //creamos el objeto cuadrado
            const cuadrado = new figuras.Cuadrado(lado);
            //mostramos los resultados
            console.log(`El area del cuadrado es:`.bgGreen,(` ${cuadrado.calcularArea()}`));//mostrar area usando metodos
            console.log(`El perimetro del cuadrado es: `.bgGreen,(` ${cuadrado.calcularPerimetro()}`));//mostrar perimetro usando metodos
            readlineSync.question('\n\nPresione Enter para continuar...');
            console.clear();
            break;


        case 2:
            console.clear();//limpiamos la consola
            //mostramos mensaje de circulo
            console.log("                                                           ".bgCyan)
            console.log("")
            console.log(colors.yellow("  ".bgCyan, ('        Ha seleccionado la opción de Circulo.'), "       ", "  ".bgCyan));
            console.log("")
            console.log("                                                           ".bgCyan)
           
            //solicitamos el radio del circulo
            let radio = parseFloat(readlineSync.questionInt('Ingrese el radio del circulo: '));
           
            //creamos el objeto circulo
            const circulo = new figuras.Circulo(radio);
            //mostramos los resultados
            console.log(`El area del circulo es:`.bgCyan,` ${circulo.calcularArea()}`);//mostrar area usando metodos
            console.log(`El perimetro del circulo es:`.bgCyan,` ${circulo.calcularPerimetro()}`);//mostrar perimetro usando metodos
            readlineSync.question('\n\nPresione Enter para continuar...');
            console.clear();
            break;
        case 3:
            console.clear();//limpiamos la consola
            //mostramos mensaje de triangulo
            console.log("                                                           ".bgRed)
            console.log("")
            console.log(colors.yellow("  ".bgRed, ('        Ha seleccionado la opción de Triangulo.'), "     ", "  ".bgRed));
            console.log("")
            console.log("                                                           ".bgRed)
            //base
            let baseT = parseFloat(readlineSync.questionInt('Ingrese la base del triángulo: '));
            //altura
            let alturaT = parseFloat(readlineSync.questionInt('Ingrese la altura del triángulo: '));
            //hipotenusa o tercer lado
            let lado3 = parseFloat(readlineSync.questionInt('Ingrese el tercer lado del triángulo: '));
            
            console.log("")
            console.log("")
            //creamos el objeto triangulo(instanciamos)
            const triangulo = new figuras.Triangulo(baseT, alturaT, lado3);
            //mostramos los resultados
            console.log(`El area del triangulo es:`.bgRed,` ${(baseT * alturaT) / 2}`);//mostrar area usando metodos
            console.log(`El perimetro del triangulo es:`.bgRed,` ${baseT + alturaT + lado3}`);//mostrar perimetro usando metodos
            readlineSync.question('\n\nPresione Enter para continuar...');
            console.clear();
            break;

        case 4:
            //salimos del programa
            salir = true;
            console.log('Gracias por usar el programa de figuras geométricas. ¡Hasta luego!'.bgRed.white);
            break;

    }




    //fin del do while
} while (!salir) 