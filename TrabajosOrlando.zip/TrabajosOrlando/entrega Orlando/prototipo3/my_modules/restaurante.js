
//AUTOR: DANIEL ELIAS DI MARCO BORGES
//FICHA: 3293689
//DOCUMENTO: 5080425
//DESCRIPCION:
//programa que contiene la clase restaurante con sus respectivos metodos
//usamos la forma antigua usando prototype
//para posteriorimente importar en main.js
// y usarlos en el menu de gestion


//==========================================================
//===================================================

//funcion constructora para restaurante

function Restaurante(plato, cantidad, precio) {
    this.plato = plato;
    this.cantidad = cantidad;
    this.precio = precio;
}

// Método para mostrar la información del pedido
Restaurante.prototype.pedidoRestaurante = function () {
    console.log(`el pedido contiene el plato de ${this.plato}, en cantidad de ${this.cantidad},con un monto de  ${this.precio}`)
}

// Método para calcular el valor del pedido
Restaurante.prototype.valorPedido = function () {
    let subtotal = 0;

    const precioProducto = (this.precio, this.plato, this.cantidad);
    subtotal += precioProducto;
    console.log(`total del plato ${this.plato}: ${precioProducto}`);
};

// Método para aplicar descuento al pedido
Restaurante.prototype.descuentoPedido = function () {
    if (this.cantidad >= 2 && this.precio > 50000) {// Condición para aplicar descuento
        const descuento = this.precio * 0.10;// 10% de descuento
        const precio_final = this.precio - descuento;// Precio final después del descuento
        console.log(`Se aplica un descuento de $${descuento}. El precio final es $${precio_final}.`);
    } else {
        console.log(`No aplica descuento para el pedido de ${this.plato}.`);
    }
};



// clase hija para restaurante a domicilio
function RestauranteDomicilio(plato, cantidad, precio, tiempo_entrega, valor_domicilio) {
    //llamamos al constructor de la clase padre
    Restaurante.call(this, plato, cantidad, precio)
    this.tiempo_entrega = tiempo_entrega;
    this.valor_domicilio = valor_domicilio;


}


//heredamos los metodos de la clase padre
RestauranteDomicilio.prototype = Object.create(Restaurante.prototype)
RestauranteDomicilio.prototype.constructor = RestauranteDomicilio;



// Metodo para mostrar informacion del restaurante a domicilio
RestauranteDomicilio.prototype.informacionRestaurante = function () {

    console.log(`este restaurante tine muy buena reputacion ya que ${this.tiempo_entrega} es el tiempo de entrega promedio y una gran variedad de platos   `)

}

// Metodo para calcular el valor del pedido con domicilio
RestauranteDomicilio.prototype.valorPedido = function () {

    let subtotal1 = 0;
    const precioProducto1 = (this.precio, this.plato, this.cantidad, this.valor_domicilio);
    subtotal1 + precioProducto1;
    console.log(`total del plato con domicilio incluido ${this.precio + this.valor_domicilio}`);

}



// exportamos las clases para usarlas en main.js

  const restaurante = {Restaurante, RestauranteDomicilio};
  export default restaurante;