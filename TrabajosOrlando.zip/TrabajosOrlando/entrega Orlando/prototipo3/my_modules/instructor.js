
//AUTOR: DANIEL ELIAS DI MARCO BORGES
//FICHA: 3293689
//DOCUMENTO: 5080425
//DESCRIPCION:
//programa que contiene la clase instructor con sus respectivos metodos
//usamos la forma antigua usando prototype
//para posteriorimente importar en main.js
// y usarlos en el menu de gestion


//funcion constructora para instructor
function Instructor(nombre, linea, jornada) {
    this.nombre = nombre;
    this.linea = linea;
    this.jornada = jornada;

}
//metodos para instructor

//mostrar informacion del instructor
Instructor.prototype.informacionInstructor = function () {

    console.log(`el nombre del instructor es ${this.nombre} y trabajo en la jornada${this.jornada}`)

};

//mostrar programa de formacion del instructor
Instructor.prototype.programaFormacion = function () {
    const linea1 = "Software";
    const linea2 = "hardware";

    if (this.linea === linea1) { //verificamos la linea tecnologica

        console.log(`el instructor ${this.nombre} pertenece al area de Análisis y desarrollo de software`)

    } else if (this.linea === linea2) {
        console.log(`el instructor ${this.nombre} pertenece al area de Administración de redes`)
    };

    if (this.linea !== linea1, linea2) {

        console.log(`no se tiene registro calificado para estas lineas tecnologicas por parte del insructor ${this.nombre}`)

    }

};


//funcion constructora para instructor de planta

function InstructorPlanta(nombre, linea, jornada, fecha_vinculacion) {
    
    //llamamos al constructor padre
    Instructor.call(this, nombre, linea, jornada)
    this.fecha_vinculacion = fecha_vinculacion;

}

//herencia
InstructorPlanta.prototype = Object.create(Instructor.prototype)
InstructorPlanta.prototype.constructor = InstructorPlanta;

//metodos para instructor de planta

//mostrar informacion del instructor de planta 
InstructorPlanta.prototype.informacionInstructor = function () {

    console.log(`el nombre del instructor es ${this.nombre} y trabajo en la jornada${this.jornada}`)


}


//mostrar tiempo de vinculacion del instructor de planta
InstructorPlanta.prototype.tiempo_vinculacion = function () {

    console.log(`el instructor ${this.nombre} se vinculó en ${this.fecha_vinculacion} `)

}


//exportamos las funciones constructoras
const instructores = { Instructor, InstructorPlanta };
export default instructores;