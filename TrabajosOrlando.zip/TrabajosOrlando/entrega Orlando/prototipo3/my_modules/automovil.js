
//AUTOR: DANIEL ELIAS DI MARCO BORGES
//FICHA: 3293689
//DOCUMENTO: 5080425
//DESCRIPCION:
//programa que contiene la clase automovil con sus respectivos metodos
//usamos la forma antigua usando prototype
//para posteriorimente importar en main.js
// y usarlos en el menu de gestion

//==========================================================
//===================================================

//funcion constructora para automovil

function Automovil(marca, linea, modelo, cilindraje, precio) {
    this.marca = marca;
    this.modelo = modelo;
    this.linea = linea;
    this.cilindraje = cilindraje;
    this.precio = precio;

}

// Método para mostrar la información del vehículo
Automovil.prototype.informacionVehiculo = function () {

    console.log(`El vehiculo es un ${this.marca} ${this.linea} del año ${this.modelo}, con cilindraje de ${this.cilindraje}cc y un precio de $${this.precio}`);
};


// Método para verificar la revisión técnico-mecánica
Automovil.prototype.revisionTecnicoMecanica = function (modelo) {
    if (this.modelo < 2025) { // el if nos permite verificar si el auto necesita revision
        console.log(`El vehiculo ${this.marca} ${this.linea} del año ${this.modelo} requiere revision tecnico-mecanica`);
    }
}


// Método para mostrar el nivel de gasolina
Automovil.prototype.nivelGasolina = function () {

    const nivel = Math.floor(Math.random() * 101);

    console.log(`El nivel de gasolina del vehiculo ${this.marca} ${this.linea} es de ${nivel}%`);
}






//funcion Constructora para sedan

function AutomovilSedan(marca, linea, modelo, cilindraje, precio, numeroPasajeros, tipoCaja) {
//llamamos al constructor padre
    Automovil.call(this, marca, linea, modelo, cilindraje, precio);

    this.numeroPasajeros = numeroPasajeros;

    this.tipoCaja = tipoCaja;

}


//establecer herencia de prototipos
AutomovilSedan.prototype = Object.create(Automovil.prototype);
AutomovilSedan.prototype.constructor = AutomovilSedan;


//metodos especificos para sedan
AutomovilSedan.prototype.numeroCinturonesSeguridad = function () {
    console.log(`El vehiculo sedan ${this.marca} ,${this.linea} tiene ${this.numeroPasajeros} cinturones de seguridad`);
};



AutomovilSedan.prototype.informacionVehiculo = function () {
    console.log(`El vehiculo es un ${this.marca} ,${this.linea} del año ${this.modelo}, con cilindraje de ${this.cilindraje}cc y un precio de $${this.precio},con ${this.numeroPasajeros} cinturones de seguridad `);
};


const carro = {Automovil, AutomovilSedan};
export default carro;