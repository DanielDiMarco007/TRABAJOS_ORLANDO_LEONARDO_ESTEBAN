
//AUTOR: DANIEL ELIAS DI MARCO BORGES
//FICHA: 3293689
//DOCUMENTO: 5080425
//DESCRIPCION:
//Programa que nos permite gestionar a travez de un menu
//diferentes clases con sus respectiva informacio y metodos
//de automoviles, instructores y restaurantes.

//usamos la forma antigua usando prototype 


//importaciones
import carro from './my_modules/automovil.js';
import instructores from './my_modules/instructor.js';
import restaurante from './my_modules/restaurante.js';
import mostrarPlantilla from './my_modules/plantilla.js';
import colors from 'colors';
import readlineSync from 'readline-sync';


//menu

let opt;//opcion de elegir un inciso 
let salir = false;
const pausaEnter = (mensaje = "Presione Enter para continuar...") => {
    readlineSync.question(mensaje);
}

console.clear();
console.log("Bienvenido al sistema de gestión".green);
do {
    //llamamos la plantilla del menu para que se muestre de una forma bonita
    mostrarPlantilla.mostrarPlantilla(
        'Menú Principal',
        ['1) Automóviles',
            '2) Instructores',
            '3) Restaurantes',// del 1 al 4 son las opciones visibles
            '4) Salir'
        ], 50)//50 es el tamaño de la plantilla

    // mensaje que le dice al usuario que elija una opcion
    opt = readlineSync.questionInt('Seleccione una opción (1-4):');
    switch (opt) {
        case 1:

            console.clear();
            console.log("==========================================================================================================================================".blue.bgWhite)
            console.log("")
            console.log("                                              ", "SELECIONÓ LA OPCIÓN AUTOMÓVIL ", "          ");
            console.log("")
            console.log("==========================================================================================================================================".blue.bgWhite)
            console.log("")
            //3 instancias para mostrar en consola
            const sedan = new carro.AutomovilSedan('Mazda', 'sedan', 2017, 1800, 50000000, 4, 'automatica skyactiv-drive')
            const auto1 = new carro.AutomovilSedan('Toyota', 'Corolla', 2018, 1800, 20000, 4, 'automatica');
            const auto2 = new carro.AutomovilSedan('Honda', 'Civic', 2020, 2000, 25000, 2, 'manual');



            // mostramos la informacion de los autos y sedan a traves de sus metodos
            console.log("------------------------------------------------------------------------------------------------------------------------------------------".rainbow.bgWhite)
            console.log("")

            auto1.revisionTecnicoMecanica();
            auto1.informacionVehiculo();
            auto1.nivelGasolina();
            auto1.numeroCinturonesSeguridad();
            console.log("")

            console.log("------------------------------------------------------------------------------------------------------------------------------------------".rainbow.bgWhite)

            console.log("")
            pausaEnter();
            console.log("")

            console.log("------------------------------------------------------------------------------------------------------------------------------------------".rainbow.bgWhite)
            console.log("")

            //metodos instancias 2
            sedan.informacionVehiculo();
            sedan.numeroCinturonesSeguridad();
            sedan.nivelGasolina();
            sedan.revisionTecnicoMecanica();

            console.log("")
            // metodos instancias 3
            console.log("------------------------------------------------------------------------------------------------------------------------------------------".rainbow.bgWhite)
            console.log("")

            pausaEnter();
            console.log("")
            console.log("------------------------------------------------------------------------------------------------------------------------------------------".rainbow.bgWhite)
            console.log("")

            auto2.revisionTecnicoMecanica();
            auto2.informacionVehiculo();
            auto2.nivelGasolina();
            auto2.numeroCinturonesSeguridad();
            console.log("")

            console.log("------------------------------------------------------------------------------------------------------------------------------------------".rainbow.bgWhite)

            console.log("\n");
            readlineSync.question('Presione Enter para continuar...');
            console.clear();

            break;
        case 2:

            // opcion de instructores
            console.clear();
            console.log("=================================================================================================================================================".blue.bgWhite)
            console.log("")
            console.log("                                                  ", "SELECIONÓ LA OPCIÓN INSTRUCTOR ", "          ");
            console.log("")
            console.log("=================================================================================================================================================".blue.bgWhite)
            console.log("")

            //instancias de instructores de planta

            const ins1 = new instructores.InstructorPlanta('Juan', 'software', 'diurna', '23/05/2023')
            const ins2 = new instructores.InstructorPlanta('Nelson', 'Software', 'mixta', '27/06/2007');
            const ins3 = new instructores.InstructorPlanta('Rucio', 'Hardware', 'diurna', '10/11/2010');


            // mostramos la informacion de los instructores y su tiempo de vinculacion a traves de sus metodos
            console.log("*************************************************************************************************************************************************".rainbow.bgMagenta)
            console.log("")
            //primer instructor
            ins1.informacionInstructor();
            ins1.tiempo_vinculacion();
            ins1.programaFormacion();
            console.log("")
            console.log("*************************************************************************************************************************************************".rainbow.bgMagenta)

            console.log("")
            pausaEnter();
            console.log("")

            console.log("*************************************************************************************************************************************************".rainbow.bgMagenta)
            console.log("")
            //segundo instructor
            ins2.informacionInstructor();
            ins2.tiempo_vinculacion();
            ins2.programaFormacion();
            console.log("")
            console.log("*************************************************************************************************************************************************".rainbow.bgMagenta)

            console.log("")
            pausaEnter();
            console.log("")

            console.log("*************************************************************************************************************************************************".rainbow.bgMagenta)
            console.log("")
            //tercer instructor
            ins3.informacionInstructor();
            ins3.tiempo_vinculacion();
            ins3.programaFormacion();
            console.log("")
            console.log("*************************************************************************************************************************************************".rainbow.bgMagenta)

            console.log("\n");
            readlineSync.question('Presione Enter para continuar...');
            console.clear();

            break;
        case 3:
            // opcion de restaurantes
            console.clear();
            console.log("===================================================================================================================================================".blue.bgWhite)
            console.log("")
            console.log("                                                     ", "SELECIONÓ LA OPCIÓN RESTAURANTE ", "          ");
            console.log("")
            console.log("===================================================================================================================================================".blue.bgWhite)
            console.log("")
            //instancias de restaurante a domicilio
            const pedido1 = new restaurante.RestauranteDomicilio('Salmon rosado Aleman con caviar negro', 1, 300000, '10m', 10000)
            const pedido2 = new restaurante.RestauranteDomicilio('mariscos a la goustue', 2, 65000, '10m', 10000)
            const pedido3 = new restaurante.RestauranteDomicilio('Caviar negro con trufas de madagascar ', 1, 250000, '10m', 15000)

            //mostramos los metodos e informacion
            console.log("---------------------------------------------------------------------------------------------------------------------------------------------------".rainbow)
            console.log("")
            pedido1.pedidoRestaurante();
            pedido1.valorPedido();
            pedido1.descuentoPedido();
            pedido1.informacionRestaurante();
            pedido1.valorPedido();
            console.log("")
            console.log("---------------------------------------------------------------------------------------------------------------------------------------------------".rainbow)

            console.log("")
            pausaEnter();
            console.log("")

            console.log("---------------------------------------------------------------------------------------------------------------------------------------------------".rainbow)
            console.log("")
            pedido2.pedidoRestaurante();
            pedido2.valorPedido();
            pedido2.descuentoPedido();
            pedido2.informacionRestaurante();
            pedido2.valorPedido();
            console.log("")
            console.log("---------------------------------------------------------------------------------------------------------------------------------------------------".rainbow)

            console.log("")
            pausaEnter();
            console.log("")

            console.log("---------------------------------------------------------".rainbow)
            console.log("")
            pedido3.pedidoRestaurante();
            pedido3.valorPedido();
            pedido3.descuentoPedido();
            pedido3.informacionRestaurante();
            pedido3.valorPedido();
            console.log("")
            console.log("---------------------------------------------------------".rainbow)

            console.log("\n");
            readlineSync.question('Presione Enter para continuar...');
            console.clear();
            break;

        case 4:
            // opcion de salir
            console.log("Saliendo del sistema...".yellow);
            salir = true;//cambiar la variable para salir del bucle
            break;




    }

} while (salir === false);//mientras no se desee salir

console.log("Gracias por usar el sistema de gestión. ¡Hasta luego!".green);
