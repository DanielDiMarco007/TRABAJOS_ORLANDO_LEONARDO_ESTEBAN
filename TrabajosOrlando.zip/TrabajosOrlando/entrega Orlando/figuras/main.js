// ============================================================================
// PROGRAMA: Cálculo de área y perímetro de figuras geométricas
// AUTOR: Daniel Elias Di Marco Borges
// DESCRIPCIÓN: Programa en consola que permite calcular el área y perímetro
//              de un rectángulo, círculo y triángulo.
// Ficha:3293689
// ============================================================================

// Importamos los módulos necesarios
import readlineSync from 'readline-sync';  
import colors from 'colors';                
import operaciones from './my_modules/funciones.js'; 

// Mensaje de bienvenida
console.log(colors.rainbow('Bienvenido al programa de figuras geométricas'));

// Variable de control para mantener el ciclo del menú activo
let continuar = true;

// Ciclo principal del menú
while (continuar) {

  console.clear();

  operaciones.menu(); // Muestra el menú principal (definido en el módulo funciones.js)
  
  // Se solicita al usuario que elija una opción del menú
  let opcion = readlineSync.question('Ingrese el numero de la opcion deseada: ');


  switch (opcion) {
    // ========================================================================
    // OPCIÓN 1: Cálculo del área y perímetro de un RECTÁNGULO
    case '1':
      // Solicitamos las dimensiones
      let largoR = readlineSync.questionFloat('Ingrese el largo del rectángulo: ');
      let anchoR = readlineSync.questionFloat('Ingrese el ancho del rectángulo: ');

      // Fórmulas
      let areaR = largoR * anchoR;
      let perimetroR = 2 * (largoR + anchoR);

      // Resultados
      console.log(colors.green(`El área del rectángulo es: ${areaR}`));
      console.log(colors.green(`El perímetro del rectángulo es: ${perimetroR}`));
      break;

    // ========================================================================
    // OPCIÓN 2: Cálculo del área y perímetro de un CÍRCULO
    case '2':
      // Solicitamos el radio
      let radio = readlineSync.questionFloat('Ingrese el radio del círculo: ');

      // Se usa la función importada desde el módulo para calcular el área
      console.log(colors.green(`El área del círculo es: ${operaciones.areaC(radio)}`));

      // Perímetro = 2 * π * radio
      console.log(colors.green(`El perímetro del círculo es: ${2 * Math.PI * radio}`));
      break;

    // ========================================================================
    // OPCIÓN 3: Cálculo del área y perímetro de un TRIÁNGULO
    case '3':
      // Se piden base y altura para calcular el área
      let baseT = readlineSync.questionFloat('Ingrese la base del triángulo: ');
      let alturaT = readlineSync.questionFloat('Ingrese la altura del triángulo: ');

      // Fórmula del área
      let areaT = (baseT * alturaT) / 2;
      console.log(colors.green(`El área del triángulo es: ${areaT}`));

      console.log('Ya calculamos el área del triángulo, ahora el perímetro:');

      // Para el perímetro se solicita el tercer lado
      let lado3 = parseFloat(readlineSync.questionInt('Ingrese el tercer lado del triángulo: '));
      let perimetroT = baseT + alturaT + lado3;
      console.log(colors.green(`El perímetro del triángulo es: ${perimetroT}`));

      // Verificación de la desigualdad triangular
      if (operaciones.desigualdad(baseT, alturaT, lado3)) {
        console.log(colors.green('Los lados ingresados pueden formar un triángulo'));

        //  tipo de triángulo
        console.log(colors.yellow('Determinando el tipo de triángulo...'));

        // Triángulo rectángulo
        if (baseT + alturaT === lado3) {
          console.log(colors.yellow('El triángulo es rectángulo (la suma de dos lados es igual al tercero)'));

        // Triángulo equilátero
        } else if (baseT === alturaT && alturaT === lado3) {
          console.log(colors.yellow('El triángulo es equilátero (los tres lados son iguales)'));

        // Triángulo isósceles
        } else if (baseT === alturaT || baseT === lado3 || alturaT === lado3) {
          console.log(colors.yellow('El triángulo es isósceles (tiene dos lados iguales)'));

        // Triángulo escaleno
        } else {
          console.log(colors.yellow('El triángulo es escaleno (todos los lados son diferentes)'));
        }

      } else {
        console.log(colors.red('Los lados ingresados NO pueden formar un triángulo'));
      }
      break;

    // ========================================================================
    // OPCIÓN 4: Salir del programa
    case '4':
      console.log(colors.blue('¡Gracias por usar el programa!'));
      continuar = false; // Finaliza el ciclo principal
      break;

    // ========================================================================
    // Opción no válida
    default:
      console.log(colors.red('¡Error! Opción no válida. Intente nuevamente.'));
      break;
  }

  // Pausa antes de volver al menú, a menos que elija salir
  if (continuar && opcion !== '4') {
    //mientras 
    console.log();
    readlineSync.question(colors.cyan('Presione Enter para volver al menú...'));

  }
}
