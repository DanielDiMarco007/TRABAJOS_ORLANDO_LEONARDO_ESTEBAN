// ============================================================================
// MÓDULO: funciones.js
// AUTOR: Daniel Elias Di Marco Borges
// DESCRIPCIÓN: Contiene las funciones necesarias para el cálculo del área del
//              círculo, la validación de triángulos y la visualización del menú
//              principal del programa de figuras geométricas.
// ============================================================================


import readlineSync from 'readline-sync'; 
import colors from 'colors';               

// ============================================================================
// FUNCIÓN: areaC()
// DESCRIPCIÓN: Calcula el área de un círculo dado su radio.
// PARÁMETROS:
//    - radio (number): el radio del círculo.
// RETORNA:
//    - number: el valor del área del círculo.
// FÓRMULA: área = π * radio²
// ============================================================================
function areaC(radio) {
  return Math.PI * Math.pow(radio, 2);
}

// ============================================================================
// FUNCIÓN: menu()
// DESCRIPCIÓN: Muestra en consola el menú principal del programa con las
//              opciones disponibles para el usuario.
// ============================================================================
function menu() {
console.log('                                                      '.bgGreen)
  console.log(colors.yellow('||'.bgGreen,'========= MENÚ DE FIGURAS GEOMÉTRICAS ==========','||'.bgGreen));
  console.log('||'.bgGreen,(colors.yellow('1. Rectángulo')),'                                  ','||'.bgGreen);
  console.log('||'.bgGreen,(colors.yellow('2. Círculo')),'                                     ','||'.bgGreen);
  console.log('||'.bgGreen,(colors.yellow('3. Triángulo')),'                                   ','||'.bgGreen);
  console.log('||'.bgGreen,(colors.yellow('4. Salir')),'                                       ','||'.bgGreen);
  console.log(colors.yellow('||'.bgGreen,'================================================','||'.bgGreen));
console.log('                                                      '.bgGreen)
}

// ============================================================================
// FUNCIÓN: desigualdad()
// DESCRIPCIÓN: Verifica si tres lados pueden formar un triángulo según la
//              desigualdad triangular (la suma de dos lados debe ser mayor
//              que el tercero).
// PARÁMETROS:
//    - baseT : base del triángulo.
//    - alturaT : altura o segundo lado del triángulo.
//    - lado3 : tercer lado del triángulo.
// RETORNA:
//    - boolean: true si los lados pueden formar un triángulo, false si no.
// ============================================================================
function desigualdad(baseT, alturaT, lado3) {
  // Validación: ningún lado debe ser negativo
  if (baseT < 0 || alturaT < 0 || lado3 < 0) {
    return false;
  }

  // Verificación de la desigualdad triangular
  return (
    baseT + alturaT > lado3 && baseT + lado3 > alturaT && alturaT + lado3 > baseT
  );
}

// ============================================================================
// OBJETO: operaciones
// DESCRIPCIÓN: Agrupa todas las funciones exportadas de este módulo para su
//              uso en el programa principal.
// ============================================================================
const operaciones = {
  areaC,
  menu,
  desigualdad
};

// Exportamos las operaciones
export default operaciones;
