//AUTOR: DANIEL ELIAS DI MARCO BORGES
//FICHA : 3293689
//DESCRIPCION:
//menu donde veamos de forma organizada :
// =========reto 1=================
//aprendiz etapa lectiva
//aprendiz etapa practica
//instructorPlanta
//instructorContrato


import colors from "colors"
import readlineSync from 'readline-sync';

//clase padre persona
class Persona {

    // atributos privados
    #documento
    #nombreCompleto

    constructor() {

        this.#documento = 0;
        this.#nombreCompleto = "";

    };
    // metodos getter y setter
    //documento
    get getdocumento() {
        return this.#documento;
    }

    set setdocumento(nuevoDocumento) {
        this.#documento = nuevoDocumento;
    }
    //nombreCompleto
    get getnombreCompleto() {
        return this.#nombreCompleto;
    }

    set setnombreCompleto(nuevoNombreCompleto) {
        this.#nombreCompleto = nuevoNombreCompleto;
    }



    //metodo informacion
    informacion() {
        return `Persona: ${this.getnombreCompleto}, Documento: ${this.getdocumento}`;
    };
};


//clase hija aprendiz -padre persona
class Aprendiz extends Persona {
    #ficha;
    #programa;

    constructor() {
        super();
        this.#ficha = "";
        this.#programa = "";

    }
    //metodos getter y setter
    //ficha
    get getficha() {
        return this.#ficha;

    };

    set setficha(nuevaFicha) {
        this.#ficha = nuevaFicha;
    }

    //programa
    get getprograma() {
        return this.#programa;
    }

    set setprograma(nuevoPrograma) {
        this.#programa = nuevoPrograma;
    }




    //metodo de matricula
    matricula() {
        return `Aprendiz: ${this.getnombreCompleto}, Documento: ${this.getdocumento}, Ficha: ${this.getficha}, Programa: ${this.getprograma}`;
    }
};


//clase hija Etapalectiva -padre aprendiz
class EtapaLectiva extends Aprendiz {
    #numeroTrimestre;
    #fechainicio;
    #fechaTerminacion;

    constructor() {
        super();
        this.#numeroTrimestre = 0;
        this.#fechainicio = "";
        this.#fechaTerminacion = "";
    }


    //metodos getter y setter
    //numeroTrimestre
    get getnumeroTrimestre() {
        return this.#numeroTrimestre;
    }

    set setnumeroTrimestre(nuevoNumeroTrimestre) {
        this.#numeroTrimestre = nuevoNumeroTrimestre;
    }

    //fecha inicio
    get getfechainicio() {
        return this.#fechainicio;
    }
    set setfechainicio(nuevaFechaInicio) {
        this.#fechainicio = nuevaFechaInicio;
    }

    //fecha terminacion
    get getfechaTerminacion() {
        return this.#fechaTerminacion;
    }
    set setfechaTerminacion(nuevaFechaTerminacion) {
        this.#fechaTerminacion = nuevaFechaTerminacion;
    }


    // metodo informacion polimorfismo
    informacion() {
        return `Aprendiz: ${this.getnombreCompleto},
                ha sido matriculado en el programa : ${this.getprograma},
                Documento: ${this.getdocumento},
                Ficha: ${this.getficha},
                Programa: ${this.getprograma},
                Numero Trimestre: ${this.getnumeroTrimestre},
                Fecha Inicio: ${this.getfechainicio},
                Fecha Terminacion: ${this.getfechaTerminacion}`;
    }

    //metodo de estado de aprendiz etapa lectiva
    estado() {
        return `se encuentra en la etapa lectiva del programa ${this.getprograma}.`;
    }
};


//clase etapa practicas -padre aprendiz
class EtapaPracticas extends Aprendiz {
    #modalidad;
    #fechainicio;
    #fechaTerminacion;
    constructor() {
        super();
        this.#modalidad = "";
        this.#fechainicio = "";
        this.#fechaTerminacion = "";


    }
    //metodos getter y setter

    //modalidad
    get getmodalidad() {
        return this.#modalidad;
    }

    set setmodalidad(nuevaModalidad) {
        this.#modalidad = nuevaModalidad;
    }

    //fecha inicio
    get getfechainicio() {
        return this.#fechainicio;
    }

    set setfechainicio(nuevaFechaInicio) {
        this.#fechainicio = nuevaFechaInicio;
    }

    //fecha terminacion
    get getfechaTerminacion() {
        return this.#fechaTerminacion;
    }

    set setfechaTerminacion(nuevaFechaTerminacion) {
        this.#fechaTerminacion = nuevaFechaTerminacion;
    }

    // metodo informacion polimorfismo
    informacion() {
        return `el aprendiz ${this.getnombreCompleto},
          Documento: ${this.getdocumento},
          Ficha: ${this.getficha},  
          está en el Programa: ${this.getprograma},
          Modalidad: ${this.getmodalidad},
          Fecha Inicio: ${this.getfechainicio},
          Fecha Terminacion: ${this.getfechaTerminacion}`;
    }
    //metodo de estado de aprendiz etapa practicas
    estado() {
        return ` se encuentra en la etapa de practicas del programa ${this.getprograma}.`;
    }

}


//clase hija instructor - padre persona
class Instructor extends Persona {
    #profesion;
    #salarioBasico;
    constructor() {
        super();
        this.#profesion = "";
        this.#salarioBasico = 0;
    }
    //metodos getter y setter
    //profesion
    get getprofesion() {
        return this.#profesion;
    }
    set setprofesion(nuevaProfesion) {
        this.#profesion = nuevaProfesion;
    }

    //salarioBasico
    get getsalarioBasico() {
        return this.#salarioBasico;
    }

    set setsalarioBasico(nuevoSalario) {
        this.#salarioBasico = nuevoSalario;
    }
    //metodo contrato instructor
    contrato() {
        return `El instructor ${this.getnombreCompleto} con documento ${this.getdocumento} tiene un salario de ${this.getsalarioBasico} y es ${this.getprofesion}.`;
    }
};


//clase hija instructorPlanta - padre instructor
class InstructorPlanta extends Instructor {
    #grado;
    #fechavinculacion;

    constructor() {
        super();
        this.#grado = "";
        this.#fechavinculacion = "";
    }
    //metodos getter y setter
    //grado
    get getgrado() {
        return this.#grado;
    }

    set setgrado(nuevoGrado) {
        this.#grado = nuevoGrado;
    }
    //fecha vinculacion
    get getfechavinculacion() {
        return this.#fechavinculacion;
    }

    set setfechavinculacion(nuevaFechaVinculacion) {
        this.#fechavinculacion = nuevaFechaVinculacion;
    }
    //metodo informacion polimorfismo
    informacion() {
        return `Instructor de Planta: ${this.getnombreCompleto}, 
                Documento: ${this.getdocumento},
                Profesion: ${this.getprofesion},
                Salario Basico: ${this.getsalarioBasico},
                Grado: ${this.getgrado},
                Fecha Vinculacion: ${this.getfechavinculacion}`;
    }


    estado() {
        return `El instructor de planta ${this.getnombreCompleto} con documento ${this.getdocumento} se encuentra vinculado desde ${this.getfechavinculacion}.`;
    }
    // en este metodo cada grado representa 100.000 y es un numero del 1 al 20
    // el sueldo se determina por el salario basico + grado * 100.000

    sueldo() {
        // calcular el salario (son 100.000 por grado) salario base 2.000.000

        const gradoNumerico = parseInt(this.getgrado);
        const incremento = gradoNumerico >= 1 && gradoNumerico <= 20 ? gradoNumerico * 100000 : 0;
        const sueldoTotal = this.getsalarioBasico + incremento;


        return `El instructor de planta ${this.getnombreCompleto} tiene un salario de ${sueldoTotal}.`;




    }
};




//clase hija instructorContrato - padre instructor
class InstructorContrato extends Instructor {
    #duracionContrato;
    #fechaVinculacion;
    constructor() {
        super();
        this.#duracionContrato = "";
        this.#fechaVinculacion = "";
    }

    //metodos getter y setter
    //duracionContrato
    get getduracionContrato() {
        return this.#duracionContrato;
    }

    set setduracionContrato(nuevaDuracion) {
        this.#duracionContrato = nuevaDuracion;
    }
    //fechaVinculacion
    get getfechaVinculacion() {
        return this.#fechaVinculacion;
    }

    set setfechaVinculacion(nuevaFecha) {
        this.#fechaVinculacion = nuevaFecha;
    }
    //metodo informacion polimorfismo
    informacion() {
        return `Instructor por Contrato: ${this.getnombreCompleto},
                Documento: ${this.getdocumento},
                Profesion: ${this.getprofesion},                                     
                Salario Basico: ${this.getsalarioBasico},
                Duracion Contrato: ${this.getduracionContrato}, 
                Fecha Vinculacion: ${this.getfechaVinculacion}`;
    }
    estado() {

        return `El instructor por contrato ${this.getnombreCompleto} con documento ${this.getdocumento} tiene un contrato de ${this.getduracionContrato}.`;
    }
    sueldo() {
        return `El instructor por contrato ${this.getnombreCompleto} tiene un salario de ${this.getsalarioBasico}.`;
    }







};



class Utilidades {

    //metodo estaticos para hacer menú

    static mostrarMenu(title, options, width) {
        console.clear();
        const emptyLine = "*".rainbow.repeat(width);

        //encabezado
        console.log(emptyLine.bgYellow)

        console.log(
            "  ".bgYellow + "=".rainbow.repeat(Math.floor((width - 4 - title.length) / 2)) +
            title + "=".rainbow.repeat((width - 4 - title.length) - Math.floor((width - 4 - title.length) / 2)) +
            "  ".bgYellow
        );
        console.log(emptyLine.bgYellow);


        //opciones numeradas
        options.forEach((opt, index) => {
            const line = `${String(index + 1).green}. ${opt}`;

            console.log(
                "  ".bgYellow +
                "      " +
                line + " ".repeat(width - line.length) +
                "  ".bgYellow
            );
        });

        // espacio + opcion de salida

        console.log("  ".bgYellow + "-".red.repeat(width - 4) + "  ".bgYellow);
        const line = `${"5".green}. Salir`;


        console.log(
            "  ".bgYellow +
            "      " +
            line + " ".repeat(width - line.length) +

            "  ".bgYellow
        );





        const volverLine = `${"6".green}. Ir al menú principal`;
        console.log(
            "  ".bgYellow +
            "      " + volverLine +
            " ".repeat(width - volverLine.length) +
            "  ".bgYellow
        );

        //pie

        console.log(emptyLine.bgYellow);

    }



    // metodo para mostrar los objetos instanciados en consola

    static mostrarClases(title, options, width) {
        console.clear();

        // Cabecera
        const line = "*".repeat(width);
        console.log(line.bgWhite);
        console.log(
            "**".rainbow.bgWhite +
            title.padStart((width + title.length) / 2, "-").padEnd(width - 4, "-") +
            "**".rainbow.bgWhite
        );

        console.log(line.bgWhite);

        // Contenido
        options.forEach((text) => {
            // separa por líneas manualmente si es muy largo
            const lines = text.split("\n");
            for (let raw of lines) {
                const linea = raw.replace(/\s+/g, " ").trim(); // limpia espacios extra
                const espacio = Math.max(0, width - 10 - linea.length);
                console.log(
                    "**".rainbow.bgWhite +
                    "      " +
                    linea +
                    " ".repeat(espacio) +
                    "**".rainbow.bgWhite
                );
            }

            // línea vacía entre objetos
            console.log("--".rainbow.bgWhite + "-".repeat(width - 4) + "--".rainbow.bgWhite);
        });

        // Pie
        console.log(line.bgWhite);
    }






    // metodo para gestionar las instancias de las clases AprendizLectiva
    static gestionLectiva() {
        //instanciar 3 objetos de la clase EtapaLectiva
        const aprendiz1 = new EtapaLectiva();
        const aprendiz2 = new EtapaLectiva();
        const aprendiz3 = new EtapaLectiva();
        //asignar valores a los atributos de los objetos
        aprendiz1.setnombreCompleto = "Daniel Di Marco";
        aprendiz1.setdocumento = 12345678;
        aprendiz1.setficha = "2023001";
        aprendiz1.setprograma = "Desarrollo de Software";
        aprendiz1.setnumeroTrimestre = 1;
        aprendiz1.setfechainicio = "2023-01-01";
        aprendiz1.setfechaTerminacion = "2023-06-30";

        aprendiz2.setnombreCompleto = "Juan Perez";
        aprendiz2.setdocumento = 23456789;
        aprendiz2.setficha = "2023003";
        aprendiz2.setprograma = "Desarrollo de Software";
        aprendiz2.setnumeroTrimestre = 2;
        aprendiz2.setfechainicio = "2023-07-01";
        aprendiz2.setfechaTerminacion = "2023-12-31";

        aprendiz3.setnombreCompleto = "Carlos Lopez";
        aprendiz3.setdocumento = 34567890;
        aprendiz3.setficha = "2023004";
        aprendiz3.setprograma = "Desarrollo de Software";
        aprendiz3.setnumeroTrimestre = 1;
        aprendiz3.setfechainicio = "2023-01-01";
        aprendiz3.setfechaTerminacion = "2023-06-30";
        //mostrar los datos de los objetos instanciados
        for (const aprendizLectiva of [aprendiz1, aprendiz2, aprendiz3]) {
            Utilidades.mostrarClases(
                "Gestión de Aprendices en Etapa Lectiva",
                [
                    aprendizLectiva.informacion(),
                    aprendizLectiva.estado(),

                ],
                120
            );
            readlineSync.keyInPause(colors.yellow("Presione espacio para continuar..."));
        }
    }



    // metodo para gestionar las instancias de las clases AprendizPractica
    static gestionPractica() {
        const aprendiz4 = new EtapaPracticas();
        const aprendiz5 = new EtapaPracticas();
        const aprendiz6 = new EtapaPracticas();
        //asignar valores a los atributos de los objetos
        aprendiz4.setnombreCompleto = "Maria Gomez";
        aprendiz4.setdocumento = 87654321;
        aprendiz4.setficha = "2023002";
        aprendiz4.setprograma = "Desarrollo de Software";
        aprendiz4.setmodalidad = "Presencial";
        aprendiz4.setfechainicio = "2023-07-01";
        aprendiz4.setfechaTerminacion = "2023-12-31";

        aprendiz5.setnombreCompleto = "Luis Martinez";
        aprendiz5.setdocumento = 45678901;
        aprendiz5.setficha = "2023005";
        aprendiz5.setprograma = "Desarrollo de Software";
        aprendiz5.setmodalidad = "Virtual";
        aprendiz5.setfechainicio = "2023-07-01";
        aprendiz5.setfechaTerminacion = "2023-12-31";

        aprendiz6.setnombreCompleto = "Ana Torres";
        aprendiz6.setdocumento = 56789012;
        aprendiz6.setficha = "2023006";
        aprendiz6.setprograma = "Desarrollo de Software";
        aprendiz6.setmodalidad = "Presencial";
        aprendiz6.setfechainicio = "2023-07-01";
        aprendiz6.setfechaTerminacion = "2023-12-31";
        //mostrar los datos de los objetos instanciados
        for (const aprendizPractica of [aprendiz4, aprendiz5, aprendiz6]) {
            Utilidades.mostrarClases(
                "Gestión de Aprendices en Etapa de Prácticas",
                [
                    aprendizPractica.informacion(),
                    aprendizPractica.estado()
                ],
                120
            );
            readlineSync.keyInPause(colors.yellow("Presione espacio para continuar..."));
        }
    }



    // metodo para gestionar las instancias de las clases InstructorPlanta
    static gestionPlanta() {
        //instanciar 3 objetos de la clase InstructorPlanta
        const instructor1 = new InstructorPlanta();
        const instructor2 = new InstructorPlanta();
        const instructor3 = new InstructorPlanta();
        //asignar valores a los atributos de los objetos
        instructor1.setnombreCompleto = "Carlos Perez";
        instructor1.setdocumento = 11223344;
        instructor1.setprofesion = "Ingeniero de Sistemas";
        instructor1.setsalarioBasico = 2000000;
        instructor1.setgrado = "5";
        instructor1.setfechavinculacion = "2020-03-15";

        instructor2.setnombreCompleto = "María López";
        instructor2.setdocumento = 22334455;
        instructor2.setprofesion = "Ingeniera de Sistemas";
        instructor2.setsalarioBasico = 3500000;
        instructor2.setgrado = "10";
        instructor2.setfechavinculacion = "2019-08-01";

        instructor3.setnombreCompleto = "Luis Martínez";
        instructor3.setdocumento = 33445566;
        instructor3.setprofesion = "Licenciado en Educación";
        instructor3.setsalarioBasico = 2800000;
        instructor3.setgrado = "3";
        instructor3.setfechavinculacion = "2021-05-20";
        //mostrar los datos de los objetos instanciados
        for (const instructorPlanta of [instructor1, instructor2, instructor3]) {
            Utilidades.mostrarClases(
                "Gestión de Instructores de Planta",
                [
                    instructorPlanta.informacion(),
                    instructorPlanta.estado(),
                    instructorPlanta.sueldo()
                ],
                120
            );
            readlineSync.keyInPause(colors.yellow("Presione espacio para continuar..."));
        }
    }



    // metodo para gestionar las instancias de las clases InstructorContrato
    static gestionContrato() {
        //instanciar 3 objetos de la clase InstructorContrato
        const instructor4 = new InstructorContrato();
        const instructor5 = new InstructorContrato();
        const instructor6 = new InstructorContrato();
        //asignar valores a los atributos de los objetos
        instructor4.setnombreCompleto = "Ana Gomez";
        instructor4.setdocumento = 22334455;
        instructor4.setprofesion = "Diseñadora Gráfica";
        instructor4.setsalarioBasico = 2500000;
        instructor4.setduracionContrato = "6 meses";
        instructor4.setfechaVinculacion = "2021-01-10";

        instructor5.setnombreCompleto = "Jorge Ramirez";
        instructor5.setdocumento = 33445566;
        instructor5.setprofesion = "Analista de Sistemas";
        instructor5.setsalarioBasico = 2700000;
        instructor5.setduracionContrato = "1 año";
        instructor5.setfechaVinculacion = "2022-06-15";

        instructor6.setnombreCompleto = "Sofia Castillo";
        instructor6.setdocumento = 44556677;
        instructor6.setprofesion = "Especialista en Marketing";
        instructor6.setsalarioBasico = 2600000;
        instructor6.setduracionContrato = "9 meses";
        instructor6.setfechaVinculacion = "2023-02-20";
        //mostrar los datos de los objetos instanciados
        for (const instructorContrato of [instructor4, instructor5, instructor6]) {
            Utilidades.mostrarClases(
                "Gestión de Instructores por Contrato",
                [
                    instructorContrato.informacion(),
                    instructorContrato.estado(),


                ],
                120
            );
            readlineSync.keyInPause(colors.yellow("Presione espacio para continuar..."));
        }
    }



}

//exportar las clases
const clases = {
    Persona,
    Aprendiz,
    Instructor,
    InstructorPlanta,
    InstructorContrato,
    Utilidades
};
export default clases;
