//AUTOR: DANIEL ELIAS DI MARCO BORGES
//FICHA : 3293689
//DESCRIPCION:
// mostramos de manera organizada en plantillas
// =========reto 2=================
//producto grado
//producto software
//revista
//libro

import colors from "colors"
import readlineSync from 'readline-sync';


//clase producto

class Producto {

    #codigo
    #titulo
    #autor

    constructor() {

        this.#autor = ""
        this.#codigo = ""
        this.#titulo = ""



    }

    //metodos get y set

    // get codigo
    get getCodigo() {
        return this.#codigo
    }

    // set codigo 
    set setCodigo(codigo) {
        this.#codigo = codigo
    }


    // get titulo
    get getTitulo() { return this.#titulo }
    // set titulo
    set setTitulo(titulo) {
        this.#titulo = titulo
    }

    // get autor
    get getAutor() { return this.#autor }

    // set autor
    set setAutor(autor) {
        this.#autor = autor
    }



    //metodo información
    informacion() {

        console.log(`Código: ${this.getCodigo} - Título: ${this.getTitulo} - Autor: ${this.getAutor}`)


    }



}

//clase hija ProductoImpreso
class ProductoImpreso extends Producto {

    #editorial
    #año
    #precio

    constructor() {
        super()
        this.#editorial = ""
        this.#año = ""
        this.#precio = 0
    }



    // getter y setter

    //get editorial
    get getEditorial() {
        return this.#editorial
    }
    //set editorial
    set setEditorial(editorial) {
        this.#editorial = editorial
    }

    // get año
    get getAño() {
        return this.#año
    }
    // set año
    set setAño(año) {
        this.#año = año
    }

    // get precio
    get getPrecio() {
        return this.#precio
    }
    // set precio
    set setPrecio(precio) {
        this.#precio = precio
    }


    //método información

    informacion() {


        return `Editorial: ${this.getEditorial} - Año: ${this.getAño} - Precio: $${this.getPrecio}`




    }



}
//clase hija ProductoGrado

class ProductoGrado extends Producto {

    #tiempoDuracion
    #medioTecnologico

    constructor() {


        super()

        this.#tiempoDuracion = 0
        this.#medioTecnologico = ""

    }

    //getter y setter

    // get tiempoDuracion
    get getTiempoDuracion() {
        return this.#tiempoDuracion
    }
    // set tiempoDuracion
    set setTiempoDuracion(tiempoDuracion) {
        this.#tiempoDuracion = tiempoDuracion
    }
    // get medioTecnologico
    get getMedioTecnologico() {
        return this.#medioTecnologico
    }

    // set medioTecnologico
    set setMedioTecnologico(medioTecnologico) {
        this.#medioTecnologico = medioTecnologico
    }




    //metodo información
    informacion() {

        return `Tiempo de Duración: ${this.getTiempoDuracion} horas - Medio Tecnológico: ${this.getMedioTecnologico}`


    }
}




//clase hija Producto Software

class ProductoSoftware extends Producto {

    #version
    #sistemaOperativo

    constructor() {
        super()
        this.#version = ""
        this.#sistemaOperativo = 0



    }

    //getter y setter
    // get version
    get getVersion() {
        return this.#version
    }
    // set version
    set setVersion(version) {
        this.#version = version
    }
    // get sistemaOperativo
    get getSistemaOperativo() {
        return this.#sistemaOperativo
    }
    // set sistemaOperativo
    set setSistemaOperativo(sistemaOperativo) {
        this.#sistemaOperativo = sistemaOperativo
    }

    //metodo información
    informacion() {

        return `Versión: ${this.getVersion} - Sistema Operativo: ${this.getSistemaOperativo}`
    }


}

//clase revista hija de ProductoImpreso

class Revista extends ProductoImpreso {


    #volumen

    constructor() {
        super()
        this.#volumen = ""



    }
    //getter y setter
    // get volumen
    get getVolumen() {
        return this.#volumen
    }
    // set volumen
    set setVolumen(volumen) {
        this.#volumen = volumen
    }


    //metodo información

    informacion() {

        return `Volumen: ${this.getVolumen}`
    }



    estado() {

        return ` la revista ${this.getTitulo} cuyo autor es ${this.getAutor}  está en estado de publicación a un precio de $${this.getPrecio}`

    }

}

//clase libro hija de ProductoImpreso
class libro extends ProductoImpreso {


    #idioma


    constructor() {
        super()
        this.#idioma = ""
    }

    //getter y setter
    //idioma
    get getIdioma() {
        return this.#idioma
    }

    // set idioma
    set setIdioma(idioma) {
        this.#idioma = idioma
    }

    //metodo información

    informacion() {


        return `Idioma: ${this.getIdioma}`
    }


    //método estado
    estado() {

        return ` El libro ${this.getTitulo} cuyo autor es ${this.getAutor}  está en estado de venta a un precio de $${this.getPrecio}`


    }

}




//clase Utilidades
class Utilidades {

    //metodo estaticos para hacer menú

    static mostrarMenu(title, options, width) {
        console.clear();
        const emptyLine = "*".rainbow.repeat(width);

        //encabezado
        console.log(emptyLine.bgYellow)

        console.log(
            "  ".bgYellow + "=".rainbow.repeat(Math.floor((width - 4 - title.length) / 2)) +
            title + "=".rainbow.repeat((width - 4 - title.length) - Math.floor((width - 4 - title.length) / 2)) +
            "  ".bgYellow
        );
        console.log(emptyLine.bgYellow);


        //opciones numeradas
        options.forEach((opt, index) => {
            const line = `${String(index + 1).green}. ${opt}`;

            console.log(
                "  ".bgYellow +
                "      " +
                line + " ".repeat(width - line.length) +
                "  ".bgYellow
            );
        });

        // espacio + opcion de salida

        console.log("  ".bgYellow + "-".red.repeat(width - 4) + "  ".bgYellow);
        const line = `${"5".green}. Salir`;

        console.log(
            "  ".bgYellow +
            "      " +
            line + " ".repeat(width - line.length) +
            "  ".bgYellow
        );




        const volverLine = `${"6".green}. Ir al menú principal`;
        console.log(
            "  ".bgYellow +
            "      " + volverLine +
            " ".repeat(width - volverLine.length) +
            "  ".bgYellow
        );

        //pie

        console.log(emptyLine.bgYellow);

    }
    //========================================
    //PLANTILLA PARA MOSTRAR CLASES
    //===========================================
    static mostrarClases(title, options, width) {
        console.clear();

        // Cabecera
        const line = "*".repeat(width);
        console.log(line.bgWhite);
        console.log(
            "**".rainbow.bgWhite +
            title.padStart((width + title.length) / 2, "-").padEnd(width - 4, "-") +
            "**".rainbow.bgWhite
        );

        console.log(line.bgWhite);

        // Contenido
        options.forEach((text) => {
            // separa por líneas manualmente si es muy largo
            const lines = text.split("\n");
            for (let raw of lines) {
                const linea = raw.replace(/\s+/g, " ").trim(); // limpia espacios extra
                const espacio = Math.max(0, width - 10 - linea.length);
                console.log(
                    "**".rainbow.bgWhite +
                    "      " +
                    linea +
                    " ".repeat(espacio) +
                    "**".rainbow.bgWhite
                );
            }

            // línea vacía entre objetos
            console.log("--".rainbow.bgWhite + "-".repeat(width - 4) + "--".rainbow.bgWhite);
        });

        // Pie
        console.log(line.bgWhite);
    }





    //instancias y prueba de las clases
//===========================================
//GRADO
//===========================================
    static gestionGrado() {
        //crear instancias de ProductoGrado

        const grado1 = new ProductoGrado()
        const grado2 = new ProductoGrado()
        const grado3 = new ProductoGrado()
        //INSTANCIAS CREADAS
        //asignar valores a las instancias
        grado1.setCodigo = "C001"
        grado1.setTitulo = "Curso de JavaScript"
        grado1.setAutor = "Academia Web"
        grado1.setTiempoDuracion = 40
        grado1.setMedioTecnologico = "Plataforma Online"

        //INSTANCIA 2

        grado2.setCodigo = "C002"
        grado2.setTitulo = "Curso de Python"
        grado2.setAutor = "Code Academy"
        grado2.setTiempoDuracion = 50
        grado2.setMedioTecnologico = "Plataforma Online"


        //INSTANCIA 3
        grado3.setCodigo = "C003"
        grado3.setTitulo = "Curso de Java"
        grado3.setAutor = "Dev Institute"
        grado3.setTiempoDuracion = 60
        grado3.setMedioTecnologico = "Plataforma Online"



        //mostrar la información de las instancias
        for (const grado of [grado1, grado2, grado3]) {
            Utilidades.mostrarClases('Producto de Grado', [
                grado.informacion()
            ], 120);
            readlineSync.keyInPause(colors.yellow("Presione espacio para continuar..."));
        }





    }
//===========================================
//SOFTWARE
//===========================================
    static gestionSoftware() {

        //crear instancias de ProductoSoftware
        const software1 = new ProductoSoftware()
        const software2 = new ProductoSoftware()
        const software3 = new ProductoSoftware()

        //INSTANCIAS CREADAS
        //INSTANCIA 1
        //asignar valores a las instancias
        software1.setCodigo = "S001"
        software1.setTitulo = "Editor de Código"
        software1.setAutor = "DevSoft"
        software1.setVersion = "1.0.0"
        software1.setSistemaOperativo = "Windows, macOS, Linux"


        //INSTANCIA 2
        software2.setCodigo = "S002"
        software2.setTitulo = "Antivirus Pro"
        software2.setAutor = "SecureTech"
        software2.setVersion = "3.5.2"
        software2.setSistemaOperativo = "Windows"


        //INSTANCIA 3
        software3.setCodigo = "S003"
        software3.setTitulo = "PhotoEdit Plus"
        software3.setAutor = "ImageSoft"
        software3.setVersion = "2.1.0"
        software3.setSistemaOperativo = "macOS, Windows"

        //mostrar la información de las instancias
        for (const software of [software1, software2, software3]) {
            Utilidades.mostrarClases('Producto de Software', [
                software.informacion()
            ], 120);

            readlineSync.keyInPause(colors.yellow("Presione espacio para continuar..."));
        }




    }

//===========================================
//REVISTA
//===========================================
    static gestionRevista() {


        //crear instancias de Revista
        const revista1 = new Revista()
        const revista2 = new Revista()
        const revista3 = new Revista()
        //INSTANCIAS CREADAS
        //INSTANCIA 1
        //asignar valores a las instancias
        revista1.setCodigo = "R001"
        revista1.setTitulo = "Revista de Tecnología"
        revista1.setAutor = "Juan Pérez"
        revista1.setEditorial = "Tech Publishers"
        revista1.setAño = "2023"
        revista1.setPrecio = 15.99
        revista1.setVolumen = "Volumen 10"

        //INSTANCIA 2

        revista2.setCodigo = "R002"
        revista2.setTitulo = "Revista de Ciencia"
        revista2.setAutor = "Ana Gómez"
        revista2.setEditorial = "Science World"
        revista2.setAño = "2022"
        revista2.setPrecio = 12.50
        revista2.setVolumen = "Volumen 8"


        //INSTANCIA 3
        revista3.setCodigo = "R003"
        revista3.setTitulo = "Revista de Arte"
        revista3.setAutor = "Luis Martínez"
        revista3.setEditorial = "Artistic Minds"
        revista3.setAño = "2024"
        revista3.setPrecio = 18.75
        revista3.setVolumen = "Volumen 12"
        //mostrar la información de las instancias
        for (const revista of [revista1, revista2, revista3]) {
            Utilidades.mostrarClases('Revista', [
                revista.informacion(),
                revista.estado()
            ], 120);

            readlineSync.keyInPause(colors.yellow("Presione espacio para continuar..."));
        }
    }

//===========================================
//LIBRO
//===========================================
    static gestionLibro() {
        //crear instancias de Libro
        const libro1 = new libro()
        const libro2 = new libro()
        const libro3 = new libro()

        //INSTANCIAS CREADAS
        //INSTANCIA 1
        //asignar valores a las instancias
        libro1.setCodigo = "L001"
        libro1.setTitulo = "Aprendiendo Node.js"
        libro1.setAutor = "María Gómez"
        libro1.setEditorial = "Code Books"
        libro1.setAño = "2022"
        libro1.setPrecio = 29.99
        libro1.setIdioma = "Español"


        //INSTANCIA 2
        libro2.setCodigo = "L002"
        libro2.setTitulo = "Introducción a Python"
        libro2.setAutor = "Carlos López"
        libro2.setEditorial = "Programming Press"
        libro2.setAño = "2021"
        libro2.setPrecio = 24.50
        libro2.setIdioma = "Inglés"

        //INSTANCIA 3
        libro3.setCodigo = "L003"
        libro3.setTitulo = "Desarrollo Web con JavaScript"
        libro3.setAutor = "Sofía Ramírez"
        libro3.setEditorial = "Web Dev Publishers"
        libro3.setAño = "2023"
        libro3.setPrecio = 34.75
        libro3.setIdioma = "Español"



        //mostrar la información de las instancias

        for (const libro of [libro1, libro2, libro3]) {
            Utilidades.mostrarClases('Libros',
                [
                    libro.informacion(),
                    libro.estado()
                ], 120);
            readlineSync.keyInPause(colors.yellow("Presione espacio para continuar..."));
        }





    }




}






const reto2 = {
    Producto,
    ProductoImpreso,
    ProductoGrado,
    ProductoSoftware,
    Revista,
    libro,
    Utilidades
}


export default reto2;