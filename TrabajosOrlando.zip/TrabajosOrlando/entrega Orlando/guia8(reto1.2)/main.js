//AUTOR: DANIEL ELIAS DI MARCO BORGES
//FICHA : 3293689
//DESCRIPCION:
//menu donde veamos de forma organizada :
//==========reto 1=================
//aprendiz etapa lectiva
//aprendiz etapa practicA
//instuctorPlanta
//instrucotrContrato
//==========reto 2=================
//producto grado
//producto software
//revista
//libro


import colors from "colors"
import readlineSync from "readline-sync"
import clases from "./my_modules/Persona.js"
import reto2 from "./my_modules/reto2.js"

let opt;
let salir = true;

//mostrar el menu
do {


    console.log("|-------------------------------|".green);
    console.log("|     Gestión de Clases         |".green);
    console.log("|-------------------------------|".green);
    console.log("| 1. reto 1                     |".yellow);
    console.log("| 2. reto 2                     |".yellow);
    console.log("| 3. Salir                      |".yellow);
    console.log("|-------------------------------|".green);

// leer la opción del usuario
    opt = readlineSync.questionInt(colors.yellow('Seleccione una opción: '));

    switch (opt) {


        case 1:
    //mostrar el submenú
            clases.Utilidades.mostrarMenu(`Gestión de clases`, [
                '  Aprendiz Etapa Lectiva',
                '  Aprendiz Etapa Práctica',
                '  Instructor Planta',
                '  Instructor Contrato',], 50);

            //leer la opción del usuario
            opt = readlineSync.questionInt(colors.yellow('Seleccione una opción: '));

            switch (opt) {
                case 1:
                    clases.Utilidades.gestionLectiva();//muestra en una plantilla los datos del aprendiz en etapa lectiva 
                    break;
                case 2:
                    clases.Utilidades.gestionPractica();//muestra en una plantilla los datos del aprendiz en etapa practica
                    break;
                case 3:
                    clases.Utilidades.gestionPlanta();//muestra en una plantilla los datos del instructor planta
                    break;
                case 4:
                    clases.Utilidades.gestionContrato();//muestra en una plantilla los datos del instructor contrato
                    break;
                case 5:
                    salir = false;

                    console.log(colors.green('¡Gracias por usar el programa!'));
                    break;
                //volver al menu principal
                case 6:
                    console.clear();
                    break;



            }
            break;

        case 2:

     //mostrar el submenú
            reto2.Utilidades.mostrarMenu(`Gestión de Productos`, [
                '  Producto Grado',
                '  Producto Software',
                '  Revista',
                '  Libro',], 50);
//leer la opción del usuario
            opt = readlineSync.questionInt(colors.yellow('Seleccione una opción: '));

            switch (opt) {

                case 1:
                    reto2.Utilidades.gestionGrado();//muestra en una plantilla los datos del producto grado
                    break;
                case 2:
                    reto2.Utilidades.gestionSoftware();//muestra en una plantilla los datos del producto software
                    break;
                case 3:
                    reto2.Utilidades.gestionRevista();//muestra en una plantilla los datos de la revista
                    break;
                case 4:
                    reto2.Utilidades.gestionLibro();//muestra en una plantilla los datos del libro
                    break;
                case 5:
                    salir = false;

                    console.log(colors.green('¡Gracias por usar el programa!'));
                    break;
                case 6:
                    console.clear();
                    //volver al menu principal
                    break;
            }
            break;



        case 3:
            salir = false;
            console.log(colors.green('¡Gracias por usar el programa!'));
            break;

    }



} while (salir);
