//====================================================
// MENU DE EJERCICIOS 
// ECHO POR : DANIEL ELIAS DI MARCO BORGES
// FICHA : 3293689
// FECHA: 27/11/2025
//====================================================
// DESCRIPCIÓN: MENÚ PRINCIPAL QUE PERMITE 
// ACCEDER A LOS DISTINTOS EJERCICIOS REALIZADOS
// EN LA CLASE DE PROGRAMACIÓN.
//====================================================

import readlineSync from "readline-sync";
import clase2 from "./my_modules/ejercicio2.js";
import figuras from "./my_modules/ejercicio1.js";
import operaciones from "./my_modules/funciones.js";
import plantilla from "./my_modules/plantillas.js";
import ConsolaResultados from "./my_modules/ejercicio3.js";

// Bandera del ciclo principal (siempre es true)
const salir = true;

// Variable para leer opción principal del menú
let opt;

// Array donde se guardarán TODAS las figuras creadas en tiempo de ejecución
const figurasCreadas = [];

// Array donde se guardarán TODAS las cuentas bancarias creadas
let cuentasCreadas = [];

// -------------------------------MENU PRINCIPAL--------------------------------
do {
  
    // Mostrar menú principal
    operaciones.mostrarMenu();

    // Leer opción digitada por el usuario
    opt = readlineSync.questionInt(' digita la opción deseada: '.green);

    switch (opt) {


        //  CASE 1: CREACIÓN DE FIGURAS (CUADRADO O CÍRCULO)

        case 1:
            console.clear();

            // Opciones que se le mostrarán al usuario
            const opcionesFigura = [
                "1. Crear cuadrado",
                "2. Crear círculo"
            ];

            // Mostrar submenú personalizado usando plantilla
            plantilla.mostrarPlantilla("CREACIÓN DE FIGURA", opcionesFigura, 60);

            // Leer el tipo de figura que quiere crear el usuario
            const tipoFigura = readlineSync.questionInt("Elige el tipo de figura: ");

            // si elije cuadrado
            switch (tipoFigura) {
                case 1:

                    const lado = readlineSync.questionFloat("Ingresa el lado del cuadrado: ");

                    // Se crea un objeto de la clase Cuadrado, enviando el lado
                    const cuadrado = new figuras.Cuadrado(lado);

                    // Se guarda el cuadrado creado en el array general
                    figurasCreadas.push(cuadrado);

                    console.log("Cuadrado creado y guardado!".green);

                    break;


                // si elije circulo
                case 2:

                    const radio = readlineSync.questionFloat("Ingresa el radio del círculo: ");

                    // Se crea un objeto de la clase Circulo, enviando el radio
                    const circulo = new figuras.Circulo(radio);

                    // Se guarda en el array general
                    figurasCreadas.push(circulo);

                    console.log("Círculo creado y guardado!".green);
                    break;

                // si elije una opcion inválida
                default: {
                    console.log("Opción no válida".red);
                }

                    break;
            }


            break;


        //  CASE 2: SUBMENÚ DE CUENTAS BANCARIAS

        case 2:
            console.clear();
            console.log('=== OPCIÓN 2: CUENTAS BANCARIAS ==='.yellow);

            let opcionCuenta;

            // Submenú de cuentas bancarias
            do {
                 // Opciones del submenú
                const opcionesSubmenu = [
                    "1. Crear una nueva cuenta",
                    "2. Ver cuentas creadas",
                    "3. Operar una cuenta (depositar/retirar/saldo)",
                    "4. Volver al menú principal"
                ];

                // Mostrar plantilla decorada
                plantilla.mostrarPlantilla("SUBMENÚ CUENTAS", opcionesSubmenu, 60);
               //leer la opcion que dijite el usuario
                opcionCuenta = readlineSync.questionInt("Elige una opción: ");

                switch (opcionCuenta) {

                    // OPCIÓN 1: CREAR CUENTA 
                    case 1:
                        console.clear();
                        console.log("=== CREACIÓN DE CUENTA ===".bgWhite.blue);

                        // Instancia de la clase CuentaBancaria
                        const nueva = new clase2.CuentaBancaria();

                        // Llenar datos de la cuenta bancaria
                        let documentoValido = false;
                        let documento;
                         //validacion de documento
                        while (!documentoValido) {
                            documento = readlineSync.question("Documento: ".bgYellow.black);
                            //validacion de que el doumento tenga entre 7 y 10 digitos
                            if (/^\d{7,10}$/.test(documento)) {
                                documentoValido = true;
                            } else {
                                //mensaje de error
                                console.log("Documento inválido. Debe tener entre 7 y 10 dígitos.\n".red);
                            }
                        }
                        //===================
                        //asignamos valores 
                        //===================
                        nueva.Documento = documento;
                        
                        // Validación de Nombre (solo letras)
                        let nombreValido = false;
                        let nombre;
                        while (!nombreValido) {
                            nombre = readlineSync.question("Nombre: ".bgYellow.black);
                            //validacion de que el nombre solo contenga letras y espacios
                            if (/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(nombre) && nombre.trim() !== "") {
                                nombreValido = true;
                            } else {
                                console.log("Nombre inválido. Solo se aceptan letras.\n".red);
                            }
                        }
                        nueva.Nombre = nombre;
                        
                        // Validación de Apellido (solo letras)
                        let apellidoValido = false;
                        let apellido;
                        while (!apellidoValido) {
                            apellido = readlineSync.question("Apellido: ".bgYellow.black);
                            //validacion de que el apellido solo contenga letras y espacios
                            if (/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(apellido) && apellido.trim() !== "") {
                                apellidoValido = true;
                            } else {
                                console.log("Apellido inválido. Solo se aceptan letras.\n".red);
                            }
                        }
                        nueva.Apellido = apellido;


                        // validacion de tipo de cuenta

                        let tipoValido = false;
                        let tipo;

                        while (!tipoValido) {
                            //========================    
                            // mini menu de tipos de cuenta
                            //========================
                            console.log("\nTipos de cuenta disponibles:".bgWhite.green);
                            console.log("---------------------------".green);
                            console.log('|'.bgYellow, ("1. Ahorros"), '            ', '|'.bgYellow);
                            console.log('|'.bgYellow, ("2. Corriente"), '          ', '|'.bgYellow);
                            console.log('|'.bgYellow, ("3. Nequi"), '              ', '|'.bgYellow);
                            console.log('|'.bgYellow, ("4. Daviplata"), '          ', '|'.bgYellow);
                            console.log("---------------------------".green);

                            const opcion = readlineSync.questionInt("Elige el tipo de cuenta (1-4): ".yellow);


                            switch (opcion) {
                              //=======================  
                              // asignacion de tipo de cuenta
                              //=======================
                                case 1:
                                    tipo = "Ahorros";
                                    tipoValido = true;
                                    break;
                                case 2:
                                    tipo = "Corriente";
                                    tipoValido = true;
                                    break;
                                case 3:
                                    tipo = "Nequi";
                                    tipoValido = true;
                                    break;
                                case 4:
                                    tipo = "Daviplata";
                                    tipoValido = true;
                                    break;
                                default:
                                    console.log("  Opción inválida, intenta nuevamente.\n".red);

                            }


                        }
                        nueva.TipoCuenta = tipo;
                        nueva.NumeroCuenta = readlineSync.questionInt("Número de cuenta: ".bgYellow.black);
                        nueva.Saldo = parseFloat(readlineSync.questionInt("Saldo inicial: ".bgYellow.black));
                        // Agregar la nueva cuenta al array de cuentas creadas
                        cuentasCreadas.push(nueva);
                        console.clear();
                        console.log("\nCuenta creada exitosamente!\n".bgGreen.white);

                        break;
                    //  OPCIÓN 2: VER CUENTAS 
                    case 2:
                        console.clear();
                        console.log("=== LISTA DE CUENTAS CREADAS ===".bgWhite.magenta);
                        // mira el array de cuentas creadas y si no hay muestra mensaje de "error"
                        if (cuentasCreadas.length === 0) {
                            console.log("No hay cuentas creadas todavía.\n".red);
                        }
                        else {
                            // Recorre el array y muestra cada cuenta
                            cuentasCreadas.forEach((cuenta, indice) => {
                                console.log(`      
                ${indice + 1}. ${cuenta.Nombre} ${cuenta.Apellido}
                Documento: ${cuenta.Documento}
                Nº Cuenta : ${cuenta.NumeroCuenta}
                Tipo      : ${cuenta.TipoCuenta}
                Saldo     : ${cuenta.Saldo}
                        `.yellow); // muestra los datos de cada cuenta hciendo que el indice suba en 1
                            });
                        }
                        break;

                    //  OPCIÓN 3: OPERAR UNA CUENTA 
                    case 3:
                        console.clear();
                        console.log("=== OPERAR UNA CUENTA ===".yellow);

                        // Verifica si hay cuentas creadas antes de operar
                        if (cuentasCreadas.length === 0) {
                            console.log("No hay cuentas para operar.\n".red);
                            break;
                        }

                        // Buscar la cuenta por el número (leer como número entero para comparar correctamente)
                        const buscar = readlineSync.questionInt("Digite el número de cuenta que desea operar: ");
                        const cuenta = cuentasCreadas.find(cuenta => cuenta.NumeroCuenta === buscar); // find busca en el array la cuenta que coincida
                        // si no encuentra la cuenta muestra mensaje de error
                        if (!cuenta) {
                            console.log("Cuenta no encontrada.\n".red);
                            break;
                        }

                        let opSub;

                        // SUBMENÚ DE OPERACIONES DE UNA CUENTA
                        do {
                            const OpcionOperarCuenta = [

                                "1. Depositar",
                                "2. Retirar",
                                "3. Ver saldo",
                                "4. Volver"


                            ]
                            // Mostrar plantilla decorada
                            plantilla.mostrarPlantilla("OPERAR CUENTA", OpcionOperarCuenta, 50);


                            opSub = readlineSync.questionInt("Elige una opción: ");

                            switch (opSub) {

                                case 1:
                                    // metodo para depositar
                                    const depositar = parseFloat(readlineSync.question("Monto a depositar: ".bgWhite.cyan));
                                    cuenta.depositar(depositar);
                                    break;

                                case 2:
                                    // metodo para retirar
                                    const retirar = parseFloat(readlineSync.question("Monto a retirar: ".bgWhite.cyan));
                                    cuenta.retirar(retirar);
                                    break;

                                case 3:
                                    // metodo para ver saldo
                                    cuenta.saldototal();
                                    break;

                            }

                        } while (opSub !== 4);

                        break;

                    //  OPCIÓN 4: REGRESAR AL MENÚ PRINCIPAL 
                    case 4:
                        console.log("Volviendo al menú principal...\n".yellow);
                        break;

                }

            } while (opcionCuenta !== 4);

            break;


        //  CASE 3: MOSTRAR TODAS LAS FIGURAS CREADAS

        case 3:
            console.clear();
        case 3:
            // Mostrar todas las figuras creadas
            ConsolaResultados.mostrarLista(figurasCreadas);
            break;




        //  CASE 4: SALIR DEL PROGRAMA

        case 4:
            console.clear();
            console.log("Programa finalizado...".red);
            process.exit(0);

    }

} while (salir);   // Fin del ciclo principal
