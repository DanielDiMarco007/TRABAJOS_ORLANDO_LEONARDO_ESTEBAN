
import readlineSync from "readline-sync"
import colors from "colors"


//mostrar menú 
function mostrarMenu() {
    //mostrar menú principal

    console.log('========================================================'.red.bgWhite)
    console.log("                    menu principal                      ".bgWhite.black)
    console.log('========================================================'.red.bgWhite)
    console.log('=='.bgRed, ("1) Figuras "), '                                      ', '=='.bgRed)
    console.log('=='.bgRed, ("2) Cuenta Bancaria"), '                               ', '=='.bgRed)
    console.log('=='.bgRed, ("3) Mostrar Figuras "), '                              ', '=='.bgRed)
    console.log('=='.bgRed, ("4) salir "), '                                        ', '=='.bgRed)
    console.log('========================================================'.red.bgWhite)
}


function menufiguras() {

    //mostrar menú de figuras
    console.log("1) cuadrado")
    console.log("2) circulo")
    console.log("3) salir")


}



//exportamos para darle uso en main.js
const operaciones = { mostrarMenu, menufiguras }


export default operaciones