
//====================================================
// MENU DE EJERCICIOS 
// ECHO POR : DANIEL ELIAS DI MARCO BORGES
// FICHA : 3293689
// FECHA: 27/11/2025
//====================================================
/*
============================================================
 EJERCICIO 2: PROYECTO DE ENCAPSULAMIENTO
 -----------------------------------------------------------
 - Crear una clase CuentaBancaria con propiedades privadas:
      #documento, #nombre, #apellidos, #tipoCuenta,
      #numeroCuenta, #saldo

 - Implementar métodos:
      depositar(), retirar(), saldototal()
============================================================
*/

// ---------------------------------------------------------
//               DEFINICIÓN DE LA CLASE
// ---------------------------------------------------------

class CuentaBancaria {

    // Propiedades privadas (solo accesibles dentro de la clase)
    #documento
    #nombre
    #apellidos
    #tipoCuenta
    #numeroCuenta
    #saldo

    constructor() {
        // Valores iniciales de la cuenta
        this.#documento = "";
        this.#nombre = "";
        this.#apellidos = "";
        this.#tipoCuenta = "";
        this.#numeroCuenta = "";
        this.#saldo = 0;   // saldo inicia en 0
    }

    // -----------------------------------------------------
    //       MÉTODOS GET Y SET (ENCAPSULAMIENTO)
    // -----------------------------------------------------
    // Estos métodos permiten leer y modificar las propiedades
    // SIN acceder directamente a ellas desde afuera.


    // get documento
    get Documento() 
    { return this.#documento; }

    // set documento
    set Documento(nuevo) 
    { this.#documento = nuevo; }

    // get nombre
    get Nombre()
     { return this.#nombre; }

    // set nombre
    set Nombre(nuevo) 
    { this.#nombre = nuevo; }

    // get apellido
    get Apellido() 
    { return this.#apellidos; }

    // set apellido
    set Apellido(nuevo) 
    { this.#apellidos = nuevo; }

    // get tipoCuenta
    get TipoCuenta() 
    { return this.#tipoCuenta; }

    // set tipoCuenta
    set TipoCuenta(nuevo) 
    { this.#tipoCuenta = nuevo; }

    // get numeroCuenta
    get NumeroCuenta() 
    { return this.#numeroCuenta; }

    // set numeroCuenta
    set NumeroCuenta(nuevo) 
    { this.#numeroCuenta = nuevo; }

    // get saldo
    get Saldo()
     { return this.#saldo; }

    // set saldo
    set Saldo(nuevo) 
    { this.#saldo = nuevo; }

    // -----------------------------------------------------
    //                MÉTODO DEPOSITAR
    // -----------------------------------------------------
    /*
        - Recibe un valor.
        - Si es menor o igual a 0 → error.
        - Si es válido, lo suma al saldo actual.
        - Usa el operador += como forma corta de:
              this.#saldo = this.#saldo + valor;
    */
    depositar(valor) {
        if (valor <= 0) {
            console.log("El valor a depositar debe ser mayor que 0.".red);
            return;
        }

        this.Saldo += valor;  // Suma al saldo
        console.log(`Se depositaron $${valor} a la cuenta ${this.NumeroCuenta}. Nuevo saldo: $${this.Saldo}`.green);
    }

    // -----------------------------------------------------
    //                MÉTODO RETIRAR
    // -----------------------------------------------------
    /*
        - Recibe un valor.
        - Si es <= 0 → ERROR.
        - Si el valor supera el saldo → ERROR.
        - Si está bien, resta del saldo.
        - Usa el operador -= como forma corta de:
              this.#saldo = this.#saldo - valor;
    */
    retirar(valor) {
        // Validaciones
        if (valor <= 0) {
            console.log("El valor a retirar debe ser mayor que 0.".red);
            return;
        }

        // Verificar fondos suficientes
        if (valor > this.Saldo) {
            console.log("Fondos insuficientes para retirar.".red);
            return;
        }

        this.Saldo -= valor;  // Resta al saldo
        console.log(`Se retiraron $${valor} de la cuenta ${this.NumeroCuenta}. Saldo restante: $${this.Saldo}`.yellow);
    }

    // -----------------------------------------------------
    //                MÉTODO SALDOTOTAL
    // -----------------------------------------------------
    /*
        - Solo muestra el saldo actual de la cuenta
    */
    saldototal() {
        console.log(`Saldo actual de la cuenta ${this.NumeroCuenta}: $${this.Saldo}`.cyan);
    }
}

// Exportar la clase para usarla en main.js
const clase2 = { CuentaBancaria };
export default clase2;
