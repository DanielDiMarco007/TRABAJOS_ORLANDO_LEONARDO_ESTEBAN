
//====================================================
// MENU DE EJERCICIOS 
// ECHO POR : DANIEL ELIAS DI MARCO BORGES
// FICHA : 3293689
// FECHA: 27/11/2025
//====================================================

// Ejercicio 1 FIGURAS 
// --------------------------------------------------
// OBJETIVO:
// Crear una clase base "Figura" con un método calcularArea() que debe ser
// sobrescrito en las clases hijas.
// Crear clases: Cuadrado y Circulo.
// Cada clase calcula su propia área según corresponda.
// El archivo exporta las clases para usarlas desde el menú principal.
// --------------------------------------------------



//  CLASE ABSTRACTA: FIGURA

class Figura {

    // Método que TODAS las subclases deben implementar obligatoriamente.
    // Si una subclase no lo implementa, generará un error.
    calcularArea() {
        throw new Error("Este método debe ser implementado en las subclases");
    }
}




//  CLASE CUADRADO (hereda de Figura)

class Cuadrado extends Figura {

    // Constructor recibe "lado" y lo guarda como propiedad del objeto
    constructor(lado) {
        super();  // Llama al constructor de la clase padre (obligatorio)
        this.lado = lado;
    }

    // Implementación del método calcularArea para un cuadrado
    calcularArea() {
        return this.lado * this.lado; // lado^2
    }
}




//  CLASE CIRCULO (hereda de Figura)

class Circulo extends Figura {

    // Constructor recibe el radio del círculo
    constructor(radio) {
        super();
        this.radio = radio;
    }

    // Implementación del método calcularArea para un círculo
    calcularArea() {
        return Math.PI * this.radio * this.radio;  // π * r^2
    }
}




//  EXPORTACIÓN DE LAS CLASES

const figuras = { Cuadrado, Circulo };

export default figuras;
