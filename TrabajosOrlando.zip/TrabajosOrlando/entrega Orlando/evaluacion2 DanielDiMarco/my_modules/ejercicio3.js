
//====================================================
// MENU DE EJERCICIOS 
// ECHO POR : DANIEL ELIAS DI MARCO BORGES
// FICHA : 3293689
// FECHA: 27/11/2025
//====================================================

// Ejercicio 3: Clase para mostrar resultados
// -------------------------------------------------------------
// Esta clase se encarga de mostrar TODAS las figuras creadas.
// Recibe un arreglo de objetos (Cuadrado o Circulo)
// Y muestra:
//     • El tipo de figura (Cuadrado / Circulo)
//     • El área con dos decimales
// -------------------------------------------------------------

class ConsolaResultados {

    // Método estático: se puede llamar sin crear un objeto
    static mostrarLista(figurasCreadas) {

        console.clear();
        console.log("=== LISTA DE FIGURAS CREADAS ===\n".green);

        // Si no hay figuras, no sigue
        if (figurasCreadas.length === 0) {
            console.log("Todavía no hay figuras creadas.\n".red);
            return;
        }

        // Recorremos el arreglo y mostramos cada figura
        figurasCreadas.forEach((figura, indice) => {

            // figura.constructor.name -> devuelve "Cuadrado" o "Circulo"
            const nombre = figura.constructor.name;

            // calcularArea() -> devuelve el área calculada según la clase
            const area = figura.calcularArea();

            console.log(
                // muestra el indice incrementando en 1 , el nombre de la forma, muestra el area con 2 decimales
                `${indice + 1}. ${nombre} -> Área: ${area.toFixed(2)}`
            );
        });

        console.log("\n=================================\n");
    }
}

export default ConsolaResultados;
