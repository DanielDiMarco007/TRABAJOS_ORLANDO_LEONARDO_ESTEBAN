//tablas de multiplicar usando callbacks
import operaciones from "./my_modules/plantillas.js"

//CODIGO ECHO EN CLASE PARA GUIARME ------------------>


// function Multiplicar(numero, callback) {
//     setTimeout(() => {
//         console.log(`tabla de multiplicar del ${numero}:`)
//         let resultado = " "
//         for (let i = 1; i <= 10; ++i)
//             resultado += ` ${numero} x ${i} = ${numero * i} \n`
//         callback()
//         console.log(resultado)

//     }, 0 | Math.random() * 2000);

// }
//------------------------------------------------------------>

//CALBACK HELL  
operaciones.MultiplicarPlantilla(1, 30, () => {
    console.log("  ")
    operaciones.MultiplicarPlantilla(2, 30, () => {
         console.log("  ")
        operaciones.MultiplicarPlantilla(3, 30, () => {
             console.log("  ")
            operaciones.MultiplicarPlantilla(4, 30, () => {
                 console.log("  ")
                operaciones.MultiplicarPlantilla(5, 30, () => {
                     console.log("  ")
                    operaciones.MultiplicarPlantilla(6, 30, () => {
                        console.log("  ")
                        operaciones.MultiplicarPlantilla(7, 30, () => {
                             console.log("  ")
                            operaciones.MultiplicarPlantilla(8, 30, () => {
                                 console.log("  ")
                                operaciones.MultiplicarPlantilla(9, 30, () => {
                                     console.log("  ")
                                    operaciones.MultiplicarPlantilla(10, 30, () => {
                                        console.log("Todas las tablas de multiplicar han sido generadas.");
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
});
