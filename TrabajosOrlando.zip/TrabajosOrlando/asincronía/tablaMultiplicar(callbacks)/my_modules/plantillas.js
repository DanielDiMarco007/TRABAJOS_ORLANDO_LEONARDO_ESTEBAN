import colors from "colors";


function MultiplicarPlantilla(numero, tamano = 30, callback) {
    setTimeout(() => {

    const emptyLine = '*'.repeat(tamano);
    console.log(emptyLine.bgWhite);


        // --- TÍTULO ---

        const titulo = `Tabla del ${numero}`;
        console.log(
            "  ".bgWhite +
            " ".repeat(Math.floor(tamano - 4 - titulo.length) / 2) +
            titulo +
            " ".repeat(tamano - 4 - titulo.length - Math.floor((tamano - 4 - titulo.length) / 2)) +
            "  ".bgWhite
        );
        console.log(emptyLine.bgWhite);

        // cuerpo de la plantilla, acá se muestran las tablas de multiplicar
        const espacio = 7;//margen izquierdo

        for (let i = 1; i <= 10; i++) {  

            let resultado = " "

            resultado += ` ${numero} x ${i} = ${numero * i} `

            console.log(
                "  ".bgWhite +
                " ".repeat(espacio) +
                resultado.green +
                " ".repeat(tamano - espacio - 4 - resultado.length) +
                "  ".bgWhite
            );
        }

        // Línea final
        console.log(emptyLine.bgWhite);
        callback();
    }, 0 | Math.random() * 3000);
}

const operaciones = {MultiplicarPlantilla}

export default operaciones;